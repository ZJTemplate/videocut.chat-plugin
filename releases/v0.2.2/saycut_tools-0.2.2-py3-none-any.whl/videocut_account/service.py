"""Account-bound device authorization and short SDK-compatible personal leases."""

import base64
import hashlib
import re
import secrets
import time
from datetime import datetime, timezone
from uuid import uuid4

from cryptography.fernet import Fernet
from flask import current_app
from sqlalchemy import func, select, text

from .models import (
    Account,
    Connection,
    DeviceGrant,
    EntitlementEvent,
    Lease,
    RateBucket,
    Token,
)
from .storage import get_engine, setting, transaction

SCOPE = 'account:read license:local'
CLIENTS = {'saycut-local': 'Saycut Local'}
DEVICE_GRANT = 'urn:ietf:params:oauth:grant-type:device_code'


class McpError(Exception):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


class CommitError(McpError):
    """Persist rate/backoff or replay revocation before returning a protocol error."""


def now():
    clock = current_app.extensions.get('mcp_clock', time.time)
    return int(clock())


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def required(data, key, maximum=4096):
    value = data.get(key)
    if not isinstance(value, str) or not value or len(value) > maximum:
        raise McpError('invalid_request', 'Invalid ' + key)
    return value


def user_code(value):
    normalized = value.replace('-', '').upper()
    if not re.fullmatch('[BCDFGHJKLMNPQRSTVWXZ23456789]{10}', normalized):
        raise McpError('invalid_user_code', 'Invalid or expired authorization code')
    return digest(normalized)


def active_user(session, user_id, lock=False):
    suffix = ' FOR UPDATE' if lock and session.bind.dialect.name == 'mysql' else ''
    row = (
        session.execute(
            text(
                'SELECT id, is_active, phone, phone_verified, root FROM users WHERE id = :id'
                + suffix
            ),
            {'id': user_id},
        )
        .mappings()
        .first()
    )
    if not row or not row['is_active']:
        raise McpError('invalid_token', 'Account is unavailable', 401)
    return row


def ensure_account(session, user_id):
    # The existing user row serializes first-time trial allocation across devices.
    active_user(session, user_id, lock=True)
    account = session.get(Account, user_id, with_for_update=True)
    if account is None:
        started = now()
        days = max(0, min(30, int(setting('MCP_TRIAL_DAYS', 30))))
        account = Account(
            user_id=user_id,
            trial_started_at=started,
            entitlement_until=started + days * 86400,
            is_active=True,
        )
        session.add(account)
        session.flush()
    return account


def entitlement_valid(account):
    return bool(account and account.is_active and account.entitlement_until > now())


def rate_limit(action, identity, limit, seconds=60):
    key = digest(action + ':' + str(identity))
    bucket = now() // seconds
    table = RateBucket.__table__
    with transaction() as session:
        if get_engine().dialect.name == 'mysql':
            from sqlalchemy.dialects.mysql import insert

            statement = insert(table).values(key_hash=key, bucket=bucket, count=1)
            statement = statement.on_duplicate_key_update(count=table.c.count + 1)
        else:
            from sqlalchemy.dialects.sqlite import insert

            statement = insert(table).values(key_hash=key, bucket=bucket, count=1)
            statement = statement.on_conflict_do_update(
                index_elements=['key_hash', 'bucket'], set_={'count': table.c.count + 1}
            )
        session.execute(statement)
        count = session.get(RateBucket, (key, bucket)).count
    if count > limit:
        raise McpError('rate_limited', 'Too many requests; try again later', 429)


def authorize_device(session, data):
    client = required(data, 'client_id', 64)
    if client not in CLIENTS:
        raise McpError('invalid_client', 'Unknown client')
    if data.get('scope', SCOPE) != SCOPE:
        raise McpError(
            'invalid_scope', 'This client only supports local SDK authorization'
        )
    name = required(data, 'device_name', 100)
    if any(ord(char) < 32 for char in name):
        raise McpError('invalid_request', 'Invalid device_name')
    code = ''.join(secrets.choice('BCDFGHJKLMNPQRSTVWXZ23456789') for _ in range(10))
    device = secrets.token_urlsafe(48)
    session.add(
        DeviceGrant(
            device_hash=digest(device),
            user_code_hash=digest(code),
            client_id=client,
            device_name=name,
            expires_at=now() + 600,
        )
    )
    verification = str(
        setting('MCP_PLATFORM_ORIGIN', 'https://platform.zjtemplate.com')
    ).rstrip('/')
    if not verification.startswith('https://'):
        raise McpError('server_error', 'Authorization origin must use HTTPS', 503)
    formatted = code[:5] + '-' + code[5:]
    return {
        'device_code': device,
        'user_code': formatted,
        'verification_uri': verification + '/mcp/authorize',
        'verification_uri_complete': verification
        + '/mcp/authorize?user_code='
        + formatted,
        'expires_in': 600,
        'interval': 5,
    }


def review_device(session, code):
    grant = session.execute(
        select(DeviceGrant)
        .where(DeviceGrant.user_code_hash == user_code(code))
        .with_for_update()
    ).scalar_one_or_none()
    if not grant or grant.expires_at <= now() or grant.status != 'pending':
        raise McpError(
            'invalid_user_code', 'Invalid, completed or expired authorization code'
        )
    return grant


def decide_device(session, code, user_id, approve):
    grant = review_device(session, code)
    if approve:
        ensure_account(session, user_id)
        grant.user_id = user_id
        grant.status = 'approved'
    else:
        grant.status = 'denied'
    return {'status': grant.status}


def token_pair(session, connection):
    access, refresh = (
        'mcp_at_' + secrets.token_urlsafe(48),
        'mcp_rt_' + secrets.token_urlsafe(48),
    )
    expires = min(now() + 900, connection.expires_at)
    for secret, kind, until in (
        (access, 'access', expires),
        (refresh, 'refresh', connection.expires_at),
    ):
        session.add(
            Token(
                token_hash=digest(secret),
                connection_id=connection.id,
                kind=kind,
                expires_at=until,
            )
        )
    return {
        'access_token': access,
        'refresh_token': refresh,
        'token_type': 'Bearer',
        'expires_in': expires - now(),
        'scope': SCOPE,
        'connection_id': connection.id,
        'server_time': now(),
    }


def connection_for_token(session, secret, kind):
    token = session.get(Token, digest(secret))
    if token is None or token.kind != kind:
        raise McpError(
            'invalid_token' if kind == 'access' else 'invalid_grant',
            'Invalid credential',
            401,
        )
    # Lock connections before tokens/leases, consistently across renew/revoke/verify.
    connection = session.get(
        Connection, token.connection_id, with_for_update=True, populate_existing=True
    )
    if not connection or connection.revoked_at or connection.expires_at <= now():
        raise McpError(
            'invalid_token' if kind == 'access' else 'invalid_grant',
            'Authorization expired or revoked',
            401,
        )
    token = session.get(
        Token, token.token_hash, populate_existing=True, with_for_update=True
    )
    if kind == 'refresh' and token.used_at:
        connection.revoked_at = now()
        raise CommitError(
            'invalid_grant', 'Refresh credential reused; authorize again', 401
        )
    if token.expires_at <= now():
        raise McpError(
            'invalid_token' if kind == 'access' else 'invalid_grant',
            'Credential expired',
            401,
        )
    active_user(session, connection.user_id)
    return connection, token


def exchange_token(session, data):
    client = required(data, 'client_id', 64)
    if client not in CLIENTS:
        raise McpError('invalid_client', 'Unknown client')
    grant_type = required(data, 'grant_type', 100)
    if grant_type == 'refresh_token':
        secret = required(data, 'refresh_token', 256)
        # Client binding is checked before a token can trigger replay revocation.
        token = session.get(Token, digest(secret))
        connection = session.get(Connection, token.connection_id) if token else None
        if not connection or connection.client_id != client:
            raise McpError('invalid_grant', 'Invalid credential')
        connection, token = connection_for_token(session, secret, 'refresh')
        token.used_at = now()
        return token_pair(session, connection)
    if grant_type != DEVICE_GRANT:
        raise McpError('unsupported_grant_type', 'Unsupported grant type')
    grant = session.get(
        DeviceGrant, digest(required(data, 'device_code', 256)), with_for_update=True
    )
    if not grant or grant.client_id != client:
        raise McpError('invalid_grant', 'Invalid device code')
    if grant.expires_at <= now():
        raise McpError('expired_token', 'Authorization code expired')
    if grant.status == 'consumed':
        raise McpError('invalid_grant', 'Authorization code already used')
    if grant.status == 'denied':
        raise McpError('access_denied', 'Authorization declined')
    if grant.last_poll_at and now() - grant.last_poll_at < grant.poll_interval:
        grant.poll_interval += 5
        grant.last_poll_at = now()
        raise CommitError('slow_down', 'Increase polling interval by five seconds')
    grant.last_poll_at = now()
    if grant.status != 'approved':
        raise CommitError('authorization_pending', 'Awaiting user approval')
    active_user(session, grant.user_id)
    ensure_account(session, grant.user_id)
    count = session.execute(
        select(func.count())
        .select_from(Connection)
        .where(
            Connection.user_id == grant.user_id,
            Connection.revoked_at == 0,
            Connection.expires_at > now(),
        )
    ).scalar_one()
    if count >= max(1, min(20, int(setting('MCP_MAX_CONNECTIONS', 3)))):
        raise McpError(
            'access_denied', 'Revoke an existing device before authorizing another', 403
        )
    connection = Connection(
        id=uuid4().hex,
        user_id=grant.user_id,
        client_id=client,
        device_name=grant.device_name,
        created_at=now(),
        expires_at=now() + 30 * 86400,
    )
    session.add(connection)
    session.flush()
    grant.status = 'consumed'
    return token_pair(session, connection)


def session_info(session, connection):
    account = session.get(Account, connection.user_id)
    return {
        'user_id': connection.user_id,
        'connection_id': connection.id,
        'scope': SCOPE,
        'device_name': connection.device_name,
        'server_time': now(),
        'connection_expires_at': connection.expires_at,
        'local_render_allowed': entitlement_valid(account),
        'entitlement_until': account.entitlement_until if account else None,
    }


def cipher():
    key = setting('MCP_LICENSE_ENCRYPTION_KEY', '')
    if not key:
        raise McpError(
            'license_unavailable', 'Personal license signing is not configured', 503
        )
    return Fernet(key.encode('ascii'))


def issue_license(session, connection):
    account = session.get(Account, connection.user_id, with_for_update=True)
    if not entitlement_valid(account):
        raise McpError(
            'entitlement_required',
            'Local rendering entitlement expired or disabled',
            403,
        )
    latest = session.execute(
        select(Lease)
        .where(
            Lease.connection_id == connection.id,
            Lease.expires_at <= min(account.entitlement_until, connection.expires_at),
        )
        .order_by(Lease.created_at.desc())
        .limit(1)
    ).scalar_one_or_none()
    if (
        latest
        and latest.expires_at > now() + 86400
        and latest.expires_at <= account.entitlement_until
    ):
        key = cipher().decrypt(latest.encrypted_license.encode('ascii')).decode('ascii')
        return {'license': key, 'expires_at': latest.expires_at, 'server_time': now()}
    if (
        latest
        and latest.created_at > now() - 60
        and latest.expires_at > now()
        and latest.expires_at <= min(account.entitlement_until, connection.expires_at)
    ):
        # Also reuse near-expiry leases; repeated calls must not create unlimited certificates.
        key = cipher().decrypt(latest.encrypted_license.encode('ascii')).decode('ascii')
        return {'license': key, 'expires_at': latest.expires_at, 'server_time': now()}
    seconds = max(
        3600, min(7 * 86400, int(setting('MCP_LICENSE_TTL_SECONDS', 3 * 86400)))
    )
    expires = min(now() + seconds, account.entitlement_until, connection.expires_at)
    info = {
        'product': 'SmartCut',
        'company': 'Saycut Personal',
        'created_at': now(),
        'expire_time': expires,
        'expire_date': datetime.fromtimestamp(expires, timezone.utc).strftime(
            '%Y-%m-%d'
        ),
        'features': ['save', 'change', 'export'],
        'license_type': 'mcp',
        'lease_id': uuid4().hex,
    }
    signer = current_app.extensions.get('mcp_license_signer')
    if signer is None:
        from .signer import generate_license
        signer = generate_license
    encryption = cipher()
    raw = signer(info)
    raw = raw.decode('ascii') if isinstance(raw, bytes) else raw
    base64.b64decode(raw, validate=True)
    key = 'mcp-' + raw
    lease = Lease(
        id=info['lease_id'],
        connection_id=connection.id,
        license_hash=digest(key),
        encrypted_license=encryption.encrypt(key.encode('ascii')).decode('ascii'),
        created_at=now(),
        expires_at=expires,
    )
    session.add(lease)
    return {'license': key, 'expires_at': expires, 'server_time': now()}


def verify_license(session, key, owner_connection=None):
    invalid = {
        'valid': False,
        'message': 'Personal license is invalid or revoked',
        'server_time': now(),
    }
    if (
        not isinstance(key, str)
        or not key.startswith('mcp-')
        or not 4 < len(key) <= 16384
    ):
        return invalid
    lease = session.execute(
        select(Lease).where(Lease.license_hash == digest(key))
    ).scalar_one_or_none()
    if not lease or (owner_connection and lease.connection_id != owner_connection.id):
        return invalid
    connection = session.get(Connection, lease.connection_id)
    if (
        not connection
        or connection.revoked_at
        or min(lease.expires_at, connection.expires_at) <= now()
    ):
        return invalid
    try:
        active_user(session, connection.user_id)
    except McpError:
        return invalid
    account = session.get(Account, connection.user_id)
    if not entitlement_valid(account):
        return invalid
    expires = min(lease.expires_at, connection.expires_at, account.entitlement_until)
    return {
        'valid': True,
        'company_name': 'Saycut Personal',
        'sdk': 'SmartCut',
        'expires_at': datetime.fromtimestamp(expires, timezone.utc).isoformat(),
        'days_remaining': (expires - now()) / 86400,
        'server_time': now(),
    }


def list_connections(session, user_id):
    rows = session.execute(
        select(Connection)
        .where(Connection.user_id == user_id)
        .order_by(Connection.created_at.desc())
        .limit(100)
    ).scalars()
    account = session.get(Account, user_id)
    return {
        'connections': [
            {
                'id': row.id,
                'client_name': CLIENTS.get(row.client_id, row.client_id),
                'device_name': row.device_name,
                'created_at': row.created_at,
                'expires_at': row.expires_at,
                'revoked_at': row.revoked_at,
            }
            for row in rows
        ],
        'local_render_allowed': entitlement_valid(account),
        'entitlement_until': account.entitlement_until if account else None,
        'server_time': now(),
    }


def revoke_connection(session, connection_id, user_id):
    row = session.get(Connection, connection_id, with_for_update=True)
    if not row or row.user_id != user_id:
        raise McpError('not_found', 'Authorization not found', 404)
    row.revoked_at = row.revoked_at or now()
    return {'revoked': True}


def set_entitlement(session, actor, data):
    if not actor.get('root'):
        raise McpError('forbidden', 'Administrator access required', 403)
    user_id, until, active = (
        data.get('user_id'),
        data.get('entitlement_until'),
        data.get('is_active'),
    )
    if type(user_id) is not int or user_id <= 0 or type(until) is not int or until < 0:
        raise McpError('invalid_request', 'Invalid account or expiry')
    if type(active) is not bool or until > now() + 366 * 86400:
        raise McpError('invalid_request', 'Invalid entitlement')
    reason = required(data, 'reason', 200)
    account = ensure_account(session, user_id)
    session.add(
        EntitlementEvent(
            id=uuid4().hex,
            user_id=user_id,
            actor_user_id=actor['id'],
            previous_until=account.entitlement_until,
            entitlement_until=until,
            is_active=active,
            reason=reason,
            created_at=now(),
        )
    )
    account.entitlement_until, account.is_active = until, active
    return {'user_id': user_id, 'entitlement_until': until, 'is_active': active}
