"""Separate metadata: importing MCP must never change db.create_all() for legacy tables."""

from typing import ClassVar

from sqlalchemy import BigInteger, Boolean, Column, Index, Integer, String, Text
from sqlalchemy.orm import declarative_base


class McpTable:
    __table_args__: ClassVar[dict] = {
        'mysql_engine': 'InnoDB',
        'mysql_charset': 'utf8mb4',
        'mysql_collate': 'utf8mb4_bin',
    }


Base = declarative_base(cls=McpTable)


class Account(Base):
    __tablename__ = 'mcp_accounts'
    user_id = Column(BigInteger, primary_key=True, autoincrement=False)
    trial_started_at = Column(BigInteger, nullable=False)
    entitlement_until = Column(BigInteger, nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)


class DeviceGrant(Base):
    __tablename__ = 'mcp_device_grants'
    device_hash = Column(String(64), primary_key=True)
    user_code_hash = Column(String(64), nullable=False, unique=True)
    client_id = Column(String(64), nullable=False)
    device_name = Column(String(100), nullable=False)
    status = Column(String(16), nullable=False, default='pending')
    user_id = Column(BigInteger)
    expires_at = Column(BigInteger, nullable=False, index=True)
    last_poll_at = Column(BigInteger, nullable=False, default=0)
    poll_interval = Column(Integer, nullable=False, default=5)


class Connection(Base):
    __tablename__ = 'mcp_connections'
    id = Column(String(32), primary_key=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    client_id = Column(String(64), nullable=False)
    device_name = Column(String(100), nullable=False)
    created_at = Column(BigInteger, nullable=False)
    expires_at = Column(BigInteger, nullable=False)
    revoked_at = Column(BigInteger, nullable=False, default=0)


class Token(Base):
    __tablename__ = 'mcp_tokens'
    token_hash = Column(String(64), primary_key=True)
    connection_id = Column(String(32), nullable=False, index=True)
    kind = Column(String(8), nullable=False)
    expires_at = Column(BigInteger, nullable=False, index=True)
    used_at = Column(BigInteger, nullable=False, default=0)


class Lease(Base):
    __tablename__ = 'mcp_license_leases'
    id = Column(String(32), primary_key=True)
    connection_id = Column(String(32), nullable=False, index=True)
    license_hash = Column(String(64), nullable=False, unique=True)
    encrypted_license = Column(Text, nullable=False)
    created_at = Column(BigInteger, nullable=False)
    expires_at = Column(BigInteger, nullable=False, index=True)


class RateBucket(Base):
    __tablename__ = 'mcp_rate_buckets'
    key_hash = Column(String(64), primary_key=True)
    bucket = Column(BigInteger, primary_key=True)
    count = Column(Integer, nullable=False)


class EntitlementEvent(Base):
    __tablename__ = 'mcp_entitlement_events'
    id = Column(String(32), primary_key=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    actor_user_id = Column(BigInteger, nullable=False)
    previous_until = Column(BigInteger, nullable=False)
    entitlement_until = Column(BigInteger, nullable=False)
    is_active = Column(Boolean, nullable=False)
    reason = Column(String(200), nullable=False)
    created_at = Column(BigInteger, nullable=False)


Index('ix_mcp_lease_connection_created', Lease.connection_id, Lease.created_at)
