"""One private deployment file; no runtime environment-variable configuration."""

import json
import hashlib
import re
from pathlib import Path

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import serialization
from sqlalchemy.engine import make_url


def load_config(path=None):
    path = Path(path) if path else Path(__file__).resolve().parents[1] / 'server.private.json'
    return validate_config(json.loads(path.read_text()))


def validate_config(value):
    account = value['account']
    url = make_url(account['DATABASE_URL'])
    if url.drivername != 'mysql+pymysql' or not url.host:
        raise ValueError('Account storage requires the existing MySQL database')
    Fernet(account['MCP_LICENSE_ENCRYPTION_KEY'].encode())
    password = account.get('SDK_PRIVATE_KEY_PASSWORD')
    key = serialization.load_pem_private_key(account['SDK_PRIVATE_KEY_PEM'].encode(),
                                             password=password.encode() if password else None)
    public = key.public_key().public_bytes(serialization.Encoding.DER,
                                           serialization.PublicFormat.SubjectPublicKeyInfo)
    if hashlib.sha256(public).hexdigest() != '0d943ee0b46d179d873d1887e3668f835bd432f829d86047a16a0be474054ef9':
        raise ValueError('The signing key must match the existing SDK public key')
    cloud = value['cloud']
    if cloud['backend'] != 'cloud' or not cloud.get('database_url'):
        raise ValueError('Existing video service configuration is required')
    tokens = cloud.get('api_tokens', {})
    if not tokens and not cloud.get('oidc_issuer'):
        raise ValueError('Video authentication must remain configured')
    if any(not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', tenant) or len(token) < 24
           for tenant, token in tokens.items()):
        raise ValueError('Invalid video authentication configuration')
    if len(value.get('reconcile_token', '')) < 32:
        raise ValueError('Existing timer credential is required')
    if not cloud.get('oss_access_key_id') or not cloud.get('oss_access_key_secret'):
        raise ValueError('Scoped OSS credentials are required in the private file')
    return value
