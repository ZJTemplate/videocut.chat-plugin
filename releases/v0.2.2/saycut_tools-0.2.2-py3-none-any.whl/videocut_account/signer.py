"""Preserve the existing template_generator certificate wire format."""

import base64
import hashlib
import json
import secrets

from cryptography.hazmat.primitives import padding, serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from flask import current_app


def padded(value):
    padder = padding.PKCS7(128).padder()
    return padder.update(value) + padder.finalize()


def generate_license(info):
    config = current_app.config
    password = config.get('SDK_PRIVATE_KEY_PASSWORD')
    private = serialization.load_pem_private_key(
        config['SDK_PRIVATE_KEY_PEM'].encode(), password=password.encode() if password else None
    )
    key, iv = secrets.token_bytes(16), secrets.token_bytes(16)
    encryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
    ciphertext = iv + encryptor.update(padded(json.dumps(info, ensure_ascii=False).encode())) + encryptor.finalize()
    message = padded(key + hashlib.sha256(ciphertext).digest())
    size = (private.key_size + 7) // 8
    needed = size - len(message) - 3
    if needed < 8:
        raise ValueError('SDK key is too short')
    nonzero = bytearray()
    while len(nonzero) < needed:
        nonzero.extend(b for b in secrets.token_bytes(needed) if b)
    encoded = b'\x00\x02' + bytes(nonzero[:needed]) + b'\x00' + message
    numbers = private.private_numbers()
    signature = pow(int.from_bytes(encoded, 'big'), numbers.d, numbers.public_numbers.n).to_bytes(size, 'big')
    return base64.b64encode(ciphertext + signature).decode('ascii')
