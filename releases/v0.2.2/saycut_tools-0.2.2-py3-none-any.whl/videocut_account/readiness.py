"""Read-only storage readiness inside the FC network before serving requests."""

from sqlalchemy import create_engine, inspect, text
from cryptography.fernet import Fernet
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError

from videocut_account.models import Base


def verify_storage(config):
    for kind, uri in [('account', config['account']['DATABASE_URL']),
                      ('cloud', config['cloud']['database_url'])]:
        url = make_url(uri).difference_update_query(['autocommit'])
        engine = create_engine(url, hide_parameters=True, connect_args={'connect_timeout': 10})
        print('Checking ' + kind + ' database readiness', flush=True)
        try:
            with engine.connect() as connection:
                inspector = inspect(connection)
                required = list(Base.metadata.tables) + ['users'] if kind == 'account' else ['saycut_documents', 'saycut_events']
                for name in required:
                    if not inspector.has_table(name):
                        raise RuntimeError('Existing service tables are missing; no schema was changed')
                if kind == 'account':
                    lease = connection.execute(text(
                        'SELECT encrypted_license FROM mcp_license_leases ORDER BY created_at DESC LIMIT 1'
                    )).scalar()
                    if lease:
                        Fernet(config['account']['MCP_LICENSE_ENCRYPTION_KEY'].encode()).decrypt(lease.encode())
        except DBAPIError as exc:
            code = exc.orig.args[0] if exc.orig.args and type(exc.orig.args[0]) is int else None
            print('Database preflight failed: ' + kind + ', MySQL error code=' + str(code), flush=True)
            raise
        finally:
            engine.dispose()
