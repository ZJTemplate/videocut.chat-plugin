"""Dedicated transactions; do not inherit the legacy autocommit connection pool."""

from contextlib import contextmanager
from threading import Lock

from flask import current_app
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

_engine_lock = Lock()


def setting(name, default=None):
    return current_app.config.get(name, default)


def get_engine():
    app = current_app._get_current_object()
    with _engine_lock:
        if 'mcp_engine' not in app.extensions:
            from sqlalchemy.engine import make_url
            url = make_url(app.config['DATABASE_URL']).difference_update_query(['autocommit'])
            if url.drivername != 'mysql+pymysql':
                raise RuntimeError('MCP production storage requires MySQL/PyMySQL')
            app.extensions['mcp_engine'] = create_engine(
                url,
                isolation_level='READ COMMITTED',
                pool_pre_ping=True,
                pool_size=2,
                max_overflow=0,
                pool_timeout=5,
                pool_recycle=300,
                connect_args={'autocommit': False},
                hide_parameters=True,
            )
        return app.extensions['mcp_engine']


@contextmanager
def transaction():
    with Session(get_engine(), expire_on_commit=False) as session, session.begin():
        yield session
