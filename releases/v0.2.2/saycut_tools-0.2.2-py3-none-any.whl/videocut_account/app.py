"""MCP account business, mounted alongside the video protocol endpoints."""

from flask import Flask, jsonify, request

from . import mcp_bp


def create_account_app(config):
    app = Flask(__name__)
    app.config.update(config)
    app.config['MAX_CONTENT_LENGTH'] = 16384
    app.register_blueprint(mcp_bp, url_prefix='/mcp')

    @app.before_request
    def origin_guard():
        origin = request.headers.get('Origin')
        if origin and origin != 'https://platform.zjtemplate.com':
            return jsonify({'error': 'forbidden_origin'}), 403

    @app.after_request
    def cors(response):
        # FC supplies permissive CORS defaults when these headers are absent.
        response.headers['Access-Control-Allow-Origin'] = 'https://platform.zjtemplate.com'
        response.headers['Access-Control-Allow-Credentials'] = 'false'
        response.headers['Vary'] = 'Origin'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Usertoken, Authorization'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
        response.headers['Cache-Control'] = 'no-store'
        return response

    return app
