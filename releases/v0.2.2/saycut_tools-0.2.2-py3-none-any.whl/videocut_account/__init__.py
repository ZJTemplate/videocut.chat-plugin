"""Personal authorization routes without schema creation or legacy billing changes."""

from functools import wraps
import httpx

from flask import Blueprint, current_app, g, jsonify, request

from . import service
from .service import CommitError, McpError
from .storage import setting, transaction

mcp_bp = Blueprint('mcp', __name__)


@mcp_bp.before_request
def guard():
    if request.content_length and request.content_length > 16384:
        return jsonify({'error': 'invalid_request'}), 413


@mcp_bp.after_request
def private_response(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response


def body():
    data = request.get_json(silent=True) if request.is_json else request.form.to_dict()
    if not isinstance(data, dict):
        raise McpError('invalid_request', 'Expected an object')
    return data


def endpoint(web=False):
    def decorator(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            try:
                result = function(*args, **kwargs)
                return jsonify({'code': 0, 'data': result} if web else result)
            except McpError as error:
                payload = {'error': error.code, 'error_description': error.message}
                if web:
                    return jsonify({'code': error.status, 'message': error.message})
                return jsonify(payload), error.status
            except Exception as error:  # noqa: BLE001 - boundary must redact SQL and signing exceptions
                # SQL errors can contain parameters, so never log repr/traceback here.
                current_app.logger.error('MCP request failed: %s', type(error).__name__)
                if web:
                    return jsonify({'code': 503, 'message': 'MCP service unavailable'})
                return jsonify({'error': 'temporarily_unavailable'}), 503

        return wrapped

    return decorator


def platform_user(session, write=False):
    # Require the actual website JWT, not the legacy API-key/fixed-token fallbacks or cookies.
    token = request.headers.get('usertoken', '')
    if not token or len(token) > 4096:
        raise McpError('invalid_token', 'Please sign in', 401)
    try:
        user_id = g.get('mcp_user_id')
        if user_id is None:
            with httpx.Client(timeout=10, follow_redirects=False, trust_env=False) as client:
                response = client.get('https://api.zjtemplate.com/user/identity', headers={'usertoken': token})
            if response.status_code in {401, 403}:
                raise McpError('invalid_token', 'Please sign in again', 401)
            response.raise_for_status()
            identity = response.json()
            if identity.get('code') != 0 or type(identity.get('data', {}).get('user_id')) is not int:
                raise ValueError('Unexpected identity response')
            user_id = g.mcp_user_id = identity['data']['user_id']
    except McpError:
        raise
    except (httpx.HTTPError, ValueError, TypeError, AttributeError):
        raise McpError('temporarily_unavailable', 'Identity service unavailable', 503) from None
    if write and request.headers.get('Origin') != str(
        setting('MCP_PLATFORM_ORIGIN', 'https://platform.zjtemplate.com')
    ).rstrip('/'):
        raise McpError('forbidden', 'Invalid authorization origin', 403)
    user = service.active_user(session, user_id)
    if write and (not user['phone'] or not user['phone_verified']):
        raise McpError('phone_required', '请先完成手机号验证', 462)
    return user


def bearer(session):
    value = request.headers.get('Authorization', '')
    if not value.startswith('Bearer mcp_at_') or len(value) > 512:
        raise McpError('invalid_token', 'Personal access token required', 401)
    return service.connection_for_token(session, value[7:], 'access')[0]


def limit_platform_user(action, write=False):
    with transaction() as session:
        user = platform_user(session, write=write)
        user_id = user['id']
    # Finish authentication before acquiring another pool connection for rate accounting.
    service.rate_limit(action, user_id, 15)


@mcp_bp.route('/v1/device/authorize', methods=['POST'])
@endpoint()
def device_authorize():
    service.rate_limit('device', request.remote_addr, 20)
    with transaction() as session:
        return service.authorize_device(session, body())


@mcp_bp.route('/v1/token', methods=['POST'])
@endpoint()
def token():
    service.rate_limit('token', request.remote_addr, 120)
    error = None
    with transaction() as session:
        try:
            result = service.exchange_token(session, body())
        except CommitError as caught:
            error = caught
    if error:
        raise error
    return result


@mcp_bp.route('/v1/device/review', methods=['GET'])
@endpoint(web=True)
def review():
    limit_platform_user('review')
    with transaction() as session:
        user = platform_user(session)
        grant = service.review_device(session, request.args.get('user_code', ''))
        return {
            'client_name': service.CLIENTS[grant.client_id],
            'device_name': grant.device_name,
            'scope': service.SCOPE,
            'expires_at': grant.expires_at,
            'user_id': user['id'],
        }


@mcp_bp.route('/v1/device/decision', methods=['POST'])
@endpoint(web=True)
def decision():
    data = body()
    if type(data.get('approve')) is not bool:
        raise McpError('invalid_request', 'An explicit decision is required')
    limit_platform_user('decision', write=True)
    with transaction() as session:
        user = platform_user(session, write=True)
        return service.decide_device(
            session,
            service.required(data, 'user_code', 32),
            user['id'],
            data['approve'],
        )


@mcp_bp.route('/v1/session', methods=['GET'])
@endpoint()
def session_status():
    with transaction() as session:
        return service.session_info(session, bearer(session))


@mcp_bp.route('/v1/license/issue', methods=['POST'])
@endpoint()
def issue():
    with transaction() as session:
        user_id = bearer(session).user_id
    service.rate_limit('issue', user_id, 30)
    with transaction() as session:
        connection = bearer(session)
        return service.issue_license(session, connection)


@mcp_bp.route('/v1/license/verify', methods=['POST'])
@endpoint()
def verify():
    with transaction() as session:
        connection = bearer(session)
        return service.verify_license(
            session, service.required(body(), 'license', 16384), connection
        )


@mcp_bp.route('/v1/connections', methods=['GET'])
@endpoint(web=True)
def connections():
    with transaction() as session:
        user = platform_user(session)
        return service.list_connections(session, user['id'])


@mcp_bp.route('/v1/connections/<connection_id>/revoke', methods=['POST'])
@endpoint(web=True)
def revoke(connection_id):
    with transaction() as session:
        user = platform_user(session, write=True)
        return service.revoke_connection(session, connection_id, user['id'])


@mcp_bp.route('/v1/logout', methods=['POST'])
@endpoint()
def logout():
    with transaction() as session:
        connection = bearer(session)
        return service.revoke_connection(session, connection.id, connection.user_id)


@mcp_bp.route('/v1/admin/entitlement', methods=['POST'])
@endpoint(web=True)
def entitlement():
    with transaction() as session:
        return service.set_entitlement(
            session, platform_user(session, write=True), body()
        )


def verify_personal_license(key):
    """Compatibility branch for template_generator's fixed business verification URL."""
    try:
        service.rate_limit('public-verify', request.remote_addr, 120)
        with transaction() as session:
            result = service.verify_license(session, key)
    except Exception:  # noqa: BLE001 - compatibility verification must fail closed on all storage failures
        result = {
            'valid': False,
            'message': 'Personal license verification unavailable',
        }
    return result


@mcp_bp.route('/v1/license/check', methods=['POST'])
@endpoint()
def public_license_check():
    return verify_personal_license(service.required(body(), 'license', 16384))


@mcp_bp.route('/v1/health', methods=['GET'])
@endpoint()
def account_health():
    from sqlalchemy import text
    with transaction() as session:
        session.execute(text('SELECT 1 FROM mcp_accounts LIMIT 1'))
    return {'status': 'ok', 'service': 'videocut-account'}
