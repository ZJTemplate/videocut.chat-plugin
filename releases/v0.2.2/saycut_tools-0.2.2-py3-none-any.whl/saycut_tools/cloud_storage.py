"""Private OSS objects with short-lived, tenant-scoped access grants."""

from __future__ import annotations

import os

from .errors import SaycutError


class ObjectStorage:
    def __init__(self, settings, bucket=None):
        import oss2

        self.settings = settings
        if not settings.oss_bucket:
            raise SaycutError("oss_required", "Configure a private OSS bucket")
        if bucket:
            self.bucket = bucket
            return
        access = settings.oss_access_key_id or os.environ.get("ALIBABA_CLOUD_ACCESS_KEY_ID") or os.environ.get("ALIBABA_CLOUD_ACCESS_KEY")
        secret = settings.oss_access_key_secret or os.environ.get("ALIBABA_CLOUD_ACCESS_KEY_SECRET") or os.environ.get(
            "ALIBABA_CLOUD_SECRET_KEY"
        )
        token = None if settings.oss_access_key_id else os.environ.get("ALIBABA_CLOUD_SECURITY_TOKEN")
        if not access or not secret:
            raise SaycutError("oss_auth_required", "Use an FC RAM role or scoped OSS credentials")
        from oss2.credentials import StaticCredentialsProvider

        auth = oss2.ProviderAuthV4(StaticCredentialsProvider(access, secret, token))
        self.bucket = oss2.Bucket(
            auth, settings.oss_endpoint, settings.oss_bucket, connect_timeout=15, region=settings.oss_region
        )

    def key(self, tenant, *parts):
        return "/".join([self.settings.oss_prefix.strip("/"), tenant, *parts])

    def head(self, key):
        import oss2

        try:
            response = self.bucket.head_object(key)
            return {
                "bytes": response.content_length,
                "etag": response.etag,
                "content_type": response.content_type,
            }
        except oss2.exceptions.NoSuchKey as exc:
            raise SaycutError("upload_missing", "The uploaded object was not found", 409) from exc

    def get_url(self, key, ttl=900):
        return self.bucket.sign_url("GET", key, ttl)

    def put_url(self, key, size, content_type, ttl=900):
        headers = {
            "Content-Type": content_type,
            "Content-Length": str(size),
            "x-oss-forbid-overwrite": "true",
        }
        return {
            "method": "PUT",
            "url": self.bucket.sign_url(
                "PUT", key, ttl, headers=headers, additional_headers=["content-length"]
            ),
            "headers": headers,
            "expires_in": ttl,
        }

    def read_json(self, key, max_bytes=4 * 1024 * 1024):
        import json

        response = self.bucket.get_object(key)
        try:
            body = response.read(max_bytes + 1)
            if len(body) > max_bytes:
                raise SaycutError("object_too_large", "Project manifest exceeds its size limit")
            return json.loads(body)
        finally:
            response.close()
