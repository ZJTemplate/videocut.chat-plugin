"""ASR adapters return real timestamps; cloud ASR requires explicit consent."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from .assets import probe
from .config import Settings, write_json
from .errors import SaycutError
from .models import Caption, Word


def normalize_ryry(result: dict) -> list[Caption]:
    captions = []
    for index, sentence in enumerate(result.get("sentences", [])):
        text = str(sentence.get("sentence", sentence.get("text", ""))).strip()
        if not text:
            continue
        start, end = float(sentence["start_ms"]) / 1000, float(sentence["end_ms"]) / 1000
        words = []
        for item in sentence.get("words", []):
            word = str(item.get("word", "")).strip()
            if word and item.get("start_ms") is not None and item.get("end_ms") is not None:
                a, b = float(item["start_ms"]) / 1000, float(item["end_ms"]) / 1000
                if b > a and a >= start and b <= end and (not words or a >= words[-1].end):
                    words.append(Word(text=word, start=a, end=b))
        captions.append(Caption(id=f"caption_{index}", text=text, start=start, end=end, words=words))
    return captions


def fit_media_end(captions: list[dict], duration: float) -> list[dict]:
    result = []
    for raw in captions:
        caption = Caption.model_validate(raw)
        if caption.start >= duration or caption.end > duration + 0.25:
            raise SaycutError("asr_alignment_invalid", "ASR timestamps extend outside the input video")
        # ASR frame quantization can overshoot EOF by milliseconds. Clip, never synthesize alignment.
        end = min(caption.end, duration)
        words = [
            {**word.model_dump(), "end": min(word.end, end)} for word in caption.words if word.start < end
        ]
        result.append(
            Caption.model_validate({**caption.model_dump(), "end": end, "words": words}).model_dump()
        )
    return result


def transcribe_in_process(settings: Settings, audio: Path, language: str | None, consent: bool):
    if settings.asr_backend == "ryry":
        if not consent:
            raise SaycutError("cloud_consent_required", "This ASR backend sends audio to SpeechToText")
        from ryry import server_func, upload

        url = upload.upload(str(audio), "force_oss")
        result = server_func.Task(
            "SpeechToText", [{"param": {"url": url, "language": language}}], timeout=settings.asr_timeout
        ).call()
        if not result or not isinstance(result[0], dict):
            raise SaycutError("asr_failed", "SpeechToText returned no transcript")
        captions = normalize_ryry(result[0])
    elif settings.asr_backend == "faster_whisper":
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise SaycutError(
                "asr_not_installed", "Install saycut-tools[asr] for local transcription"
            ) from exc
        try:
            model = WhisperModel(
                settings.asr_model,
                device="cpu",
                compute_type="int8",
                local_files_only=not settings.asr_allow_model_download,
            )
        except (OSError, ValueError):
            raise SaycutError(
                "asr_model_unavailable",
                "Local ASR model is unavailable; run configure-asr --backend faster_whisper --model small --download-model with the private interpreter",
            ) from None
        segments, _ = model.transcribe(
            str(audio), language=(language or "").split("-")[0] or None, word_timestamps=True, vad_filter=True
        )
        captions = []
        for index, segment in enumerate(segments):
            if segment.text.strip() and segment.end > segment.start:
                words = [
                    Word(text=w.word, start=w.start, end=w.end)
                    for w in segment.words or []
                    if w.word.strip() and w.end > w.start
                ]
                captions.append(
                    Caption(
                        id=f"caption_{index}",
                        text=segment.text.strip(),
                        start=segment.start,
                        end=segment.end,
                        words=words,
                    )
                )
    else:
        raise SaycutError("asr_not_configured", "Configure local ASR or supply timed captions")
    if not captions:
        raise SaycutError("no_speech", "No speech was recognized; no captioned video was generated")
    return [c.model_dump(mode="json") for c in captions]


def main():
    parent = os.getppid()

    def watch_parent():
        while os.getppid() == parent:
            time.sleep(2)
        if os.name != "nt":
            os.killpg(os.getpgrp(), signal.SIGKILL)
        os._exit(1)

    threading.Thread(target=watch_parent, daemon=True).start()
    folder = Path(sys.argv[1])
    request = json.loads((folder / "asr-request.json").read_text())
    settings = Settings.model_validate(request["settings"])
    audio = folder / "speech.wav"
    try:
        if not probe(Path(request["video"]), settings.ffprobe)["has_audio"]:
            raise SaycutError("no_audio_stream", "This video has no audio track; provide timed captions instead")
        subprocess.run(
            [
                settings.ffmpeg,
                "-v",
                "error",
                "-nostdin",
                "-protocol_whitelist",
                "file,pipe",
                "-i",
                request["video"],
                "-map",
                "0:a:0",
                "-vn",
                "-ac",
                "1",
                "-ar",
                "16000",
                "-t",
                str(settings.max_duration),
                "-y",
                str(audio),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=min(settings.asr_timeout, 180),
        )
        cues = transcribe_in_process(settings, audio, request.get("language"), request["consent"])
        write_json(folder / "asr-result.json", {"captions": cues})
    except Exception as exc:  # noqa: BLE001 - isolate optional ASR engines and redact provider errors
        error = (
            exc.payload()["error"]
            if isinstance(exc, SaycutError)
            else {
                "code": "asr_failed",
                "message": "ASR or audio extraction failed; inspect the private worker log",
            }
        )
        write_json(folder / "asr-error.json", error)
        raise SystemExit(1) from None
    finally:
        audio.unlink(missing_ok=True)


if __name__ == "__main__":
    os.umask(0o077)
    main()
