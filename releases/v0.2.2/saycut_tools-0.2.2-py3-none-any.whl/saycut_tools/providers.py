"""Tool-schema and result adapters; no provider credentials or model calls are needed here."""

from __future__ import annotations

import copy
import json
from collections.abc import Callable

from .errors import SaycutError
from .registry import BY_NAME, OPERATIONS

CHAT_PROVIDERS = {"openai_chat", "deepseek", "qwen", "doubao"}
RESPONSES_PROVIDERS = {"openai_responses", "deepseek_responses", "doubao_responses"}
PROVIDERS = (
    "openai_responses",
    "openai_chat",
    "deepseek",
    "deepseek_responses",
    "anthropic",
    "qwen",
    "doubao",
    "doubao_responses",
    "gemini_interactions",
)


def inline_schema(schema: dict) -> dict:
    definitions = schema.get("$defs", {})

    def walk(value):
        if isinstance(value, list):
            return [walk(item) for item in value]
        if not isinstance(value, dict):
            return value
        if "$ref" in value:
            prefix = "#/$defs/"
            if not value["$ref"].startswith(prefix):
                raise ValueError("Only local JSON Schema references may be exported")
            return walk(
                {
                    **definitions[value["$ref"][len(prefix) :]],
                    **{k: v for k, v in value.items() if k != "$ref"},
                }
            )
        return {key: walk(item) for key, item in value.items() if key not in ("$defs", "title")}

    return walk(copy.deepcopy(schema))


def tool_schemas(provider: str, names: list[str] | None = None) -> list[dict]:
    if provider not in PROVIDERS:
        raise ValueError("Unsupported provider format")
    operations = [BY_NAME[name] for name in names] if names is not None else OPERATIONS
    result = []
    for operation in operations:
        parameters = inline_schema(operation.model.model_json_schema())
        function = {"name": operation.name, "description": operation.description, "parameters": parameters}
        if provider == "anthropic":
            result.append(
                {"name": operation.name, "description": operation.description, "input_schema": parameters}
            )
        elif provider in CHAT_PROVIDERS:
            result.append({"type": "function", "function": function})
        else:
            result.append(
                {
                    "type": "function",
                    **function,
                    **({"strict": False} if provider in RESPONSES_PROVIDERS else {}),
                }
            )
    return result


def dispatch(
    provider: str,
    call: dict,
    execute: Callable[[str, dict], dict],
    approve: Callable[[str, dict], bool] | None = None,
) -> dict:
    """Require host approval for every mutating call, then use the shared validated service."""
    if provider not in PROVIDERS:
        raise ValueError("Unsupported provider format")
    if provider in CHAT_PROVIDERS:
        name, raw = call["function"]["name"], call["function"]["arguments"]
    elif provider == "anthropic":
        name, raw = call["name"], call["input"]
    else:
        name, raw = call["name"], call["arguments"]
    try:
        arguments = json.loads(raw) if isinstance(raw, str) else raw
        if name not in BY_NAME or not isinstance(arguments, dict):
            raise SaycutError("invalid_tool_call", "Expected a registered tool and object arguments")
        # Partial edits must preserve omitted fields instead of turning them into explicit nulls.
        arguments = BY_NAME[name].model.model_validate(arguments).model_dump(mode="json", exclude_unset=True)
        if not BY_NAME[name].readonly and (approve is None or not approve(name, arguments)):
            raise SaycutError("approval_required", "Host/user approval is required for this operation", 403)
        result = execute(name, arguments)
    except SaycutError as exc:
        result = exc.payload()
    except ValueError:
        result = {"error": {"code": "invalid_arguments", "message": "Tool arguments do not match the schema"}}
    serialized = json.dumps(result, ensure_ascii=False, allow_nan=False)
    if provider in CHAT_PROVIDERS:
        return {"role": "tool", "tool_call_id": call["id"], "content": serialized}
    if provider == "anthropic":
        return {
            "type": "tool_result",
            "tool_use_id": call["id"],
            "content": serialized,
            "is_error": set(result) == {"error"},
        }
    if provider == "gemini_interactions":
        return {
            "type": "function_result",
            "name": name,
            "call_id": call["id"],
            "result": [{"type": "text", "text": serialized}],
        }
    return {"type": "function_call_output", "call_id": call["call_id"], "output": serialized}
