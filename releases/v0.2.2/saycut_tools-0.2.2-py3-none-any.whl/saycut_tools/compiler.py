from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from .catalog import Catalog
from .config import Settings, write_json
from .errors import SaycutError
from .models import ProjectSpec
from .store import Store
from .text_style import layout_defaults


def caption_words(caption):
    result, cursor = [], 0
    for word in caption.words:
        text = word.text.strip()
        position = caption.text.find(text, cursor)
        if position >= 0:
            gap = caption.text[cursor:position]
            display = (gap if gap.isspace() else "") + text
            cursor = position + len(text)
        else:
            display = word.text
        result.append(
            {
                "word": display,
                "start_ms": round((word.start - caption.start) * 1000),
                "end_ms": round((word.end - caption.start) * 1000),
            }
        )
    return result


def compile_project(
    settings: Settings, store: Store, tenant: str, spec: ProjectSpec, folder: Path
) -> Path:
    catalog = Catalog(settings)
    tracks = []
    media = folder / "inputs"
    media.mkdir(parents=True, exist_ok=True)
    background = media / "background.png"
    subprocess.run(
        [
            settings.ffmpeg,
            "-v",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "color=black:s=64x64",
            "-frames:v",
            "1",
            str(background),
        ],
        check=True,
        capture_output=True,
        timeout=30,
    )
    tracks.append(
        [
            {
                "res": str(background),
                "type": "image",
                "startTime": 0.0,
                "duration": spec.duration,
                "positionType": "relative",
                "positionX": 0,
                "positionY": 0,
                "params": {"width": spec.width, "height": spec.height, "fillmode": 1},
            }
        ]
    )
    for clip in spec.clips:
        asset = store.asset(tenant, clip.asset_id)
        source = Path(asset["path"])
        local = media / (clip.asset_id + source.suffix)
        if not local.exists():
            shutil.copy2(source, local)
        tracks.append(
            [
                {
                    "res": str(local),
                    "type": asset["kind"],
                    "startTime": clip.start,
                    "duration": clip.duration,
                    "positionType": "relative",
                    "positionX": 0,
                    "positionY": 0,
                    "params": {
                        "width": spec.width,
                        "height": spec.height,
                        "fillmode": 1,
                        "speed": 1,
                        "volume": clip.volume,
                        "trimStartTime": clip.source_start,
                    },
                }
            ]
        )
    for caption_index, caption in enumerate(spec.captions):
        identifier = caption.style_id or spec.style_id
        overrides = {**spec.effect_params, **caption.effect_params}
        entry = catalog.validate(identifier, overrides)
        source = catalog.path(identifier)
        effect_dir = folder / "effects" / f"caption_{caption_index:04d}"
        # Keep each caption's binding files independent even when the same effect is reused.
        shutil.copytree(source.parent, effect_dir)
        params = layout_defaults(entry, spec.width)
        suffixes = entry.get("label_suffixes", [""])
        if any(slot not in suffixes for slot in caption.slots):
            raise SaycutError("invalid_text_slot", f"Allowed slots for {identifier}: {suffixes}")
        duration = caption.end - caption.start
        words = caption_words(caption)
        binding = {
            "words": words,
            "sentence": caption.text,
            "start_ms": 0,
            "end_ms": round(duration * 1000),
            "keywords": caption.keywords,
            "sub_index": 0,
        }
        write_json(effect_dir / "res/asr.json", binding)
        write_json(
            effect_dir / "res/lyriconfig.json",
            {
                "text": caption.text,
                "timestamp": [0, round(duration * 1000)],
                "sentences": [
                    {
                        "sentence": caption.text,
                        "timestamp": [0, round(duration * 1000)],
                        "keywords": [{"word": word} for word in caption.keywords],
                    }
                ],
            },
        )
        for index, suffix in enumerate(suffixes):
            for prefix in sorted({key.split(":")[0] for key in params}):
                text_key = f"{prefix}:Text{suffix}"
                if text_key not in params:
                    continue
                text = caption.slots.get(suffix, caption.text if index == 0 else "")
                params[text_key] = text
                overrides = {
                    "AsrPath": "res/asr.json",
                    "LyricPath": "res/lyriconfig.json",
                }
                for key, value in overrides.items():
                    target = f"{prefix}:{key}{suffix}"
                    if target in params:
                        params[target] = value
                if spec.font_asset_id:
                    asset = store.asset(tenant, spec.font_asset_id)
                    font = Path(asset["path"])
                    destination = effect_dir / "res" / ("user-font" + font.suffix)
                    shutil.copy2(font, destination)
                    params[f"{prefix}:CustomFontPath{suffix}"] = destination.relative_to(
                        effect_dir
                    ).as_posix()
        for key, value in list(params.items()):
            if "CustomFontPath" in key and value and not (effect_dir / value).is_file():
                fallback = settings.fallback_font
                if not fallback or not fallback.is_file():
                    raise SaycutError(
                        "font_missing",
                        "Effect font is missing; configure a licensed fallback_font",
                    )
                destination = effect_dir / "res" / ("fallback-font" + fallback.suffix)
                shutil.copy2(fallback, destination)
                params[key] = destination.relative_to(effect_dir).as_posix()
        params.update(spec.effect_params)
        params.update(caption.effect_params)
        # Unbound slots must not retain demo captions or ASR records from the resource pack.
        for path in (effect_dir / "res").glob("asr*.json"):
            write_json(path, binding)
        tracks.append(
            [
                {
                    "res": str(effect_dir / source.name),
                    "type": "effect",
                    "startTime": caption.start,
                    "duration": duration,
                    "params": {"ofParams": params},
                }
            ]
        )
    config = folder / "layers.json"
    write_json(config, {"width": spec.width, "height": spec.height, "layer": tracks})
    write_json(folder / "project.json", spec.model_dump(mode="json"))
    return config


def portable_bundle(folder: Path, spec: ProjectSpec) -> dict:
    """Package the native project, retaining its own relative asset layout."""
    template = folder / "native-project"
    skies = sorted(template.rglob("*.sky"))
    if not skies:
        raise SaycutError("native_project_missing", "Renderer did not produce an editable SkyMedia project")
    for path in skies:
        data = json.loads(path.read_text())

        def relative(value):
            if isinstance(value, dict):
                return {key: relative(item) for key, item in value.items()}
            if isinstance(value, list):
                return [relative(item) for item in value]
            if isinstance(value, str) and value.startswith(str(template) + "/"):
                return Path(value).relative_to(template).as_posix()
            return value

        write_json(path, relative(data))
    manifest = {
        "format": "saycut-editable-bundle",
        "version": 1,
        "project": spec.model_dump(mode="json"),
        "sky_json_path": skies[0].relative_to(template).as_posix(),
        "binding": "relative_to_native_project_root",
        "files": [p.relative_to(template).as_posix() for p in sorted(template.rglob("*")) if p.is_file()],
    }
    write_json(template / "saycut-manifest.json", manifest)
    archive = shutil.make_archive(str(folder / "editable-project"), "zip", template)
    return {"bundle": str(Path(archive).resolve()), "sky_json": str(skies[0].resolve()), "manifest": manifest}
