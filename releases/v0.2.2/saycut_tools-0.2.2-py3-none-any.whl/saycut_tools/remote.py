"""A stdio bridge for hosts without remote MCP support. Never silently upload local media."""

import hashlib
import json
from pathlib import Path

from .catalog import digest
from .client import SaycutClient
from .config import write_json
from .errors import SaycutError
from .worker import try_lock


class RemoteService:
    def __init__(self, settings, base_url, token):
        self.settings = settings
        self.client = SaycutClient(base_url, token)
        self.scope = hashlib.sha256((base_url + "\n" + token).encode()).hexdigest()

    def __getattr__(self, name):
        def invoke(args=None, **context):
            values = args.model_dump(mode="json", exclude_unset=True) if args is not None else {}
            if name == "render_video" and values.get("path"):
                if not values.get("allow_cloud_processing"):
                    raise SaycutError(
                        "cloud_consent_required", "Obtain permission before uploading this local video", 403
                    )
                path = Path(values["path"]).expanduser().resolve()
                if (
                    not any(path.is_relative_to(root) for root in self.settings.allowed_roots)
                    or not path.is_file()
                ):
                    raise SaycutError(
                        "local_access_denied", "Selected file is outside the configured allowed_roots", 403
                    )
                if path.stat().st_size > self.settings.max_asset_bytes:
                    raise SaycutError("asset_too_large", "Video exceeds the configured upload limit", 413)
                key = hashlib.sha256((self.scope + values["idempotency_key"]).encode()).hexdigest()
                cache = self.settings.data_dir / "remote-uploads" / (key + ".json")
                cache.parent.mkdir(parents=True, exist_ok=True)
                fingerprint = hashlib.sha256(
                    (json.dumps(values, sort_keys=True) + digest(path)).encode()
                ).hexdigest()
                acquired = try_lock(cache.with_suffix(".lock"))
                if not acquired:
                    raise SaycutError("upload_in_progress", "A matching upload is already running", 409, True)
                with acquired:
                    if cache.exists():
                        asset = json.loads(cache.read_text())
                        if asset["fingerprint"] != fingerprint:
                            raise SaycutError(
                                "idempotency_conflict",
                                "This key was used for different media or arguments",
                                409,
                            )
                    else:
                        asset = {**self.client.upload(path), "fingerprint": fingerprint}
                        write_json(cache, asset)
                values.update(path=None, asset_id=asset["asset_id"])
            return self.client.call("saycut_" + name, values)

        return invoke
