from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from .assets import probe
from .compiler import compile_project, portable_bundle
from .config import Settings, write_json
from .errors import SaycutError
from .license_adapter import child_environment
from .models import ProjectSpec
from .store import Store


def spawn(settings: Settings, tenant: str, job_id: str):
    folder = settings.data_dir / "jobs" / job_id
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    write_json(folder / "settings.json", settings.snapshot())
    with (folder / "worker.log").open("ab") as log:
        os.chmod(folder / "worker.log", 0o600)
        subprocess.Popen(
            [
                sys.executable,
                *(["-I"] if settings.account_enabled else []),
                "-m",
                "saycut_tools.worker",
                str(folder),
                tenant,
                job_id,
            ],
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=log,
            start_new_session=True,
            env=child_environment()
            if settings.account_enabled
            else {k: v for k, v in os.environ.items() if k not in {"SAYCUT_API_TOKENS", "SAYCUT_TOKEN"}},
        )


def try_lock(path):
    stream = path.open("a+b")
    try:
        if os.name == "nt":
            import msvcrt

            if path.stat().st_size == 0:
                stream.write(b"\0")
                stream.flush()
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return stream
    except OSError:
        stream.close()
        return None


def terminate(child):
    if child.poll() is not None:
        return
    if os.name == "nt":
        import psutil

        try:
            for process in psutil.Process(child.pid).children(recursive=True):
                try:
                    process.kill()
                except psutil.NoSuchProcess:
                    pass
            child.kill()
        except psutil.NoSuchProcess:
            pass
    else:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    child.wait(timeout=10)


def run(folder: Path, tenant: str, job_id: str):
    settings = Settings.model_validate_json((folder / "settings.json").read_text())
    store = Store(settings.data_dir)
    ownership = try_lock(folder / "worker.lock")
    if not ownership:
        return
    slot, child = None, None
    try:
        job = store.job(tenant, job_id)
        if job["status"] == "running":
            store.update_job(
                tenant,
                job_id,
                status="failed",
                error={
                    "code": "worker_interrupted",
                    "message": "Worker stopped unexpectedly; retry with a new idempotency key",
                },
            )
            return
        if job["status"] != "queued":
            return
        while not slot:
            job = store.job(tenant, job_id)
            if job["cancel_requested"]:
                store.update_job(tenant, job_id, status="cancelled")
                return
            for index in range(settings.concurrency):
                slot = try_lock(settings.data_dir / f"slot-{index}.lock")
                if slot:
                    break
            if not slot:
                store.update_job(tenant, job_id)
                time.sleep(0.5)
        if not store.update_job(tenant, job_id, status="running", claim=True):
            return
        from .account import require_account

        require_account(settings)
        spec = ProjectSpec.model_validate(
            store.project(tenant, job["project_id"], job["revision"])["project"]
        )
        project_id, revision = job["project_id"], job["revision"]
        request = job.get("request") or {}
        if request.get("transcribe"):
            video = store.asset(tenant, spec.clips[0].asset_id)["path"]
            write_json(
                folder / "asr-request.json",
                {
                    "settings": settings.snapshot(),
                    "video": video,
                    "language": request.get("language"),
                    "consent": request.get("consent", False),
                },
            )
            with (folder / "asr.log").open("wb") as log:
                child = subprocess.Popen(
                    [
                        sys.executable,
                        *(["-I"] if settings.account_enabled else []),
                        "-m",
                        "saycut_tools.asr",
                        str(folder),
                    ],
                    stdin=subprocess.DEVNULL,
                    stdout=log,
                    stderr=log,
                    start_new_session=True,
                    env=child_environment() if settings.account_enabled else None,
                )
                started = time.monotonic()
                while child.poll() is None:
                    if store.job(tenant, job_id)["cancel_requested"]:
                        terminate(child)
                        store.update_job(tenant, job_id, status="cancelled")
                        return
                    if time.monotonic() - started > settings.asr_timeout:
                        terminate(child)
                        raise SaycutError("asr_timeout", "Speech recognition exceeded its time limit")
                    store.update_job(tenant, job_id, progress=0.01)
                    time.sleep(0.5)
            if child.returncode:
                error_path = folder / "asr-error.json"
                error = (
                    json.loads(error_path.read_text())
                    if error_path.exists()
                    else {"code": "asr_failed", "message": "Speech recognition worker exited"}
                )
                store.update_job(tenant, job_id, status="failed", error=error)
                return
            cues = json.loads((folder / "asr-result.json").read_text())["captions"]
            from .asr import fit_media_end

            cues = fit_media_end(cues, spec.duration)
            spec = ProjectSpec.model_validate({**spec.model_dump(), "captions": cues})
            from .service import Service

            Service(settings).validate_project(tenant, spec)
            generated = store.save_project(tenant, spec.model_dump(mode="json"), project_id, revision)
            revision = generated["revision"]
        from .service import Service

        validation = Service(settings).validate_project(tenant, spec)
        compile_project(settings, store, tenant, spec, folder)
        started = time.monotonic()
        with (folder / "native.log").open("wb") as log:
            child = subprocess.Popen(
                [
                    sys.executable,
                    *(["-I"] if settings.account_enabled else []),
                    "-m",
                    "saycut_tools.native",
                    str(folder),
                ],
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=log,
                start_new_session=True,
                env=child_environment() if settings.account_enabled else None,
            )
            while child.poll() is None:
                if store.job(tenant, job_id)["cancel_requested"]:
                    terminate(child)
                    store.update_job(tenant, job_id, status="cancelled")
                    return
                if time.monotonic() - started > settings.render_timeout:
                    terminate(child)
                    raise SaycutError(
                        "render_timeout", "Local render exceeded its configured timeout", retryable=True
                    )
                progress_file = folder / "progress.json"
                progress = (
                    json.loads(progress_file.read_text()).get("progress", 0) if progress_file.is_file() else 0
                )
                if progress > 1:
                    progress /= 100
                store.update_job(tenant, job_id, progress=min(0.99, max(0, progress)))
                time.sleep(0.5)
        if child.returncode:
            error_path = folder / "native-error.json"
            error = (
                json.loads(error_path.read_text())
                if error_path.is_file()
                else {"code": "native_crash", "message": "Native renderer exited unexpectedly"}
            )
            store.update_job(tenant, job_id, status="failed", error=error)
            return
        media = probe(folder / "video.mp4", settings.ffprobe)
        if media["kind"] != "video" or abs(media["duration"] - spec.duration) > max(0.2, 2 / spec.fps):
            raise SaycutError(
                "output_validation_failed", "Rendered duration does not match the project timeline"
            )
        if media["width"] != spec.width or media["height"] != spec.height:
            raise SaycutError("output_validation_failed", "Rendered dimensions do not match the project")
        if media["fps"] is None or abs(media["fps"] - spec.fps) > 0.01:
            raise SaycutError("output_validation_failed", "Rendered frame rate does not match the project")
        bundle = portable_bundle(folder, spec)
        store.update_job(
            tenant,
            job_id,
            status="succeeded",
            progress=1,
            result={
                "project_id": project_id,
                "revision": revision,
                "video": str(folder / "video.mp4"),
                "bundle": bundle["bundle"],
                "sky_json": bundle["sky_json"],
                "media": media,
                "warnings": validation.get("warnings", []),
                "warning_count": validation.get("warning_count", 0),
                "usage": {
                    "output_seconds": media["duration"],
                    "render_wall_seconds": round(time.monotonic() - started, 3),
                    "backend": "template_generator",
                    "charge": None,
                },
                "timing_basis": "word"
                if spec.captions and all(c.words for c in spec.captions)
                else "sentence",
            },
        )
    except Exception as exc:  # noqa: BLE001 - persist terminal failure even when the native SDK crashes
        error = (
            exc.payload()["error"]
            if isinstance(exc, SaycutError)
            else {
                "code": "worker_failed",
                "message": f"Worker failed ({type(exc).__name__}); see private worker logs",
            }
        )
        store.update_job(tenant, job_id, status="failed", error=error)
    finally:
        if child:
            terminate(child)
        if slot:
            slot.close()
        ownership.close()


if __name__ == "__main__":
    os.umask(0o077)
    run(Path(sys.argv[1]), sys.argv[2], sys.argv[3])
