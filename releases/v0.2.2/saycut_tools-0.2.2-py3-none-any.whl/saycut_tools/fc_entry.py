"""One FC runtime for the HTTP gateway and authenticated timer invocations."""

import json
import logging
import secrets
import time

from starlette.concurrency import run_in_threadpool
from starlette.responses import JSONResponse
from starlette.middleware.wsgi import WSGIMiddleware
from videocut_account.app import create_account_app
from videocut_account.config import load_config
from videocut_account.readiness import verify_storage

from .config import Settings
from .http import create_app
from .service import create_service

LOGGER = logging.getLogger(__name__)


class RequestLogging:
    """Log route templates and timings, never tokens, query strings or media URLs."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        started, status = time.monotonic(), 500

        async def logged_send(message):
            nonlocal status
            if message["type"] == "http.response.start":
                status = message["status"]
            await send(message)

        try:
            await self.app(scope, receive, logged_send)
        finally:
            route = getattr(scope.get("route"), "path", None)
            if not route:
                path = scope.get("path")
                route = path if path in {"/mcp", "/invoke", "/health"} else "unmatched"
            method = scope.get("method")
            if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}:
                method = "OTHER"
            LOGGER.info("request_completed %s", json.dumps({
                "method": method, "route": route, "status": status,
                "duration_ms": round((time.monotonic() - started) * 1000, 1),
            }))


class TimerGateway:
    def __init__(self, app, service, token):
        self.app, self.service, self.token = app, service, token

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["path"] != "/invoke":
            return await self.app(scope, receive, send)
        status, result = 401, {"error": "invalid_timer_authorization"}
        if scope["method"] != "POST":
            status, result = 405, {"error": "method_not_allowed"}
        else:
            try:
                body = b""
                while True:
                    message = await receive()
                    if message["type"] == "http.disconnect":
                        return
                    body += message.get("body", b"")
                    if len(body) > 4096:
                        return await JSONResponse({"error": "request_too_large"}, 413)(scope, receive, send)
                    if not message.get("more_body"):
                        break
                event = json.loads(body)
                payload = json.loads(event["payload"])
                token = payload.get("token")
                authorized = (
                    event.get("triggerName") == "reconcileEveryMinute"
                    and payload.get("action") == "reconcile"
                    and isinstance(token, str)
                    and bool(self.token)
                    and secrets.compare_digest(token.encode(), self.token.encode())
                )
            except (ValueError, TypeError, KeyError, AttributeError):
                authorized = False
            if authorized:
                try:
                    result = await run_in_threadpool(self.service.reconcile)
                    status = 200
                    LOGGER.info("reconciliation_completed examined=%s", result.get("examined"))
                except Exception:
                    LOGGER.error("reconciliation_failed")
                    status, result = 500, {"error": "reconciliation_failed"}
        return await JSONResponse(result, status)(scope, receive, send)


class AccountGateway:
    def __init__(self, app, account):
        self.app, self.account = app, WSGIMiddleware(account)

    async def __call__(self, scope, receive, send):
        if scope['type'] == 'http' and scope['path'].startswith('/mcp/v1/'):
            return await self.account(scope, receive, send)
        return await self.app(scope, receive, send)


def web():
    if not LOGGER.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        LOGGER.addHandler(handler)
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False
    LOGGER.info("service_starting")
    try:
        config = load_config()
        verify_storage(config)
        settings = Settings.model_validate({**config['cloud'], 'data_dir': '/tmp/videocut-chat'})
        settings.data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        service = create_service(settings)
    except Exception:
        LOGGER.error('service_initialization_failed')
        raise RuntimeError('Service configuration or storage unavailable; inspect private configuration') from None
    token = config['reconcile_token']
    if len(token) < 32:
        raise RuntimeError("A private SAYCUT_RECONCILE_TOKEN is required for the unified FC runtime")
    app = RequestLogging(AccountGateway(
        TimerGateway(create_app(settings, service), service, token), create_account_app(config['account'])))
    LOGGER.info("service_initialized backend=%s", settings.backend)
    return app
