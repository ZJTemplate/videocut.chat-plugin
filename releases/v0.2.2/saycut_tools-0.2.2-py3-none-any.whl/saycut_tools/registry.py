from __future__ import annotations

import inspect
import json
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Annotated, Any

from pydantic import Field, ValidationError

from . import models as m
from .errors import SaycutError
from .service import Service

TENANT = ContextVar("saycut_tenant", default=None)


@dataclass(frozen=True)
class Operation:
    method: str
    model: type[m.Model]
    description: str
    readonly: bool = False
    idempotent: bool = False

    @property
    def name(self):
        return "saycut_" + self.method


OPERATIONS = [
    Operation(
        "render_template",
        m.RenderTemplate,
        "Cloud only: render an administrator-registered native template using asset IDs for its resource slots. "
        "Read template IDs and required slots from capabilities. Requires explicit cloud consent.",
        idempotent=True,
    ),
    Operation(
        "render_attachment",
        m.RenderAttachment,
        "Caption an authorized chat file attachment. Omit captions for ASR; select a discovered style. "
        "Cloud processing requires consent. Returns a job_id to poll with get_job.",
        idempotent=True,
    ),
    Operation(
        "render_video",
        m.RenderVideo,
        "Add fancy subtitles to one video in a single asynchronous job. Omit captions for real ASR. "
        "Accept one local path, URL, asset_id or authorized file. Cloud processing requires user consent. "
        "Reuse idempotency_key on retries, then poll get_job.",
        idempotent=True,
    ),
    Operation(
        "prepare_upload",
        m.UploadRequest,
        "Cloud only: obtain a restricted OSS direct-upload grant. Upload the file bytes, then complete_upload.",
    ),
    Operation(
        "complete_upload",
        m.AssetRef,
        "Cloud only: verify the uploaded object's size and register its asset_id.",
        idempotent=True,
    ),
    Operation(
        "capabilities",
        m.Empty,
        "Check the active backend, rendering prerequisites, supported operations, enabled styles and limits. Does not validate the license.",
        True,
    ),
    Operation(
        "list_styles",
        m.ListStyles,
        "Search installed text styles by name or tags such as 花字, 字幕, 动态字幕, flower, outline. Returned tags derive from resource metadata, not visual review. Use IDs from this list, never invent them.",
        True,
    ),
    Operation(
        "get_style",
        m.StyleRef,
        "Read resource defaults, documented native parameters and supported semantic controls. Resource defaults are not effective render values; use inspect_caption_style for a project's actual inputs.",
        True,
    ),
    Operation(
        "import_asset",
        m.ImportAsset,
        "Import a video, image, audio or font. Local paths require stdio/CLI allowed_roots; HTTP uses upload or enabled HTTPS URLs.",
    ),
    Operation(
        "parse_subtitles",
        m.ParseSubtitles,
        "Parse SRT/VTT/ASS into timed caption objects. Does not perform speech recognition or estimate word alignment.",
        True,
    ),
    Operation(
        "estimate",
        m.CreateProject,
        "Validate a composition and estimate local staging bytes, duration and pixel-frames. No charge is collected.",
        True,
    ),
    Operation(
        "enhance_video",
        m.EnhanceVideo,
        "Create an editable project adding fancy timed captions to an imported video. Call render_project afterwards.",
    ),
    Operation(
        "create_project",
        m.CreateProject,
        "Create a revisioned multi-track video project with timed captions and installed fancy-text styles.",
    ),
    Operation(
        "get_project",
        m.ProjectRef,
        "Read a project and its revision. Asset IDs and style IDs remain stable across transports.",
        True,
    ),
    Operation(
        "edit_project",
        m.EditProject,
        "Patch captions with optimistic revision checking. effect_params replaces all project overrides; effect_params_patch merges instead (null removes a key). Caption patches support effect_params_patch. Prefer style_captions for color/size/position edits. Timing/text changes clear stale word alignment.",
    ),
    Operation(
        "inspect_caption_style",
        m.InspectCaptionStyle,
        "Local only: inspect one caption's effective render inputs after canvas, project and caption overrides, with supported semantic controls. Returns revision. Use before relative font-size changes; no render is performed.",
        True,
    ),
    Operation(
        "style_captions",
        m.StyleCaptions,
        "Local only: change explicitly selected captions using #RRGGBB colors, font_size, scale_by (1.2 = 20% larger), position, x/y, opacity or first-outline width. Preserves unrelated overrides and captions; expected_revision prevents applying relative changes twice. Returns effective values, not a rendered video; call render_project next.",
    ),
    Operation(
        "update_project",
        m.ReplaceProject,
        "Replace the complete composition, including clips and captions, using expected_revision.",
    ),
    Operation(
        "render_project",
        m.RenderProject,
        "Start an asynchronous render on the configured local or callback_v1 backend. Reuse the same idempotency key on retries. Returns job_id, not a finished video.",
        idempotent=True,
    ),
    Operation(
        "get_job",
        m.JobRef,
        "Poll job state. A succeeded job includes available downloads; legacy GenVideo returns MP4 only. Follow downloads_require_bearer_token; never send gateway credentials to signed URLs.",
        True,
    ),
    Operation(
        "cancel_job",
        m.JobRef,
        "Cancel a queued/running job. Local workers terminate owned subprocesses; cloud gateways forward cancellation to GenVideo. Completed jobs are unchanged.",
        idempotent=True,
    ),
    Operation(
        "job_events",
        m.EventCursor,
        "Read durable tenant-scoped job status events after a cursor, for n8n/Make/Zapier polling triggers.",
        True,
    ),
    Operation(
        "editor_handoff",
        m.EditorHandoff,
        "Issue a short-lived read-only link for one rendered native project. The hosted editor needs the supplied bridge installed.",
    ),
]
ACCOUNT_OPERATIONS = [
    Operation(
        "account_login",
        m.Empty,
        "Local only: request Saycut account authorization. Show the URL and code to the user; never approve on their behalf.",
    ),
    Operation(
        "account_complete_login",
        m.Empty,
        "Local only: check an existing authorization request. If pending, respect the returned polling interval.",
    ),
    Operation(
        "account_status",
        m.Empty,
        "Local only: check the connected account and local-render entitlement online. Never returns credentials.",
        True,
    ),
    Operation(
        "account_logout",
        m.Empty,
        "Local only: revoke this plugin connection and remove its saved account credentials.",
        idempotent=True,
    ),
]
BY_NAME = {operation.name: operation for operation in [*OPERATIONS, *ACCOUNT_OPERATIONS]}


def invoke(service: Service, name: str, arguments: dict, tenant: str, local_access=False):
    if name not in BY_NAME:
        raise SaycutError("unknown_tool", "Unknown Saycut operation", 404)
    if name in {operation.name for operation in ACCOUNT_OPERATIONS} and (
        not local_access or not isinstance(service, Service)
    ):
        raise SaycutError("local_only", "Account credentials belong to the local plugin", 403)
    try:
        payload = BY_NAME[name].model.model_validate(arguments)
        return getattr(service, BY_NAME[name].method)(payload, tenant=tenant, local_access=local_access)
    except ValidationError as exc:
        raise SaycutError("validation_error", str(exc)[:3000], 422) from exc


def flat_handler(service: Service, operation: Operation, local=False):
    """Present the same top-level arguments to the SDK without generated Python source."""

    def handler(**kwargs) -> dict[str, Any]:
        tenant = "local" if local else TENANT.get()
        if tenant is None:
            raise SaycutError("unauthorized", "Authentication required", 401)
        try:
            return invoke(service, operation.name, kwargs, tenant, local)
        except SaycutError as exc:
            from mcp.server.mcpserver.exceptions import ToolError

            raise ToolError(json.dumps(exc.payload(), ensure_ascii=False)) from exc

    handler.__name__ = operation.name
    parameters = []
    for name, field in operation.model.model_fields.items():
        annotation = Annotated[field.annotation, Field(description=field.description), *field.metadata]
        default = (
            inspect.Parameter.empty
            if field.is_required()
            else field.get_default(call_default_factory=True)
        )
        parameters.append(
            inspect.Parameter(
                name,
                inspect.Parameter.KEYWORD_ONLY,
                default=default,
                annotation=annotation,
            )
        )
    handler.__signature__ = inspect.Signature(parameters, return_annotation=dict[str, Any])
    return handler
