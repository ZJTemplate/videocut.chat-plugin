"""The existing Ryry task wire protocol, without importing its desktop runtime."""

from __future__ import annotations

import json
import os

import httpx

from .errors import SaycutError


class AigcClient:
    def __init__(self, settings, client=None):
        headers = {}
        token = settings.aigc_token or os.environ.get("SAYCUT_AIGC_TOKEN")
        usertoken = settings.aigc_usertoken or os.environ.get("SAYCUT_AIGC_USERTOKEN")
        if token:
            headers["Authorization"] = "Bearer " + token
        if usertoken:
            headers["Usertoken"] = usertoken
        self.settings = settings
        self.client = client or httpx.Client(
            base_url=settings.aigc_base_url.rstrip("/"),
            headers=headers,
            timeout=15,
            follow_redirects=False,
            trust_env=False,
        )

    def call(self, method, payload):
        try:
            response = self.client.post("/aigc/task/" + method, json=payload)
            response.raise_for_status()
            body = response.json()
            if not isinstance(body, dict):
                raise TypeError("Invalid AIGC response")
            if body.get("code") != 0:
                raise SaycutError("aigc_rejected", "AIGC rejected the request; check server credentials", 502)
            return body["data"]
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            # A timed-out create may already have reached the queue; callers must not blindly retry it.
            raise SaycutError(
                "aigc_unavailable",
                "AIGC response unavailable; submission may already have reached the queue",
                503,
                True,
            ) from exc

    def submit(self, payload):
        payload = dict(payload)
        if "domain" not in payload:
            import datetime

            payload["domain"] = "https://upload.zjtemplate.com/temp/" + datetime.datetime.now(
                datetime.UTC
            ).strftime("%Y/%m/%d/%H/")
        request = {
            "widget_name": self.settings.aigc_widget_name,
            "widget_data": json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            "extend": json.dumps(
                self.settings.aigc_extend
                or {"app": "saycut-tools", "device": "aliyun fc", "platform": "fc 3.0"}
            ),
        }
        if self.settings.aigc_widget_version:
            request.update(
                widget_version=self.settings.aigc_widget_version, version=self.settings.aigc_widget_version
            )
        identifier = self.call("createTask", request)
        if not isinstance(identifier, str) or not identifier or len(identifier) > 200:
            raise SaycutError("aigc_response_invalid", "AIGC returned an invalid task identifier", 502)
        return identifier

    def check(self, identifier):
        detail = self.call("checkTask", {"task_uuid": identifier})
        if not isinstance(detail, dict) or "status" not in detail:
            raise SaycutError("aigc_response_invalid", "AIGC returned invalid task details", 502, True)
        return detail

    def cancel(self, identifier):
        return self.call("taskCancel", {"task_uuid": identifier})
