from __future__ import annotations

import hashlib
import importlib.util
import json
import secrets
import shutil
import time
from pathlib import Path
from urllib.parse import urlencode, urlsplit

import pysubs2

from . import __version__
from . import models as m
from .account import AccountClient, require_account
from .assets import Assets
from .catalog import Catalog
from .config import Settings
from .errors import SaycutError
from .native import native_binary
from .store import Store
from .text_style import appearance_patch, effective_params, inspection, visual_warnings
from .worker import spawn, try_lock


def create_service(settings):
    if settings.backend == "cloud":
        if settings.aigc_protocol == "legacy":
            from .legacy import LegacyCloudService

            return LegacyCloudService(settings)
        from .cloud import CloudService

        return CloudService(settings)
    return Service(settings)


class Service:
    def _account_operation(self, method, local_access=False, **context):
        if not local_access or self.settings.backend != "local":
            raise SaycutError("local_only", "Account credentials belong to the local plugin", 403)
        with AccountClient(self.settings) as account:
            return getattr(account, method)()

    def account_login(self, args, **context):
        return self._account_operation("start_login", **context)

    def account_complete_login(self, args, **context):
        return self._account_operation("complete_login", **context)

    def account_status(self, args, **context):
        return self._account_operation("status", **context)

    def account_logout(self, args, **context):
        return self._account_operation("logout", **context)

    def render_template(self, args, tenant, **context):
        raise SaycutError("cloud_only", "Registered GenVideo templates are available on the cloud gateway")

    def __init__(self, settings: Settings):
        self.settings = settings
        self.store = Store(settings.data_dir)
        self.assets = Assets(settings, self.store)
        self.catalog = Catalog(settings)

    def capabilities(self, args=None, **context):
        try:
            native_binary(self.settings)
            runtime = True
        except SaycutError:
            runtime = False
        sdk = bool(
            importlib.util.find_spec("template_generator") or self.settings.template_generator_source
        )
        ffmpeg, ffprobe = (
            bool(shutil.which(self.settings.ffmpeg)),
            bool(shutil.which(self.settings.ffprobe)),
        )
        available = self.catalog.list(limit=1, available_only=True)["total"]
        missing = [
            name
            for name, present in (
                ("runtime_missing", runtime),
                ("sdk_missing", sdk),
                ("ffmpeg_missing", ffmpeg),
                ("ffprobe_missing", ffprobe),
                ("styles_missing", available > 0),
            )
            if not present
        ]
        asr_dependency = {
            "disabled": False,
            "faster_whisper": bool(importlib.util.find_spec("faster_whisper")),
            "ryry": bool(importlib.util.find_spec("ryry")),
        }[self.settings.asr_backend]
        return {
            "version": __version__,
            "backend": "template_generator",
            "runtime_configured": runtime,
            "sdk_installed": sdk,
            "license_file_present": (
                self.settings.data_dir / "private/sdk/license.txt"
                if self.settings.account_enabled
                else Path.home() / ".config/template_generator/license.txt"
            ).is_file(),
            "license_validated": False,
            "account_authorization": self.settings.account_enabled,
            "styles": self.catalog.list(limit=1)["total"],
            "styles_installed": available,
            "semantic_caption_editing": True,
            "per_caption_parameters": True,
            "readiness": {
                "local_prerequisites_ready": not missing,
                "missing_prerequisites": missing,
                "asr_dependency_installed": asr_dependency,
                "asr_model_check": "not_checked",
                "account_check": "not_checked",
                "note": "Prerequisites only; verify account entitlement, selected style/fonts and ASR model before rendering",
            },
            "features": [
                "timed_captions",
                "fancy_text",
                "multitrack_composition",
                "native_project_export",
                "revisioned_edits",
                "semantic_caption_editing",
            ],
            "transcription": self.settings.asr_backend,
            "ffmpeg": ffmpeg,
            "ffprobe": ffprobe,
            "remote_urls": self.settings.allow_remote_urls,
            "sdk_telemetry": self.settings.sdk_telemetry,
            "limits": {
                "max_duration": self.settings.max_duration,
                "max_asset_bytes": self.settings.max_asset_bytes,
                "concurrency": self.settings.concurrency,
            },
            "editor_bridge_enabled": self.settings.editor_bridge_enabled,
        }

    def list_styles(self, args: m.ListStyles, **context):
        return self.catalog.list(**args.model_dump())

    def get_style(self, args: m.StyleRef, **context):
        return self.catalog.get(args.style_id)

    def import_asset(self, args: m.ImportAsset, tenant, local_access=False):
        return self.assets.import_asset(tenant, **args.model_dump(), local_access=local_access)

    def render_video(self, args: m.RenderVideo, tenant, local_access=False):
        native_binary(self.settings)
        fingerprint = hashlib.sha256(
            json.dumps(args.model_dump(mode="json"), sort_keys=True, ensure_ascii=False).encode()
        ).hexdigest()
        key_hash = hashlib.sha256((tenant + ":" + args.idempotency_key).encode()).hexdigest()
        lock = try_lock(self.settings.data_dir / ("submit-" + key_hash + ".lock"))
        if not lock:
            raise SaycutError(
                "submission_busy", "This submission is in progress; retry the same key", 409, True
            )
        try:
            previous = self.store.job_by_key(tenant, args.idempotency_key)
            if previous:
                if (previous.get("request") or {}).get("fingerprint") != fingerprint:
                    raise SaycutError("idempotency_conflict", "Key already used for another request", 409)
                return self.get_job(m.JobRef(job_id=previous["job_id"]), tenant, local_access)
            require_account(self.settings)
            if args.captions is None:
                if self.settings.asr_backend == "disabled":
                    raise SaycutError("asr_not_configured", "Configure ASR or provide timed captions")
                if self.settings.asr_backend == "ryry" and not args.allow_cloud_processing:
                    raise SaycutError(
                        "cloud_consent_required", "Remote ASR uploads audio; obtain consent", 403
                    )
            asset = (
                self.store.asset(tenant, args.asset_id)
                if args.asset_id
                else self.import_asset(
                    m.ImportAsset(
                        path=args.path,
                        url=args.file.download_url if args.file else args.url,
                        filename=(args.file.file_name or "source.mp4") if args.file else None,
                    ),
                    tenant,
                    local_access,
                )
            )
            if asset["kind"] != "video" or not asset.get("duration"):
                raise SaycutError("video_required", "The source must be a video with a known duration")
            if args.captions is None and asset.get("has_audio") is False:
                raise SaycutError("no_audio_stream", "This video has no audio track; provide timed captions instead of automatic transcription")
            spec = m.ProjectSpec(
                name=args.name,
                width=asset["width"] // 2 * 2,
                height=asset["height"] // 2 * 2,
                fps=asset.get("fps") or 30,
                duration=asset["duration"],
                clips=[m.Clip(asset_id=asset["asset_id"], duration=asset["duration"])],
                captions=args.captions or [],
                style_id=args.style_id,
                effect_params=args.effect_params,
            )
            self.catalog.validate(args.style_id, args.effect_params)
            project = self.create_project(m.CreateProject(project=spec), tenant)
            request = {
                "fingerprint": fingerprint,
                "transcribe": args.captions is None,
                "language": args.language,
                "consent": args.allow_cloud_processing,
            }
            job, _ = self.store.create_job(
                tenant,
                project["project_id"],
                project["revision"],
                args.idempotency_key,
                self.settings.max_active_jobs,
                request,
            )
            return self.public_job(self.start_worker(tenant, job["job_id"]), local_access)
        finally:
            lock.close()

    def render_attachment(self, args: m.RenderAttachment, tenant, local_access=False):
        return self.render_video(
            m.RenderVideo.model_validate(args.model_dump(mode="json")), tenant, local_access
        )

    def prepare_upload(self, args, **context):
        raise SaycutError("cloud_only", "Local HTTP clients use /v1/assets/upload; stdio uses import_asset")

    def complete_upload(self, args, **context):
        raise SaycutError("cloud_only", "Upload finalization is only needed for OSS direct uploads")

    def parse_subtitles(self, args: m.ParseSubtitles, **context):
        try:
            document = pysubs2.SSAFile.from_string(args.content, format_=args.format)
            captions = [
                m.Caption(
                    id=f"caption_{index}", text=line.plaintext, start=line.start / 1000, end=line.end / 1000
                )
                for index, line in enumerate(document)
                if not line.is_comment and line.plaintext.strip()
            ]
            if len(captions) > 1000:
                raise ValueError("At most 1000 captions per project")
        except (ValueError, pysubs2.exceptions.Pysubs2Error) as exc:
            raise SaycutError(
                "invalid_subtitles", "Could not parse bounded, positive-duration subtitle cues"
            ) from exc
        return {
            "captions": [caption.model_dump(mode="json") for caption in captions],
            "timing_basis": "sentence",
        }

    def validate_project(self, tenant, project: m.ProjectSpec):
        if project.duration > self.settings.max_duration:
            raise SaycutError("duration_limit", "Project exceeds max_duration")
        staging = 0
        sizes = {}
        warnings = []
        warning_count = 0
        font_asset = self.store.asset(tenant, project.font_asset_id) if project.font_asset_id else None
        if font_asset and font_asset["kind"] != "font":
            raise SaycutError("invalid_font", "font_asset_id must reference an imported font")
        for caption in project.captions:
            style_id = caption.style_id or project.style_id
            entry = self.catalog.validate(style_id, {**project.effect_params, **caption.effect_params})
            hints = visual_warnings(project, caption, effective_params(entry, project.width, project.effect_params, caption.effect_params))
            warning_count += len(hints)
            warnings.extend(hints[:max(0, 20 - len(warnings))])
            if self.catalog.missing_fonts(entry) and not project.font_asset_id:
                raise SaycutError(
                    "font_missing",
                    "Effect needs a font; import font_asset_id or configure fallback_font",
                )
            if any(slot not in entry.get("label_suffixes", [""]) for slot in caption.slots):
                raise SaycutError(
                    "invalid_text_slot",
                    "Caption slots must match the style's label_suffixes",
                )
            path = self.catalog.path(style_id)
            if path not in sizes:
                sizes[path] = sum(p.stat().st_size for p in path.parent.rglob("*") if p.is_file())
            staging += sizes[path]
            bound_fonts = {
                f"{prefix}:CustomFontPath{suffix}"
                for prefix in {key.split(":")[0] for key in entry["defaults"]}
                for suffix in entry.get("label_suffixes", [""])
                if font_asset and f"{prefix}:Text{suffix}" in entry["defaults"]
            }
            # The compiler copies user/fallback fonts into each independent caption effect directory.
            if bound_fonts:
                staging += font_asset["bytes"]
            if any(
                "CustomFontPath" in key and value and key not in bound_fonts
                and not (path.parent / value).is_file()
                for key, value in entry["defaults"].items()
            ):
                fallback = self.settings.fallback_font
                if not fallback or not fallback.is_file():
                    raise SaycutError("font_missing", "An effect slot needs a licensed fallback font")
                staging += fallback.stat().st_size
        for clip in project.clips:
            asset = self.store.asset(tenant, clip.asset_id)
            if asset["kind"] not in ("video", "image", "audio"):
                raise SaycutError(
                    "invalid_clip",
                    "Timeline clips require image, video or audio assets",
                )
            if (
                asset["kind"] != "image"
                and clip.source_start + clip.duration > asset["duration"] + 0.05
            ):
                raise SaycutError(
                    "clip_out_of_bounds",
                    "Clip source range exceeds the imported media duration",
                )
            staging += asset["bytes"]
        if staging * 2 > self.settings.max_staging_bytes:
            raise SaycutError(
                "staging_limit",
                "Project copies exceed max_staging_bytes; split into shorter projects",
            )
        return {
            "estimated_staging_bytes": staging * 2,
            "warnings": warnings,
            "warning_count": warning_count,
            "output_seconds": project.duration,
            "pixel_frames": project.width * project.height * project.fps * project.duration,
            "charge": None,
            "billing_mode": "local_unmetered",
            "native_license_required": True,
        }

    def estimate(self, args: m.CreateProject, tenant, **context):
        return self.validate_project(tenant, args.project)

    def create_project(self, args: m.CreateProject, tenant, **context):
        validation = self.validate_project(tenant, args.project)
        saved = self.store.save_project(tenant, args.project.model_dump(mode="json"))
        return {**saved, "warnings": validation.get("warnings", []), "warning_count": validation.get("warning_count", 0)}

    def enhance_video(self, args: m.EnhanceVideo, tenant, **context):
        asset = self.store.asset(tenant, args.asset_id)
        if asset["kind"] != "video" or asset["duration"] <= 0:
            raise SaycutError("video_required", "Enhance requires a video asset with a known duration")
        spec = m.ProjectSpec(
            name=args.name,
            width=asset["width"] // 2 * 2,
            height=asset["height"] // 2 * 2,
            fps=asset.get("fps") or 30,
            duration=asset["duration"],
            clips=[m.Clip(asset_id=args.asset_id, duration=asset["duration"])],
            captions=args.captions,
            style_id=args.style_id,
            effect_params=args.effect_params,
        )
        return self.create_project(m.CreateProject(project=spec), tenant)

    def get_project(self, args: m.ProjectRef, tenant, **context):
        return self.store.project(tenant, args.project_id, args.revision)

    def update_project(self, args: m.ReplaceProject, tenant, **context):
        self.store.project(tenant, args.project_id)
        validation = self.validate_project(tenant, args.project)
        saved = self.store.save_project(
            tenant, args.project.model_dump(mode="json"), args.project_id, args.expected_revision
        )
        return {**saved, "warnings": validation.get("warnings", []), "warning_count": validation.get("warning_count", 0)}

    def edit_project(self, args: m.EditProject, tenant, **context):
        current = self.store.project(tenant, args.project_id)
        if current["revision"] != args.expected_revision:
            raise SaycutError("revision_conflict", "Read the latest project before editing", 409)
        project = current["project"]
        captions = {caption["id"]: caption for caption in project["captions"]}
        for change in args.captions:
            if change.id not in captions:
                raise SaycutError("caption_not_found", "Caption ID not present in project", 404)
            patch = change.model_dump(exclude_unset=True, exclude={"id"})
            native_patch = patch.pop("effect_params_patch", None)
            if any(key in patch for key in ("text", "start", "end")) and "words" not in patch:
                patch["words"] = []
            captions[change.id].update(patch)
            if native_patch is not None:
                captions[change.id]["effect_params"] = self.merge_params(
                    captions[change.id].get("effect_params", {}), native_patch
                )
        if args.style_id is not None:
            project["style_id"] = args.style_id
        if args.effect_params is not None:
            project["effect_params"] = args.effect_params
        if args.effect_params_patch is not None:
            project["effect_params"] = self.merge_params(
                project.get("effect_params", {}), args.effect_params_patch
            )
        return self.update_project(
            m.ReplaceProject(
                project_id=args.project_id,
                expected_revision=args.expected_revision,
                project=m.ProjectSpec.model_validate(project),
            ),
            tenant,
        )

    @staticmethod
    def merge_params(existing, patch):
        values = {**existing, **patch}
        return {key: value for key, value in values.items() if value is not None}

    def require_style_controls(self):
        if self.settings.backend == "cloud":
            raise SaycutError(
                "worker_upgrade_required",
                "Semantic caption editing is local-only until the actual cloud worker supports per-caption overrides",
                409,
            )

    def inspect_caption_style(self, args: m.InspectCaptionStyle, tenant, **context):
        self.require_style_controls()
        current = self.store.project(tenant, args.project_id, args.revision)
        project = m.ProjectSpec.model_validate(current["project"])
        caption = next((c for c in project.captions if c.id == args.caption_id), None)
        if caption is None:
            raise SaycutError("caption_not_found", "Caption ID not present in project", 404)
        entry = self.catalog.get(caption.style_id or project.style_id)
        return {
            "project_id": args.project_id,
            "revision": current["revision"],
            **inspection(entry, project, caption),
        }

    def style_captions(self, args: m.StyleCaptions, tenant, **context):
        self.require_style_controls()
        current = self.store.project(tenant, args.project_id)
        if current["revision"] != args.expected_revision:
            raise SaycutError("revision_conflict", "Read the latest project before styling", 409)
        project = m.ProjectSpec.model_validate(current["project"])
        selected = set(args.caption_ids)
        if len(selected) != len(args.caption_ids) or selected - {c.id for c in project.captions}:
            raise SaycutError("invalid_caption_selection", "Use unique existing caption IDs")
        resolved = []
        for caption in project.captions:
            if caption.id not in selected:
                continue
            entry = self.catalog.get(caption.style_id or project.style_id)
            effective = effective_params(
                entry, project.width, project.effect_params, caption.effect_params
            )
            patch = appearance_patch(entry, effective, args.appearance, project.height)
            caption.effect_params.update(patch)
            if len(resolved) < 5:
                resolved.append(inspection(entry, project, caption))
        saved = self.update_project(
            m.ReplaceProject(
                project_id=args.project_id,
                expected_revision=args.expected_revision,
                project=project,
            ),
            tenant,
        )
        return {
            "project_id": saved["project_id"],
            "revision": saved["revision"],
            "changed_caption_ids": [c.id for c in project.captions if c.id in selected],
            "resolved_styles": resolved,
            "remaining_style_count": len(selected) - len(resolved),
            "warnings": saved.get("warnings", []),
            "warning_count": saved.get("warning_count", 0),
            "inspect_tool": "saycut_inspect_caption_style",
            "render_required": True,
        }

    def render_project(self, args: m.RenderProject, tenant, local_access=False):
        native_binary(self.settings)
        require_account(self.settings)
        self.validate_project(
            tenant,
            m.ProjectSpec.model_validate(
                self.store.project(tenant, args.project_id, args.revision)["project"]
            ),
        )
        job, _created = self.store.create_job(
            tenant, args.project_id, args.revision, args.idempotency_key, self.settings.max_active_jobs
        )
        if _created:
            job = self.start_worker(tenant, job["job_id"])
            return self.public_job(job, local_access)
        return self.get_job(m.JobRef(job_id=job["job_id"]), tenant, local_access)

    def start_worker(self, tenant, identifier):
        try:
            spawn(self.settings, tenant, identifier)
        except OSError:
            self.store.update_job(
                tenant,
                identifier,
                status="failed",
                claim=True,
                error={
                    "code": "worker_start_failed",
                    "message": "Cannot start the private render worker; check disk and runtime access",
                },
            )
        return self.store.job(tenant, identifier)

    def public_job(self, job, local_access=False):
        job.pop("request", None)
        if job["result"]:
            result = job["result"]
            result["downloads"] = {
                kind: f"{self.settings.public_base_url}/v1/jobs/{job['job_id']}/files/{kind}"
                for kind in ("video", "bundle", "sky_json")
            }
            result["downloads_require_bearer_token"] = True
            if not local_access:
                for key in ("video", "bundle", "sky_json"):
                    result.pop(key, None)
        return job

    def get_job(self, args: m.JobRef, tenant, local_access=False):
        job = self.store.job(tenant, args.job_id)
        if job["status"] in ("queued", "running") and time.time() - job["updated"] > 10:
            job = self.start_worker(tenant, args.job_id)
        return self.public_job(job, local_access)

    def cancel_job(self, args: m.JobRef, tenant, local_access=False):
        job = self.store.cancel_job(tenant, args.job_id)
        return self.public_job(job, local_access)

    def job_events(self, args: m.EventCursor, tenant, **context):
        return self.store.events(tenant, args.after, args.limit)

    def editor_handoff(self, args: m.EditorHandoff, tenant, **context):
        job = self.store.job(tenant, args.job_id)
        if job["status"] != "succeeded":
            raise SaycutError(
                "render_required", "Render successfully before opening the native editable project", 409
            )
        token = secrets.token_urlsafe(32)
        expires = time.time() + args.ttl_seconds
        with self.store.connect(True) as db:
            db.execute("DELETE FROM handoffs WHERE expires<?", (time.time(),))
            db.execute(
                "INSERT INTO handoffs VALUES (?,?,?,?)",
                (hashlib.sha256(token.encode()).hexdigest(), tenant, args.job_id, expires),
            )
        gateway = self.settings.public_base_url.rstrip("/")
        link = (
            self.settings.editor_origin.rstrip("/")
            + "/?"
            + urlencode({"saycut_gateway": gateway})
            + "#"
            + urlencode({"saycut_handoff": token})
        )
        return {
            "editor_url": link,
            "expires_at": expires,
            "integration_status": "ready"
            if self.settings.editor_bridge_enabled
            else "editor_bridge_required",
            "gateway_is_loopback": urlsplit(gateway).hostname in ("127.0.0.1", "localhost", "::1"),
            "requirements": "Install src/integrations/editor bridge in the editor; HTTPS gateway must be reachable by that browser. A local bundle works without the bridge.",
        }

    def handoff_job(self, token):
        with self.store.connect() as db:
            row = db.execute(
                "SELECT tenant,job_id FROM handoffs WHERE token_hash=? AND expires>?",
                (hashlib.sha256(token.encode()).hexdigest(), time.time()),
            ).fetchone()
        if not row:
            raise SaycutError("handoff_expired", "Handoff token is invalid or expired", 401)
        return self.store.job(row["tenant"], row["job_id"])
