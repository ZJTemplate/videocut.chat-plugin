"""Shared render defaults and deterministic, model-facing caption controls."""

import copy
import unicodedata

from .errors import SaycutError


def layout_defaults(entry, width):
    params = dict(entry["defaults"])
    for prefix in {key.split(":", 1)[0] for key in params}:
        for suffix in entry.get("label_suffixes", [""]):
            if f"{prefix}:Text{suffix}" not in params:
                continue
            for name, value in {
                "BoundMaxWidth": width * 0.9,
                "BoundMaxLines": 2,
                "BoundAutoWrap": True,
                "BoundAutoScale": True,
                "BoundKeepWord": True,
                "Size": max(16, round(width * 0.09)),
            }.items():
                key = f"{prefix}:{name}{suffix}"
                if key in params:
                    params[key] = value
    return params


def effective_params(entry, width, project_params, caption_params):
    return {**layout_defaults(entry, width), **project_params, **caption_params}


PARAM_HELP = {
    "Size": (
        "字号",
        "Native font size before effect scaling and automatic fitting; not final glyph height.",
        "native_font_units",
    ),
    "TransX": (
        "水平偏移",
        "Pixels relative to effect center; positive moves right.",
        "canvas_pixels",
    ),
    "TransY": (
        "垂直偏移",
        "Pixels relative to effect center; positive moves down.",
        "canvas_pixels",
    ),
    "Opacity": ("文字不透明度", "0 hides text; 100 is opaque. Independent decorations may remain visible.", "percent"),
    "Outline1Thickness": (
        "第一层描边宽度",
        "Native outline thickness; additional outline layers remain independent.",
        "native_units",
    ),
    "ScaleX": (
        "横向缩放",
        "Effect horizontal multiplier, separate from font size.",
        "multiplier",
    ),
    "ScaleY": (
        "纵向缩放",
        "Effect vertical multiplier, separate from font size.",
        "multiplier",
    ),
    "MotionDuration": (
        "动效时长",
        "Duration of the configured motion; requires this style to support it.",
        "seconds",
    ),
    "MotionStrength": ("动效强度", "Strength of the configured motion.", "multiplier"),
    "MotionMode": (
        "动效模式",
        "Native mode ID, not a speed or a name; choose a discovered motion preset instead of guessing IDs.",
        "native_enum",
    ),
}


def describe_schema(schema):
    result = copy.deepcopy(schema)
    for key, field in result["properties"].items():
        name = key.split(":", 1)[-1]
        if name in PARAM_HELP:
            title, description, unit = PARAM_HELP[name]
            field.update(title=title, description=description, unit=unit)
        elif "Color" in name and field.get("type") == "array" and field.get("minItems") == 4:
            field.update(
                description="RGBA components in [0, 1]. Gradient corners and outline layers are independent.",
                unit="rgba_0_1",
            )
    return result


def discovery(entry):
    identifier = entry["id"].lower()
    tags = ["文字", "text"]
    if "flower" in identifier:
        tags += ["花字", "装饰标题", "flower", "decorative"]
    if entry.get("kind") == "motion_preset" or "zapmotion" in identifier:
        tags += ["动态字幕", "字幕", "动效", "animated", "captions"]
    if "/caption/" in identifier:
        tags += ["字幕", "caption"]
    if "/basic/" in identifier:
        tags += ["普通文字", "基础字幕", "basic"]
    defaults = entry["defaults"]
    if defaults.get("0:Outline1Enabled"):
        tags += ["描边", "outline"]
    if defaults.get("0:Shadow"):
        tags += ["阴影", "shadow"]
    if defaults.get("0:FillGradientEnable"):
        tags += ["渐变", "gradient"]
    return {
        "tags": tags,
        "metadata_basis": "resource_name_and_defaults_not_visual_review",
    }


def control_keys(entry, effective=None):
    properties = entry["parameter_schema"]["properties"]
    current = entry["defaults"] if effective is None else effective
    # Multi-label/multi-filter controls need an explicit slot mapping, not a guess.
    if entry.get("label_suffixes", [""]) != [""] or {k.split(":")[0] for k in entry["defaults"]} != {
        "0"
    }:
        return {}
    keys = {
        "font_size": ["0:Size"],
        "scale_by": ["0:Size"],
        "x": ["0:TransX"],
        "y": ["0:TransY"],
        "position": ["0:TransX", "0:TransY"],
        "opacity": ["0:Opacity"],
        "outline_width": ["0:Outline1Thickness", "0:Outline1Enabled"],
    }
    if current.get("0:FillGradientEnable"):
        keys["text_color"] = ["0:GradientColor" + corner for corner in ("TL", "TR", "BL", "BR")]
    else:
        keys["text_color"] = ["0:Color1"]
        if "0:MotionTextColor" in properties:
            keys["text_color"].append("0:MotionTextColor")
    if current.get("0:OutlineGradientEnable"):
        keys["outline_color"] = ["0:OutlineColor" + corner for corner in ("TL", "TR", "BL", "BR")]
    else:
        keys["outline_color"] = ["0:Outline1Color"]
    keys["outline_color"].append("0:Outline1Enabled")
    return {name: group for name, group in keys.items() if all(k in properties for k in group)}


def appearance_patch(entry, effective, appearance, height):
    supported = control_keys(entry, effective)
    values = appearance.model_dump(exclude_none=True)
    unsupported = sorted(set(values) - supported.keys())
    if unsupported:
        raise SaycutError(
            "unsupported_style_control",
            f"This style does not support: {unsupported}; inspect its parameter_schema",
        )
    patch = {}
    for control, value in values.items():
        keys = supported[control]
        if control.endswith("_color"):
            color = [int(value[i : i + 2], 16) / 255 for i in (1, 3, 5)] + [1.0]
            patch.update({k: True if k.endswith("Enabled") else color for k in keys})
        elif control == "scale_by":
            patch[keys[0]] = round(effective[keys[0]] * value)
        elif control == "position":
            patch.update(
                {
                    "0:TransX": 0,
                    "0:TransY": round(height * {"top": -0.32, "center": 0, "bottom": 0.32}[value]),
                }
            )
        elif control == "outline_width":
            patch.update({keys[0]: value, keys[1]: value > 0})
        else:
            patch[keys[0]] = value
    size = patch.get("0:Size")
    if size is not None and not 8 <= size <= 512:
        raise SaycutError("invalid_effect_parameters", "Resulting font_size must be between 8 and 512")
    return patch


def visual_warnings(project, caption, params):
    warnings = []

    def add(code, message):
        warnings.append({"caption_id": caption.id, "code": code, "message": message})

    text = caption.text + "".join(caption.slots.values())
    if len(text) > 80:
        add("long_caption", "Long text can auto-shrink into unreadable or invisible glyphs. Split using supplied timestamps or word alignment; this length check is a heuristic, not a measured layout.")
    if min(project.width, project.height) < 128:
        add("narrow_canvas", "Very small or narrow canvases can produce invisible text after auto-fitting. Inspect rendered frames.")
    if caption.end - caption.start < max(0.15, 1 / project.fps):
        add("short_caption", "This cue is extremely short; it can be unreadable or end before the animation becomes visible. Verify timing rather than assuming a successful file contains readable subtitles.")
    if any(unicodedata.name(c, "").startswith(("ARABIC", "DEVANAGARI", "HEBREW")) or ord(c) >= 0x1F000 for c in text):
        add("font_coverage_unverified", "Font coverage and script shaping are not verified for all requested characters. A successful render can omit glyphs; inspect the full text and use a suitable font.")
    if params.get("0:Opacity") == 0:
        add("text_transparent", "Text opacity is zero, but independent decorations may still be visible.")
    if abs(params.get("0:TransX", 0)) >= project.width / 2 or abs(params.get("0:TransY", 0)) >= project.height / 2:
        add("offcanvas_position", "The effect center lies outside the canvas; text may be invisible.")
    return warnings


def inspection(entry, project, caption):
    params = effective_params(entry, project.width, project.effect_params, caption.effect_params)
    editable = {k: v for k, v in params.items() if k in entry["parameter_schema"]["properties"]}
    controls = control_keys(entry, params)
    return {
        "caption_id": caption.id,
        "style_id": entry["id"],
        "effective_parameters": editable,
        "controls": controls,
        "override_order": ["resource", "canvas_layout", "project", "caption"],
        "warnings": visual_warnings(project, caption, params),
        "notes": [
            "Values match compiler inputs; effect scaling and auto-fitting can change final glyph dimensions.",
            "position uses the effect center, not the text bounding box; inspect a rendered frame for clipping.",
            "Decorations and motion can extend beyond the text and clip at canvas edges; bottom is not an automatic safe-area fit.",
            "outline_color/outline_width affect the first outline only; other decorative layers are preserved.",
        ],
    }
