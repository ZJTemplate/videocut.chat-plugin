from __future__ import annotations

import copy
import hashlib
import json
import os
import time
from urllib.parse import urlencode, urlsplit

import jwt

from . import __version__
from . import cloud_models as cm
from . import models as m
from .aigc import AigcClient
from .catalog import Catalog
from .cloud_storage import ObjectStorage
from .cloud_store import TERMINAL, CloudStore
from .errors import SaycutError
from .service import Service
from .store import new_id


def https_source(url):
    parts = urlsplit(url)
    if (
        parts.scheme != "https"
        or not parts.hostname
        or parts.username
        or parts.password
        or parts.port not in (None, 443)
        or parts.fragment
        or any(ord(c) < 32 for c in url)
    ):
        raise SaycutError("unsafe_url", "Provide an authorized HTTPS media URL without embedded credentials")
    return url


class CloudCatalog(Catalog):
    def available(self, entry):
        return entry["id"] in self.settings.cloud_available_styles

    def validate(self, identifier, params, require_available=True):
        entry = super().validate(identifier, params, require_available=False)
        if require_available and not self.available(entry):
            raise SaycutError("resource_unavailable", "This style is not enabled on cloud workers")
        return entry


class CloudService(Service):
    def __init__(self, settings, store=None, objects=None, aigc=None):
        self.settings = settings
        self.store = store or CloudStore(settings.database_url)
        self.objects = objects or ObjectStorage(settings)
        self.aigc = aigc or AigcClient(settings)
        self.catalog = CloudCatalog(settings)
        self.signing_key = settings.worker_signing_key or os.environ.get("SAYCUT_WORKER_SIGNING_KEY", "")
        if len(self.signing_key) < 32:
            raise SaycutError(
                "worker_key_required", "Set a stable SAYCUT_WORKER_SIGNING_KEY with 32+ characters"
            )

    def capabilities(self, args=None, **context):
        return {
            "version": __version__,
            "backend": "genvideo",
            "execution": "remote_worker",
            "semantic_caption_editing": False,
            "per_caption_parameters": False,
            "renderer": "template_generator",
            "upload": "oss_direct",
            "transcription": "worker_configured",
            "cloud_consent_required": True,
            "styles": len(self.catalog.styles),
            "styles_enabled": self.catalog.list(available_only=True, limit=1)["total"],
            "limits": {
                "max_asset_bytes": self.settings.max_asset_bytes,
                "max_duration": self.settings.max_duration,
            },
            "editor_bridge_enabled": self.settings.editor_bridge_enabled,
        }

    def import_asset(self, args, tenant, local_access=False):
        if args.path:
            raise SaycutError(
                "local_access_denied", "The FC gateway cannot read your local path; upload once"
            )
        asset = {
            "asset_id": new_id("asset"),
            "url": https_source(args.url),
            "kind": "unverified",
            "bytes": 0,
            "verified": False,
            "filename": args.filename or "source.mp4",
        }
        self.store.add_asset(tenant, asset)
        return {"asset_id": asset["asset_id"], "verification": "worker_will_probe"}

    def prepare_upload(self, args: m.UploadRequest, tenant, **context):
        if args.bytes > self.settings.max_asset_bytes:
            raise SaycutError("asset_too_large", "Video exceeds the upload limit", 413)
        identifier = new_id("asset")
        key = self.objects.key(tenant, "inputs", identifier, args.filename)
        asset = {
            "asset_id": identifier,
            "object_key": key,
            "bytes": args.bytes,
            "filename": args.filename,
            "kind": "unverified",
            "verified": False,
            "uploaded": False,
        }
        self.store.add_asset(tenant, asset)
        return {
            "asset_id": identifier,
            "upload": self.objects.put_url(key, args.bytes, args.content_type),
            "next_tool": "saycut_complete_upload",
        }

    def complete_upload(self, args: m.AssetRef, tenant, **context):
        asset = self.store.asset(tenant, args.asset_id)
        if "object_key" not in asset:
            raise SaycutError("upload_not_expected", "This asset was not created by prepare_upload")
        info = self.objects.head(asset["object_key"])
        if info["bytes"] != asset["bytes"]:
            raise SaycutError("upload_size_mismatch", "Uploaded size differs from the declared size", 409)
        with self.store.transaction() as db:
            asset.update(uploaded=True, etag=info["etag"])
            self.store.write(db, "asset", tenant, args.asset_id, asset)
        return {"asset_id": args.asset_id, "bytes": info["bytes"], "verification": "worker_will_probe"}

    def asset_for_worker(self, tenant, identifier):
        asset = self.store.asset(tenant, identifier)
        if "object_key" in asset:
            if not asset.get("uploaded"):
                raise SaycutError("upload_incomplete", "Complete the direct upload before rendering", 409)
            return {"url": self.objects.get_url(asset["object_key"], 3600), "filename": asset["filename"]}
        return {"url": asset["url"], "filename": asset["filename"]}

    def validate_project(self, tenant, project):
        if any(c.effect_params for c in project.captions):
            raise SaycutError(
                "worker_upgrade_required",
                "Per-caption overrides require an upgraded cloud worker; use local composition",
                409,
            )
        if project.duration > self.settings.max_duration:
            raise SaycutError("duration_limit", "Project exceeds max_duration")
        for caption in project.captions:
            entry = self.catalog.validate(caption.style_id or project.style_id, project.effect_params)
            if any(slot not in entry.get("label_suffixes", [""]) for slot in caption.slots):
                raise SaycutError("invalid_text_slot", "Caption slots do not match the style")
        identifiers = {c.asset_id for c in project.clips}
        if project.font_asset_id:
            identifiers.add(project.font_asset_id)
        total = 0
        for identifier in identifiers:
            asset = self.store.asset(tenant, identifier)
            if "object_key" in asset and not asset.get("uploaded"):
                raise SaycutError("upload_incomplete", "Complete all uploads before rendering", 409)
            total += asset["bytes"]
        if total * 2 > self.settings.max_staging_bytes:
            raise SaycutError("staging_limit", "The project exceeds the staging quota")
        return {
            "output_seconds": project.duration,
            "input_bytes": total,
            "charge": None,
            "billing_mode": "cloud_unpriced",
            "media_validation": "worker_will_probe",
        }

    def enhance_video(self, args, tenant, **context):
        asset = self.store.asset(tenant, args.asset_id)
        if not asset.get("verified"):
            raise SaycutError("use_render_video", "Use render_video to probe and caption a new cloud asset")
        return super().enhance_video(args, tenant, **context)

    def render_video(self, args: m.RenderVideo, tenant, local_access=False):
        if not args.allow_cloud_processing:
            raise SaycutError(
                "cloud_consent_required", "Obtain consent before sending media to cloud workers", 403
            )
        if args.path:
            raise SaycutError("local_access_denied", "Cloud workers cannot access your local file path")
        if any(c.effect_params for c in args.captions or []):
            raise SaycutError(
                "worker_upgrade_required",
                "Per-caption overrides require an upgraded cloud worker; use local composition",
                409,
            )
        self.catalog.validate(args.style_id, args.effect_params)
        fingerprint = self.fingerprint(args.model_dump(mode="json"))
        previous = self.store.job_by_key(tenant, args.idempotency_key)
        if previous:
            if previous["fingerprint"] != fingerprint:
                raise SaycutError("idempotency_conflict", "Key already used for another request", 409)
            return self.get_job(m.JobRef(job_id=previous["job_id"]), tenant)
        identifier = (
            args.asset_id
            or self.import_asset(
                m.ImportAsset(
                    url=args.file.download_url if args.file else args.url,
                    filename=(args.file.file_name or "source.mp4") if args.file else None,
                ),
                tenant,
            )["asset_id"]
        )
        self.asset_for_worker(tenant, identifier)
        request = {
            "operation": "render_video",
            "asset_ids": [identifier],
            "arguments": {
                **args.model_dump(mode="json", exclude={"path", "url", "file"}),
                "asset_id": identifier,
            },
        }
        job, _ = self.store.enqueue(
            tenant,
            request,
            args.idempotency_key,
            fingerprint,
            self.settings.max_active_jobs,
            self.settings.cloud_job_ttl,
        )
        self.dispatch(tenant, job["job_id"])
        return self.public_job(self.store.job(tenant, job["job_id"]))

    def render_template(self, args, tenant, **context):
        raise SaycutError("legacy_only", "Registered template rendering uses the legacy GenVideo protocol")

    @staticmethod
    def fingerprint(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

    def render_project(self, args, tenant, local_access=False):
        project = self.store.project(tenant, args.project_id, args.revision)["project"]
        spec = m.ProjectSpec.model_validate(project)
        self.validate_project(tenant, spec)
        identifiers = {c.asset_id for c in spec.clips}
        if spec.font_asset_id:
            identifiers.add(spec.font_asset_id)
        request = {"operation": "render_project", "project": project, "asset_ids": sorted(identifiers)}
        job, _ = self.store.enqueue(
            tenant,
            request,
            args.idempotency_key,
            self.fingerprint(request),
            self.settings.max_active_jobs,
            self.settings.cloud_job_ttl,
            args.project_id,
            args.revision,
        )
        self.dispatch(tenant, job["job_id"])
        return self.public_job(self.store.job(tenant, job["job_id"]))

    def token(self, tenant, job, scope="worker", ttl=None):
        return jwt.encode(
            {
                "sub": job["job_id"],
                "tenant": tenant,
                "scope": scope,
                "exp": min(job["deadline"] + 3600, time.time() + ttl) if ttl else job["deadline"] + 3600,
                "iss": self.settings.public_base_url,
                "aud": scope,
            },
            self.signing_key,
            algorithm="HS256",
        )

    def authorize_capability(self, token, scope="worker"):
        try:
            claims = jwt.decode(
                token,
                self.signing_key,
                algorithms=["HS256"],
                audience=scope,
                issuer=self.settings.public_base_url,
                options={"require": ["exp", "sub", "tenant", "scope"]},
            )
            if claims["scope"] != scope:
                raise ValueError()
            self.store.job(claims["tenant"], claims["sub"])
            return claims
        except (jwt.PyJWTError, ValueError, SaycutError) as exc:
            raise SaycutError("invalid_capability", "Invalid or expired job capability", 401) from exc

    def dispatch(self, tenant, identifier):
        now = time.time()

        def reserve(job):
            if job["status"] in TERMINAL:
                return False
            if job["deadline"] <= now:
                job.update(
                    status="failed", error={"code": "job_expired", "message": "The job deadline elapsed"}
                )
                return False
            if job["cancel_requested"]:
                if job["lease_until"] <= now:
                    job.update(status="cancelled")
                return False
            if job["lease_until"] > now or job["dispatch_after"] > now:
                return False
            job["dispatch_after"] = now + 60
            if job["upstream_ids"]:
                return "poll"
            if job["dispatches"]:
                job.update(
                    status="failed",
                    error={
                        "code": "dispatch_uncertain",
                        "message": "Submission acknowledgement was lost; check the upstream queue before retrying",
                    },
                )
                return False
            job["dispatches"] = 1
            return "submit"

        job, action = self.store.mutate_job(tenant, identifier, reserve)
        if not action:
            return
        if action == "poll":
            try:
                status = int(self.aigc.check(job["upstream_ids"][-1])["status"])
            except SaycutError:
                return
            except (KeyError, TypeError, ValueError):
                status = 3
            if status in (2, 3):

                def missing_callback(current):
                    if current["status"] not in TERMINAL and current["lease_until"] <= time.time():
                        current.update(
                            status="failed",
                            error={
                                "code": "worker_no_completion",
                                "message": "GenVideo finished without a valid completion callback; verify the remote adapter",
                            },
                        )

                self.store.mutate_job(tenant, identifier, missing_callback)
            return
        try:
            upstream = self.aigc.submit(
                {
                    "params": {
                        "tid": "saycut_tools_v1",
                        "gateway": self.settings.public_base_url,
                        "job_id": identifier,
                        "capability": self.token(tenant, job),
                    }
                }
            )
            self.store.mutate_job(tenant, identifier, lambda j: j["upstream_ids"].append(upstream))
            if self.store.job(tenant, identifier)["cancel_requested"]:
                self.aigc.cancel(upstream)
        except SaycutError:
            # No upstream idempotency guarantee: preserve the reservation instead of creating duplicates.
            return

    def reconcile(self):
        count = 0
        for tenant, identifier in self.store.pending():
            self.dispatch(tenant, identifier)
            count += 1
        return {"examined": count}

    def get_job(self, args, tenant, local_access=False):
        self.dispatch(tenant, args.job_id)
        return self.public_job(self.store.job(tenant, args.job_id))

    def public_job(self, job, local_access=False):
        result = copy.deepcopy(job["result"])
        if result:
            result["downloads"] = {
                kind: self.objects.get_url(key) for kind, key in result.pop("objects").items()
            }
            result["downloads_require_bearer_token"] = False
            result["download_links_expire_in"] = 900
        return {
            **{
                key: job[key]
                for key in (
                    "job_id",
                    "project_id",
                    "revision",
                    "status",
                    "created",
                    "updated",
                    "progress",
                    "cancel_requested",
                    "error",
                )
            },
            "result": result,
        }

    def cancel_job(self, args, tenant, local_access=False):
        job = self.store.cancel_job(tenant, args.job_id)
        if job["cancel_requested"]:
            for identifier in job["upstream_ids"]:
                try:
                    self.aigc.cancel(identifier)
                except SaycutError:
                    pass
        return self.public_job(job)

    def claim(self, tenant, identifier, args: cm.Claim):
        now = time.time()

        def claim(job):
            if job["status"] in TERMINAL or job["cancel_requested"] or job["deadline"] <= now:
                raise SaycutError("job_closed", "The job no longer accepts execution", 409)
            if job["lease_until"] > now and job["run_id"] != args.run_id:
                raise SaycutError("already_claimed", "Another worker owns this job", 409)
            if job["run_id"] != args.run_id or job["lease_until"] <= now:
                job["attempt"] += 1
                job["uploads"] = {}
            job.update(
                status="running", run_id=args.run_id, lease_until=now + self.settings.worker_lease_seconds
            )

        job, _ = self.store.mutate_job(tenant, identifier, claim)
        request = copy.deepcopy(job["request"])
        request["assets"] = {asset: self.asset_for_worker(tenant, asset) for asset in request["asset_ids"]}
        return {
            "request": request,
            "attempt": job["attempt"],
            "lease_seconds": self.settings.worker_lease_seconds,
        }

    def check_lease(self, job, args):
        if (
            job["status"] != "running"
            or job["run_id"] != args.run_id
            or job["attempt"] != args.attempt
            or job["lease_until"] <= time.time()
            or job["deadline"] <= time.time()
        ):
            raise SaycutError("lease_lost", "This worker no longer owns the job", 409)

    def heartbeat(self, tenant, identifier, args: cm.Heartbeat):
        def beat(job):
            self.check_lease(job, args)
            job["lease_until"] = time.time() + self.settings.worker_lease_seconds
            job["progress"] = max(job["progress"], min(args.progress, 0.99))

        job, _ = self.store.mutate_job(tenant, identifier, beat)
        return {
            "cancel_requested": job["cancel_requested"],
            "lease_seconds": self.settings.worker_lease_seconds,
        }

    def artifact_uploads(self, tenant, identifier, args: cm.ArtifactUpload):
        def reserve(job):
            self.check_lease(job, args)
            if job["cancel_requested"]:
                raise SaycutError("cancel_requested", "Stop this render", 409)
            uploads = {**job["uploads"], **{name: value.model_dump() for name, value in args.files.items()}}
            if (
                len(uploads) > 2000
                or sum(v["bytes"] for v in uploads.values()) > self.settings.max_staging_bytes
            ):
                raise SaycutError("output_quota", "Artifacts exceed the per-job quota", 413)
            job["uploads"] = uploads

        self.store.mutate_job(tenant, identifier, reserve)
        return {
            "uploads": {
                name: self.objects.put_url(
                    self.artifact_key(tenant, identifier, args.attempt, name),
                    value.bytes,
                    value.content_type,
                    3600,
                )
                for name, value in args.files.items()
            }
        }

    def artifact_key(self, tenant, identifier, attempt, name):
        return self.objects.key(tenant, "jobs", identifier, str(attempt), name)

    def complete(self, tenant, identifier, args: cm.Complete):
        job = self.store.job(tenant, identifier)
        if job["status"] == "succeeded" and job["run_id"] == args.run_id and job["attempt"] == args.attempt:
            return {"accepted": True}
        self.check_lease(job, args)
        required = {
            "outputs/video.mp4",
            "outputs/project.zip",
            "outputs/timeline.sky",
            "native-project/saycut-manifest.json",
        }
        if not required.issubset(job["uploads"]):
            raise SaycutError("artifacts_missing", "Missing video or editable project artifacts", 409)
        for name, value in job["uploads"].items():
            info = self.objects.head(self.artifact_key(tenant, identifier, args.attempt, name))
            if info["bytes"] != value["bytes"]:
                raise SaycutError("artifact_size_mismatch", "Artifact upload is incomplete", 409)
        source_ids = set(job["request"]["asset_ids"])
        project_ids = {clip.asset_id for clip in args.project.clips}
        if args.project.font_asset_id:
            project_ids.add(args.project.font_asset_id)
        if not project_ids.issubset(source_ids):
            raise SaycutError("invalid_asset", "Worker project refers to an unrelated asset")
        for asset_id, metadata in args.assets.items():
            if asset_id not in source_ids:
                raise SaycutError("invalid_asset", "Worker returned an unrelated asset")
            with self.store.transaction() as db:
                asset = self.store.read(db, "asset", tenant, asset_id)
                asset.update(
                    {
                        k: metadata[k]
                        for k in ("kind", "duration", "width", "height", "fps", "bytes")
                        if k in metadata
                    }
                )
                asset["verified"] = True
                self.store.write(db, "asset", tenant, asset_id, asset)
        self.validate_project(tenant, args.project)
        project = self.store.save_project(tenant, args.project.model_dump(mode="json"))

        def finish(current):
            self.check_lease(current, args)
            if current["cancel_requested"]:
                current.update(status="cancelled")
                return
            current.update(
                status="succeeded",
                progress=1,
                project_id=project["project_id"],
                revision=project["revision"],
                result={
                    "project_id": project["project_id"],
                    "revision": project["revision"],
                    "media": args.media,
                    "usage": args.usage,
                    "objects": {
                        kind: self.artifact_key(tenant, identifier, args.attempt, name)
                        for kind, name in (
                            ("video", "outputs/video.mp4"),
                            ("bundle", "outputs/project.zip"),
                            ("sky_json", "outputs/timeline.sky"),
                        )
                    },
                },
            )

        self.store.mutate_job(tenant, identifier, finish)
        return {"accepted": True}

    def fail(self, tenant, identifier, args: cm.Failure):
        def fail(job):
            self.check_lease(job, args)
            job.update(
                status="cancelled" if job["cancel_requested"] else "failed",
                error=None
                if job["cancel_requested"]
                else {"code": args.code, "message": "The render worker could not complete this job"},
            )

        self.store.mutate_job(tenant, identifier, fail)
        return {"accepted": True}

    def editor_handoff(self, args, tenant, **context):
        job = self.store.job(tenant, args.job_id)
        if job["status"] != "succeeded":
            raise SaycutError("render_required", "Finish rendering before opening the native project", 409)
        token = self.token(
            tenant, {**job, "deadline": time.time() + args.ttl_seconds}, "handoff", args.ttl_seconds
        )
        return {
            "editor_url": self.settings.editor_origin
            + "/?"
            + urlencode({"saycut_gateway": self.settings.public_base_url})
            + "#saycut_handoff="
            + token,
            "expires_in": args.ttl_seconds,
            "status": "ready" if self.settings.editor_bridge_enabled else "editor_bridge_required",
        }

    def handoff_job(self, token):
        claims = self.authorize_capability(token, "handoff")
        return {**self.store.job(claims["tenant"], claims["sub"]), "tenant": claims["tenant"]}

    def handoff_manifest(self, job):
        return self.objects.read_json(
            self.artifact_key(
                job["tenant"], job["job_id"], job["attempt"], "native-project/saycut-manifest.json"
            )
        )

    def handoff_url(self, job, path):
        manifest = self.handoff_manifest(job)
        name = "native-project/" + path
        if path not in manifest["files"] or name not in job["uploads"]:
            raise SaycutError("file_not_found", "File not included in this project", 404)
        return self.objects.get_url(self.artifact_key(job["tenant"], job["job_id"], job["attempt"], name))
