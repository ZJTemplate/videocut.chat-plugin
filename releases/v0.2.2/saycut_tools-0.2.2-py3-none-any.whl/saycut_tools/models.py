from __future__ import annotations

import json
from typing import Annotated, Any, Literal

from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    Field,
    model_serializer,
    model_validator,
)


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


Identifier = Annotated[str, Field(pattern=r"^[a-z][a-z0-9_]{7,80}$")]


def no_null_character(value: str) -> str:
    if "\x00" in value:
        raise ValueError("Text must not contain null characters")
    return value


def visible_text(value: str) -> str:
    if not value.strip():
        raise ValueError("Text must contain a non-whitespace character")
    return no_null_character(value)


CaptionText = Annotated[str, Field(min_length=1, max_length=4000), AfterValidator(visible_text)]
SlotText = Annotated[str, Field(max_length=4000), AfterValidator(no_null_character)]
KeywordText = Annotated[str, Field(max_length=256), AfterValidator(no_null_character)]


class Word(Model):
    text: Annotated[str, Field(min_length=1, max_length=256), AfterValidator(visible_text)]
    start: float = Field(ge=0)
    end: float = Field(gt=0)

    @model_validator(mode="after")
    def ordered(self):
        if self.end <= self.start:
            raise ValueError("end must be after start")
        return self


class Caption(Model):
    id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,64}$")
    text: CaptionText
    start: float = Field(ge=0)
    end: float = Field(gt=0)
    words: list[Word] = Field(default_factory=list, max_length=500)
    keywords: list[KeywordText] = Field(default_factory=list, max_length=30)
    style_id: str | None = None
    slots: dict[str, SlotText] = Field(default_factory=dict, max_length=32)
    effect_params: dict[str, Any] = Field(
        default_factory=dict,
        description="Per-caption native overrides, applied after project overrides. Use style_captions for semantic edits.",
    )

    @model_serializer(mode="wrap")
    def compatible_payload(self, handler):
        value = handler(self)
        # Older workers reject unknown fields, including empty optional overrides.
        if not self.effect_params:
            value.pop("effect_params", None)
        return value

    @model_validator(mode="after")
    def ordered(self):
        if self.end <= self.start:
            raise ValueError("Caption end must be after start")
        json.dumps(self.effect_params, allow_nan=False)
        previous = self.start
        for word in self.words:
            if word.start < previous or word.end > self.end + 0.001:
                raise ValueError("Words must be ordered and lie inside their caption")
            previous = word.end
        return self


class Clip(Model):
    asset_id: Identifier
    start: float = Field(default=0, ge=0)
    duration: float = Field(gt=0)
    source_start: float = Field(default=0, ge=0)
    volume: float = Field(default=1, ge=0, le=2)


class ProjectSpec(Model):
    name: str = Field(default="Saycut video", min_length=1, max_length=120)
    width: int = Field(default=1080, ge=64, le=3840, multiple_of=2)
    height: int = Field(default=1920, ge=64, le=3840, multiple_of=2)
    fps: float = Field(default=30, ge=1, le=60)
    duration: float = Field(gt=0, le=86400)
    clips: list[Clip] = Field(default_factory=list, max_length=200)
    captions: list[Caption] = Field(default_factory=list, max_length=1000)
    style_id: str = "runtime/ZapMotion"
    effect_params: dict[str, Any] = Field(default_factory=dict)
    font_asset_id: Identifier | None = None

    @model_validator(mode="after")
    def timeline(self):
        json.dumps(self.effect_params, allow_nan=False)
        ids = [c.id for c in self.captions]
        if len(ids) != len(set(ids)):
            raise ValueError("Caption IDs must be unique")
        for caption in self.captions:
            if caption.end > self.duration + 0.001:
                raise ValueError("Caption exceeds project duration")
        for clip in self.clips:
            if clip.start + clip.duration > self.duration + 0.001:
                raise ValueError("Clip exceeds project duration")
        if not self.clips and not self.captions:
            raise ValueError("Provide at least one clip or caption")
        return self


class CreateProject(Model):
    project: ProjectSpec


class ImportAsset(Model):
    path: str | None = Field(default=None, min_length=1, max_length=4096)
    url: str | None = Field(default=None, min_length=1, max_length=8192)
    filename: str | None = Field(default=None, min_length=1, max_length=200)

    @model_validator(mode="after")
    def one_source(self):
        if (self.path is None) == (self.url is None):
            raise ValueError("Provide exactly one path or URL")
        return self


class ParseSubtitles(Model):
    content: str = Field(max_length=2_000_000)
    format: Literal["srt", "vtt", "ass"] = "srt"


class EnhanceVideo(Model):
    asset_id: Identifier
    captions: list[Caption] = Field(min_length=1, max_length=1000)
    style_id: str = "runtime/ZapMotion"
    effect_params: dict[str, Any] = Field(default_factory=dict)
    name: str = "Captioned video"


class Attachment(Model):
    download_url: str = Field(min_length=1, max_length=8192)
    file_id: str = Field(min_length=1, max_length=512)
    mime_type: str = ""
    file_name: str = ""


class RenderVideo(Model):
    path: str | None = Field(default=None, max_length=4096)
    url: str | None = Field(default=None, max_length=8192)
    asset_id: Identifier | None = None
    file: Attachment | None = None
    captions: list[Caption] | None = Field(default=None, max_length=1000)
    style_id: str = "runtime/ZapMotion"
    effect_params: dict[str, Any] = Field(default_factory=dict)
    language: str | None = Field(default=None, pattern=r"^[a-z]{2,3}(-[A-Za-z]{2,8})?$")
    name: str = Field(default="Captioned video", min_length=1, max_length=120)
    allow_cloud_processing: bool = False
    idempotency_key: str = Field(min_length=8, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")

    @model_validator(mode="after")
    def one_source(self):
        if sum(v is not None for v in (self.path, self.url, self.asset_id, self.file)) != 1:
            raise ValueError("Provide exactly one path, URL, asset_id or authorized file attachment")
        return self


class UploadRequest(Model):
    filename: str = Field(min_length=1, max_length=200, pattern=r"^[^/\\\\\x00]+$")
    bytes: int = Field(gt=0)
    content_type: str = Field(default="video/mp4", max_length=120)


class AssetRef(Model):
    asset_id: Identifier


class RenderTemplate(Model):
    template_id: str = Field(min_length=1, max_length=100)
    assets: dict[str, Identifier] = Field(default_factory=dict, max_length=100)
    allow_cloud_processing: bool = False
    idempotency_key: str = Field(min_length=8, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")


class RenderAttachment(Model):
    file: Attachment
    captions: list[Caption] | None = Field(default=None, max_length=1000)
    style_id: str = "runtime/ZapMotion"
    effect_params: dict[str, Any] = Field(default_factory=dict)
    language: str | None = Field(default=None, pattern=r"^[a-z]{2,3}(-[A-Za-z]{2,8})?$")
    allow_cloud_processing: bool = False
    idempotency_key: str = Field(min_length=8, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")


class CaptionChange(Model):
    id: str
    text: CaptionText | None = None
    start: float | None = Field(default=None, ge=0)
    end: float | None = Field(default=None, gt=0)
    words: list[Word] | None = None
    style_id: str | None = None
    slots: dict[str, SlotText] | None = Field(default=None, max_length=32)
    effect_params_patch: dict[str, Any] | None = Field(
        default=None,
        description="Merge native overrides for this caption. Null values remove the corresponding override.",
    )

    @model_serializer(mode="wrap")
    def compatible_payload(self, handler):
        value = handler(self)
        if self.effect_params_patch is None:
            value.pop("effect_params_patch", None)
        return value


class EditProject(Model):
    project_id: Identifier
    expected_revision: int = Field(ge=1)
    captions: list[CaptionChange] = Field(default_factory=list, max_length=1000)
    style_id: str | None = None
    effect_params: dict[str, Any] | None = None
    effect_params_patch: dict[str, Any] | None = Field(
        default=None,
        description="Merge project native overrides. Null values remove an override; unrelated values remain unchanged.",
    )

    @model_validator(mode="after")
    def exclusive_params(self):
        if self.effect_params is not None and self.effect_params_patch is not None:
            raise ValueError("Use effect_params (replace) or effect_params_patch (merge), not both")
        return self

    @model_serializer(mode="wrap")
    def compatible_payload(self, handler):
        value = handler(self)
        if self.effect_params_patch is None:
            value.pop("effect_params_patch", None)
        return value


class Appearance(Model):
    text_color: str | None = Field(
        default=None,
        pattern=r"^#[0-9a-fA-F]{6}$",
        description="Opaque text color in #RRGGBB, e.g. #FFD900. Updates all fill gradient corners when needed.",
    )
    outline_color: str | None = Field(
        default=None,
        pattern=r"^#[0-9a-fA-F]{6}$",
        description="First outline color in #RRGGBB. Other outline/decorative layers are preserved.",
    )
    font_size: int | None = Field(
        default=None,
        ge=8,
        le=512,
        description="Absolute native font size before effect scaling and automatic fitting. Inspect effective values first.",
    )
    scale_by: float | None = Field(
        default=None,
        ge=0.25,
        le=4,
        description="Multiply current effective font size: 1.2 means 20 percent larger. Applied once using expected_revision.",
    )
    position: Literal["top", "center", "bottom"] | None = Field(
        default=None,
        description="Center horizontally; effect Y offset is -32%, 0%, or +32% of canvas height. Visual QA still required.",
    )
    x: int | None = Field(
        default=None,
        ge=-3840,
        le=3840,
        description="Absolute horizontal offset from effect center in canvas pixels; positive is right.",
    )
    y: int | None = Field(
        default=None,
        ge=-3840,
        le=3840,
        description="Absolute vertical offset from effect center in canvas pixels; positive is down.",
    )
    opacity: int | None = Field(default=None, ge=0, le=100, description="Text opacity: 0 hides text, 100 is opaque. Independent effect decorations may remain visible.")
    outline_width: float | None = Field(
        default=None,
        ge=0,
        le=100,
        description="First native outline thickness. Zero disables the first outline only.",
    )

    @model_validator(mode="after")
    def unambiguous(self):
        if not self.model_dump(exclude_none=True):
            raise ValueError("Provide at least one appearance control")
        if self.font_size is not None and self.scale_by is not None:
            raise ValueError("Use font_size or scale_by, not both")
        if self.position is not None and (self.x is not None or self.y is not None):
            raise ValueError("Use position or explicit x/y offsets, not both")
        return self


class StyleCaptions(Model):
    project_id: Identifier
    expected_revision: int = Field(ge=1)
    caption_ids: list[str] = Field(
        min_length=1,
        max_length=1000,
        description="Explicit caption IDs from get_project; only these captions are changed.",
    )
    appearance: Appearance


class InspectCaptionStyle(Model):
    project_id: Identifier
    caption_id: str
    revision: int | None = Field(default=None, ge=1)


class ProjectRef(Model):
    project_id: Identifier
    revision: int | None = Field(default=None, ge=1)


class RenderProject(Model):
    project_id: Identifier
    revision: int = Field(ge=1)
    idempotency_key: str = Field(min_length=8, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")


class JobRef(Model):
    job_id: Identifier


class ListStyles(Model):
    query: str = Field(default="", max_length=120)
    offset: int = Field(default=0, ge=0)
    limit: int = Field(default=20, ge=1, le=100)
    available_only: bool = False


class StyleRef(Model):
    style_id: str = Field(min_length=1, max_length=200)


class EditorHandoff(Model):
    job_id: Identifier
    ttl_seconds: int = Field(default=600, ge=60, le=3600)


class Empty(Model):
    pass


class ReplaceProject(Model):
    project_id: Identifier
    expected_revision: int = Field(ge=1)
    project: ProjectSpec


class EventCursor(Model):
    after: int = Field(default=0, ge=0)
    limit: int = Field(default=100, ge=1, le=100)
