from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .catalog import import_catalog, sync_packages
from .config import Settings, write_json
from .errors import SaycutError
from .registry import BY_NAME, invoke
from .service import Service, create_service


def parser():
    root = argparse.ArgumentParser(prog="saycut-tools")
    root.add_argument("--config", type=Path)
    commands = root.add_subparsers(dest="command", required=True)
    init = commands.add_parser(
        "init", help="Create local configuration; optionally import the existing SDK catalogs"
    )
    init.add_argument("--saycut-root", type=Path)
    init.add_argument("--smartcut-root", type=Path)
    init.add_argument("--subtitle-source", type=Path)
    init.add_argument("--runtime-build", type=Path)
    init.add_argument("--sdk-source", type=Path)
    init.add_argument("--allow-root", type=Path, action="append")
    init.add_argument("--data-dir", type=Path, default=Path(".saycut"))
    init.add_argument("--sync", action="store_true")
    doctor = commands.add_parser("doctor")
    doctor.add_argument(
        "--check", action="store_true", help="Exit nonzero when local render prerequisites are missing"
    )
    account = commands.add_parser("account", help="Authorize this isolated plugin with the Saycut platform")
    account.add_argument("action", choices=["login", "start", "complete", "status", "logout"])
    account.add_argument("--no-browser", action="store_true")
    commands.add_parser("mcp", help="Run the MCP stdio server (stdout reserved for protocol)")
    remote = commands.add_parser("remote-mcp", help="Bridge stdio MCP to the cloud REST gateway")
    remote.add_argument("--url", default="https://mcp.zjtemplate.com")
    asr = commands.add_parser(
        "configure-asr", help="Configure real ASR explicitly; local rendering never auto-uploads"
    )
    asr.add_argument("--backend", choices=["disabled", "faster_whisper", "ryry"], required=True)
    asr.add_argument("--model", default="small")
    asr.add_argument("--download-model", action="store_true")
    serve = commands.add_parser("serve", help="Run REST and authenticated Streamable HTTP MCP")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)
    serve.add_argument("--allow-network", action="store_true")
    catalog = commands.add_parser("catalog")
    catalog.add_argument("action", choices=["sync", "list", "bind"])
    catalog.add_argument("--style")
    catalog.add_argument("--path", type=Path)
    catalog.add_argument("--fallback-font", type=Path)
    call = commands.add_parser("call")
    call.add_argument("tool", choices=list(BY_NAME))
    call.add_argument("--json", default="{}", help="JSON object, or @path to read JSON from a file")
    export = commands.add_parser("export-integrations")
    export.add_argument("--output", type=Path, default=Path("src/integrations/generated"))
    export.add_argument("--base-url", help="Public origin for OpenAPI and workflow exports")
    export.add_argument(
        "--plugin-source", type=Path, help="Unpacked plugin directory for wheel-only installs"
    )
    return root


def initialize(args):
    config = (args.config or Path("saycut.local.json")).resolve()
    if config.exists():
        raise SaycutError(
            "config_exists",
            "Configuration already exists; edit it explicitly or choose another --config path",
        )
    settings = Settings(
        data_dir=args.data_dir.resolve(),
        allowed_roots=[p.resolve() for p in (args.allow_root or [Path.cwd()])],
        template_generator_source=args.sdk_source.resolve() if args.sdk_source else None,
    )
    settings.data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    if args.runtime_build:
        runtime = settings.data_dir / "runtime"
        runtime.mkdir(exist_ok=True)
        link = runtime / "skymedia"
        if not link.exists():
            link.symlink_to(args.runtime_build.resolve(), target_is_directory=True)
        elif link.resolve() != args.runtime_build.resolve():
            raise SaycutError("runtime_conflict", "Existing runtime points to a different build")
        settings.runtime_dir = runtime
    sources = (args.saycut_root, args.smartcut_root, args.subtitle_source)
    if any(sources):
        if not all(sources):
            raise SaycutError(
                "catalog_sources_required",
                "Provide --saycut-root, --smartcut-root and --subtitle-source together",
            )
        settings.catalog_file = settings.data_dir / "catalog.json"
        settings.effect_sources = import_catalog(
            args.saycut_root / "src/config/textRuntimeCatalog.json",
            args.smartcut_root,
            args.subtitle_source,
            settings.catalog_file,
        )
    write_json(config, settings.snapshot())
    if args.sync:
        settings.effect_sources = sync_packages(settings)
        write_json(config, settings.snapshot())
    return {"config": str(config), "data_dir": str(settings.data_dir), "catalog": str(settings.catalog_file)}


def main():
    os.umask(0o077)
    args = parser().parse_args()
    try:
        if args.command == "init":
            result = initialize(args)
        else:
            settings = Settings.load(args.config)
            if args.command == "account":
                import time
                import webbrowser

                from .account import AccountClient

                with AccountClient(settings) as account:
                    if args.action in {"login", "start"}:
                        result = account.start_login()
                        if args.action == "login":
                            print(json.dumps(result, ensure_ascii=False), file=sys.stderr)
                            if not args.no_browser:
                                webbrowser.open(result["verification_uri_complete"])
                            deadline = time.monotonic() + result["expires_in"]
                            interval = result["interval"]
                            while time.monotonic() < deadline:
                                time.sleep(interval)
                                result = account.complete_login()
                                if result["status"] == "connected":
                                    break
                                interval = result["interval"]
                            else:
                                raise SaycutError("login_timeout", "Authorization expired; start again")
                    else:
                        result = getattr(
                            account, {"complete": "complete_login"}.get(args.action, args.action)
                        )()
                print(json.dumps(result, ensure_ascii=False))
                return
            if args.command == "remote-mcp":
                from .mcp_server import create_mcp
                from .remote import RemoteService

                token = os.environ.get("SAYCUT_TOKEN")
                if not token:
                    raise SaycutError("token_required", "Set SAYCUT_TOKEN in the MCP host environment")
                remote = RemoteService(settings, args.url, token)
                try:
                    create_mcp(remote, local=True).run()
                finally:
                    remote.client.close()
                return
            if args.command == "configure-asr":
                settings.asr_backend = args.backend
                settings.asr_model = args.model
                if args.download_model:
                    if args.backend != "faster_whisper":
                        raise SaycutError(
                            "invalid_asr_option", "Model download applies to local faster_whisper only"
                        )
                    from faster_whisper import WhisperModel

                    WhisperModel(args.model, device="cpu", compute_type="int8")
                settings.asr_allow_model_download = False
                write_json(
                    args.config or Path(os.environ.get("SAYCUT_CONFIG", "saycut.local.json")),
                    settings.snapshot(),
                )
                print(
                    json.dumps(
                        {
                            "asr_backend": settings.asr_backend,
                            "model": settings.asr_model,
                            "audio_upload": args.backend == "ryry",
                        }
                    )
                )
                return
            if args.command == "mcp":
                from .mcp_server import create_mcp

                create_mcp(create_service(settings), local=True).run()
                return
            if args.command == "serve":
                import uvicorn

                from .http import create_app

                if args.host not in ("127.0.0.1", "localhost", "::1") and not args.allow_network:
                    raise SaycutError(
                        "network_opt_in_required",
                        "Use --allow-network explicitly and put TLS in front of non-loopback serving",
                    )
                if settings.public_base_url == "http://127.0.0.1:8765":
                    settings.public_base_url = f"http://127.0.0.1:{args.port}"
                uvicorn.run(create_app(settings), host=args.host, port=args.port, access_log=False)
                return
            if args.command == "doctor":
                result = create_service(settings).capabilities()
                if args.check and result.get("readiness", {}).get("local_prerequisites_ready") is False:
                    print(json.dumps(result, ensure_ascii=False, indent=2))
                    raise SystemExit(1)
            elif args.command == "catalog":
                if args.action == "sync":
                    settings.effect_sources = sync_packages(settings)
                    write_json(
                        args.config or Path(os.environ.get("SAYCUT_CONFIG", "saycut.local.json")),
                        settings.snapshot(),
                    )
                    result = {"installed_resource_packs": len(settings.effect_sources)}
                elif args.action == "bind":
                    if not args.style or not args.path or not args.path.is_file():
                        raise SaycutError(
                            "resource_required", "Provide --style and --path to a trusted local .fceffect"
                        )
                    if args.path.suffix != ".fceffect":
                        raise SaycutError("resource_required", "Expected an .fceffect file")
                    entry = Service(settings).catalog.get(args.style)
                    settings.effect_sources[entry["resource_id"]] = str(args.path.resolve())
                    if args.fallback_font:
                        if not args.fallback_font.is_file():
                            raise SaycutError("font_missing", "Fallback font file does not exist")
                        settings.fallback_font = args.fallback_font.resolve()
                    write_json(
                        args.config or Path(os.environ.get("SAYCUT_CONFIG", "saycut.local.json")),
                        settings.snapshot(),
                    )
                    result = {
                        "bound": entry["resource_id"],
                        "verification": "local_override_requires_render_qa",
                    }
                else:
                    result = Service(settings).catalog.list(limit=100)
            elif args.command == "call":
                raw = Path(args.json[1:]).read_text() if args.json.startswith("@") else args.json
                result = invoke(
                    create_service(settings), args.tool, json.loads(raw), "local", local_access=True
                )
            else:
                from .integrations import export_integrations

                result = export_integrations(
                    settings.model_copy(update={"public_base_url": args.base_url})
                    if args.base_url
                    else settings,
                    args.output,
                    (args.config or Path("saycut.local.json")).resolve(),
                    args.plugin_source,
                )
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (SaycutError, ValueError, OSError) as exc:
        result = (
            exc.payload()
            if isinstance(exc, SaycutError)
            else {"error": {"code": "local_error", "message": str(exc)}}
        )
        print(json.dumps(result, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
