# 安装与首次运行

本文档面向第一次安装 `videocut.chat` 插件的用户，配合 [README](../README.zh-CN.md) 的能力介绍阅读。

## 1. 安装

```bash
# 1. 安装 SDK（包含 native 渲染、ASR、可选 cloud 适配）
pip install --user "saycut-tools[asr]"

# 2. 安装本插件
解压 videocut-chat-plugin-<version>.zip 后，把 plugins/videocut-chat/ 目录
放到你的 Agent 客户端的插件目录（Codex/Qwen/Codex 等相同）。
```

> **不要**安装到全局 Python。建议使用 `pip install --user` 或 venv。

## 2. 首次运行：登录 + 续期

打开任意 Agent 客户端并发出指令（例如“给这个本地视频添加花字字幕”）。第一次会让模型
调用 `saycut_account_login`，按提示在浏览器完成授权。

授权完成后，本机 **会自动**：

- **Token**：在 MCP stdio server 与 FastAPI gateway 进程内，每 30 分钟通过后台守护
  线程 (`saycut_tools.keepers.TokenKeeper`) 调用一次轻量 `/mcp/v1/session` 校验，
  检测 token 被吊销；真正需要刷新时由 `AccountClient.authorized` 在 401 触发。
- **License (SDK)**：每 6 小时通过后台守护线程 (`saycut_tools.keepers.LicenseKeeper`)
  检查一次租约；当剩余 TTL 低于 **36 小时** 时，自动向 `/mcp/v1/license/issue`
  申请新租约并写入私有凭据目录，无需用户介入。

> **不要问用户“license 即将过期”**：先调 `saycut_keeper_status` 看一下
> `lease.remaining_seconds`。正常机器永远大于 36h。

## 3. 验证自动续期生效

```bash
# 看 keepers 是否在后台启动
saycut-tools mcp --print-status
# 或重启后：
saycut-tools serve # 起 FastAPI gateway
```

查看日志会看到 `saycut.keepers` 模块的初始化。断网 5 秒再恢复，下次 tick
应当能恢复到 `running=True, last_error=None`。

## 4. 离线 / 沙盒环境

- 离线时 license 自动续期会失败（`last_error = account_unavailable`）。
  这时本地渲染用的是磁盘上的旧 lease，**只要 lease 还没过期就能继续用**。
- 真正过期后再恢复网络，下一次 MCP 调用会自动重新拉新 license。

## 5. 排错

| 现象 | 原因 | 修复 |
| --- | --- | --- |
| MCP 一直在 unauthorized | OAuth 连接断了 | `saycut-tools account status`，必要时重新走一遍 `login` |
| `keeper_status.license.last_error` 是 `entitlement_required` | 账号订阅暂停 | 联系平台端 |
| `keeper_status.token.detail.revoked=true` | token 被吊销（最常见的：用户主动改密） | 重新走 `login` |
| 渲染时 `invalid_personal_license` | lease 文件损坏或没写 | `rm ~/.local/share/saycut/private/sdk/license.txt` 然后重渲一次 |

## 6. 跑单元测试（可选）

```bash
cd path/to/videocut.chat-server
python3 scripts/verify_keepers.py
```

跑通即代表本机 keepers 行为对齐预期。
