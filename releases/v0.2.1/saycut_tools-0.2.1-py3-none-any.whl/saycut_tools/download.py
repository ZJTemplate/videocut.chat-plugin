"""Bounded HTTPS downloads with DNS pinned for the lifetime of each connection."""

from __future__ import annotations

import http.client
import ipaddress
import socket
import ssl
from pathlib import Path
from urllib.parse import urljoin, urlsplit

from .errors import SaycutError


def public_addresses(host: str, port: int) -> list[str]:
    addresses = list(dict.fromkeys(a[4][0] for a in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)))
    if not addresses or any(not ipaddress.ip_address(ip).is_global for ip in addresses):
        raise SaycutError("unsafe_url", "Only publicly routable HTTPS asset addresses are allowed")
    return addresses


class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host: str, ip: str, port: int):
        super().__init__(host, port, timeout=30, context=ssl.create_default_context())
        self.ip = ip

    def connect(self):
        sock = socket.create_connection((self.ip, self.port), timeout=self.timeout)
        try:
            self.sock = self._context.wrap_socket(sock, server_hostname=self.host)
        except BaseException:
            sock.close()
            raise


def download(url: str, output: Path, max_bytes: int) -> None:
    try:
        for _ in range(4):
            parsed = urlsplit(url)
            if (
                parsed.scheme != "https"
                or not parsed.hostname
                or parsed.username
                or parsed.password
                or parsed.port not in (None, 443)
                or any(ord(c) < 32 for c in url)
            ):
                raise SaycutError("unsafe_url", "Use an HTTPS URL on port 443 without embedded credentials")
            connection = PinnedHTTPS(parsed.hostname, public_addresses(parsed.hostname, 443)[0], 443)
            try:
                target = parsed.path or "/"
                if parsed.query:
                    target += "?" + parsed.query
                connection.request(
                    "GET", target, headers={"User-Agent": "Saycut-Tools/0.1", "Accept-Encoding": "identity"}
                )
                response = connection.getresponse()
                if response.status in (301, 302, 303, 307, 308):
                    url = urljoin(url, response.getheader("Location", ""))
                    continue
                if response.status != 200:
                    raise SaycutError("download_failed", f"Asset server returned HTTP {response.status}")
                total = 0
                output.parent.mkdir(parents=True, exist_ok=True)
                with output.open("xb") as stream:
                    while chunk := response.read(1024 * 1024):
                        total += len(chunk)
                        if total > max_bytes:
                            raise SaycutError("asset_too_large", "Download exceeds the configured byte limit")
                        stream.write(chunk)
                return
            finally:
                connection.close()
        raise SaycutError("too_many_redirects", "Asset URL redirects more than three times")
    except BaseException:
        output.unlink(missing_ok=True)
        raise
