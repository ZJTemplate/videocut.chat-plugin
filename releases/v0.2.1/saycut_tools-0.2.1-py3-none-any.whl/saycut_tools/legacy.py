"""Run the already-deployed GenVideo protocol, without changing any worker registration."""

from __future__ import annotations

import copy
import json
import math
import time
from pathlib import PurePosixPath
from urllib.parse import urlsplit

from .cloud import CloudService, https_source
from .cloud_store import TERMINAL
from .errors import SaycutError


class LegacyCloudService(CloudService):
    def capabilities(self, args=None, **context):
        value = super().capabilities(args, **context)
        value["limits"].update(max_duration=None, duration_enforcement="existing_genvideo_policy")
        value.update(
            protocol="legacy",
            transcription="GenVideo/SpeechToText",
            editable_output=False,
            timed_caption_input=False,
            effect_parameter_overrides=False,
            templates=[
                {"id": key, "slots": value.get("slots", [])}
                for key, value in self.settings.cloud_templates.items()
            ],
            limitations=[
                "Existing add_subtitle returns MP4, not its generated project or ASR records.",
                "Install the optional callback_v1 adapter on the real worker for full editable output.",
                "Output storage and retention follow the existing GenVideo upload service.",
            ],
            accepted_media_hosts=self.settings.legacy_media_hosts,
        )
        return value

    def source_url(self, value):
        https_source(value)
        hostname = urlsplit(value).hostname
        own_bucket = self.settings.oss_bucket + "." + urlsplit(self.settings.oss_endpoint).hostname
        if hostname not in [own_bucket, *self.settings.legacy_media_hosts]:
            # The deployed downloader does not enforce SSRF controls. Never pass arbitrary hosts to it.
            raise SaycutError(
                "upload_required", "Upload the media to this gateway's private OSS bucket first", 403
            )
        return value

    def asset_for_worker(self, tenant, identifier):
        value = super().asset_for_worker(tenant, identifier)
        asset = self.store.asset(tenant, identifier)
        if asset.get("object_key"):
            value["url"] = self.objects.get_url(asset["object_key"], min(86400, self.settings.cloud_job_ttl))
        value["url"] = self.source_url(value["url"])
        return value

    def render_video(self, args, tenant, local_access=False):
        if args.captions is not None or args.effect_params or args.language is not None:
            raise SaycutError(
                "worker_upgrade_required",
                "Legacy GenVideo uses automatic ASR and preset styles only; custom timed captions, "
                "language selection and effect parameters need callback_v1 on the actual render worker",
                409,
            )
        entry = self.catalog.validate(args.style_id, {})
        if entry["kind"] not in ("runtime", "motion_preset"):
            raise SaycutError(
                "worker_upgrade_required", "This effect needs the callback_v1 worker adapter", 409
            )
        return super().render_video(args, tenant, local_access)

    def render_project(self, args, tenant, **context):
        raise SaycutError(
            "worker_upgrade_required",
            "Full ProjectSpec rendering needs callback_v1. Existing deployed GenVideo accepts registered templates.",
            409,
        )

    def render_template(self, args, tenant, **context):
        if not args.allow_cloud_processing:
            raise SaycutError("cloud_consent_required", "Obtain consent before cloud rendering", 403)
        template = self.settings.cloud_templates.get(args.template_id)
        if not template:
            raise SaycutError("template_not_found", "Use a registered template ID from capabilities", 404)
        slots = template.get("slots", [])
        if set(args.assets) != set(slots):
            raise SaycutError(
                "template_slots_mismatch", "Provide exactly the registered template resource slots"
            )
        for slot, identifier in args.assets.items():
            path = PurePosixPath(slot)
            if path.is_absolute() or ".." in path.parts or "\\" in slot or ":" in slot:
                raise SaycutError("invalid_template_slot", "Unsafe template resource path")
            self.asset_for_worker(tenant, identifier)
        request = {
            "operation": "render_template",
            "template_id": args.template_id,
            "assets": args.assets,
            "asset_ids": sorted(set(args.assets.values())),
        }
        job, _ = self.store.enqueue(
            tenant,
            request,
            args.idempotency_key,
            self.fingerprint(request),
            self.settings.max_active_jobs,
            self.settings.cloud_job_ttl,
        )
        self.dispatch(tenant, job["job_id"])
        return self.public_job(self.store.job(tenant, job["job_id"]))

    def payload(self, tenant, job):
        request = job["request"]
        if request["operation"] == "render_template":
            template = self.settings.cloud_templates[request["template_id"]]
            params = {
                "tid": "zip_generate",
                "zip": self.source_url(template["zip_url"]),
                "res_params": {
                    slot: self.asset_for_worker(tenant, identifier)["url"]
                    for slot, identifier in request["assets"].items()
                },
            }
        else:
            arguments = request["arguments"]
            params = {
                "tid": "add_subtitle",
                "subtitle_style": self.catalog.styles[arguments["style_id"]]["name"],
                "video_url": self.asset_for_worker(tenant, arguments["asset_id"])["url"],
            }
        return {"params": params}

    def dispatch(self, tenant, identifier):
        now = time.time()

        def reserve(job):
            if job["status"] in TERMINAL:
                return None
            if job["deadline"] <= now:
                job.update(
                    status="failed", error={"code": "job_expired", "message": "The render deadline elapsed"}
                )
                return None
            if job["dispatch_after"] > now:
                return None
            job["dispatch_after"] = now + 30
            if job["upstream_ids"]:
                return "poll"
            if job["dispatches"]:
                # No upstream idempotency contract exists: an uncertain enqueue must not bill twice.
                job.update(
                    status="failed",
                    error={
                        "code": "dispatch_uncertain",
                        "message": "Submission acknowledgement was lost; check the upstream queue before retrying",
                    },
                )
                return None
            job["dispatches"] = 1
            return "submit"

        job, action = self.store.mutate_job(tenant, identifier, reserve)
        if action is None:
            return
        if action == "submit":
            try:
                upstream = self.aigc.submit(self.payload(tenant, job))
                self.store.mutate_job(tenant, identifier, lambda j: j["upstream_ids"].append(upstream))
                if self.store.job(tenant, identifier)["cancel_requested"]:
                    self.aigc.cancel(upstream)
            except SaycutError:
                # Leave the dispatch reservation durable. Never blindly resubmit an uncertain createTask.
                pass
            return
        try:
            detail = self.aigc.check(job["upstream_ids"][-1])
        except SaycutError:
            return
        try:
            status = int(detail["status"])
            if status not in (0, 1, 2, 3):
                raise ValueError("Unknown GenVideo task status")
            result = self.parse_result(detail["task_result"]) if status == 2 else None
        except (SaycutError, ValueError, TypeError, KeyError):
            status, result = 3, None
        progress = job["progress"]
        try:
            value = float(detail.get("progress", 0)) / 100
            if math.isfinite(value):
                progress = max(progress, max(0, min(value, 0.99)))
        except (AttributeError, ValueError, TypeError):
            pass

        def update(current):
            if current["status"] in TERMINAL:
                return
            if current["cancel_requested"]:
                current.update(status="cancelled")
            elif status == 2:
                current.update(status="succeeded", progress=1, result=result)
            elif status == 3:
                current.update(
                    status="failed",
                    error={"code": "genvideo_failed", "message": "GenVideo could not complete this task"},
                )
            else:
                current.update(
                    status="running" if status == 1 else "queued", progress=max(current["progress"], progress)
                )

        self.store.mutate_job(tenant, identifier, update)

    @staticmethod
    def parse_result(value):
        value = json.loads(value) if isinstance(value, str) else value
        if isinstance(value, list) and len(value) == 1:
            value = value[0]
        if not isinstance(value, dict):
            raise TypeError("Invalid GenVideo output")
        if value.get("status", 0) != 0:
            raise ValueError("GenVideo reported failure")
        result = value.get("result", value)
        url = https_source(result["url"])
        return {
            "downloads": {"video": url},
            "editable_output": False,
            "downloads_require_bearer_token": False,
            "media": {"duration": result.get("duration")},
            "storage": "existing_genvideo_upload_service",
        }

    def public_job(self, job, local_access=False):
        return {
            **{
                key: job[key]
                for key in (
                    "job_id",
                    "project_id",
                    "revision",
                    "status",
                    "created",
                    "updated",
                    "progress",
                    "cancel_requested",
                    "error",
                )
            },
            "result": copy.deepcopy(job["result"]),
        }

    def editor_handoff(self, args, tenant, **context):
        self.store.job(tenant, args.job_id)
        raise SaycutError(
            "editable_output_unavailable",
            "Deployed legacy GenVideo returns MP4 only. Enable callback_v1 to export the editable project",
            409,
        )
