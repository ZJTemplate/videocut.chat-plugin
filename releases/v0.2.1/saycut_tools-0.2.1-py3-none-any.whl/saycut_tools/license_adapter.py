"""Process-local adaptation only; never edit the installed template_generator package."""

from __future__ import annotations

import base64
import os

from .account import private_directory
from .errors import SaycutError


def native_license(value: str) -> str:
    if not value.startswith("mcp-"):
        return value
    raw = value[4:]
    try:
        if not raw:
            raise ValueError("empty")
        base64.b64decode(raw, validate=True)
    except ValueError:
        raise SaycutError("invalid_personal_license", "Malformed personal SDK license") from None
    return raw


class VerifiedRequests:
    def __init__(self, original, origin, proxy=None):
        self.original, self.origin, self.proxy = original, origin, proxy

    def __getattr__(self, name):
        return getattr(self.original, name)

    def post(self, url, **kwargs):
        if url != "https://api.zjtemplate.com/business/verify-license":
            raise SaycutError("unexpected_license_request", "Unexpected SDK license destination")
        kwargs["verify"] = True
        kwargs["allow_redirects"] = False
        kwargs["headers"] = {"Content-Type": "application/json"}
        if self.proxy:
            kwargs["proxies"] = {"http": self.proxy, "https": self.proxy}
        return self.original.post(self.origin + "/business/verify-license", **kwargs)


def install_license(settings, module, key):
    if not key.startswith("mcp-"):
        raise SaycutError("invalid_personal_license", "A personal certificate is required")
    native_license(key)
    directory = private_directory(settings) / "sdk"
    if directory.is_symlink():
        raise SaycutError("unsafe_credentials", "SDK state directory must not be a symbolic link")
    directory.mkdir(mode=0o700, exist_ok=True)
    os.chmod(directory, 0o700)
    for name in ("license.txt", ".state", ".verify.lock"):
        if (directory / name).is_symlink():
            raise SaycutError("unsafe_credentials", "SDK state files must not be symbolic links")
    module._get_config_dir = lambda: str(directory)
    module._license_manager = None
    module.LicenseManager._instance = None
    module.requests = VerifiedRequests(
        module.requests, settings.account_api_origin.rstrip("/"), settings.account_proxy
    )
    module.write_license(key)
    # Existing write_license returns True even if its online verification failed.
    if module._get_manager().state.get("valid") is not True:
        raise SaycutError("license_verification_failed", "SDK online license validation failed")


def child_environment():
    return {
        key: value
        for key, value in os.environ.items()
        if key not in {"PYTHONPATH", "PYTHONHOME", "SAYCUT_API_TOKENS", "SAYCUT_TOKEN"}
    }
