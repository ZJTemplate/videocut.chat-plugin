class SaycutError(Exception):
    def __init__(self, code: str, message: str, status: int = 400, retryable: bool = False):
        super().__init__(message)
        self.code = code
        self.status = status
        self.retryable = retryable

    def payload(self) -> dict:
        return {"error": {"code": self.code, "message": str(self), "retryable": self.retryable}}
