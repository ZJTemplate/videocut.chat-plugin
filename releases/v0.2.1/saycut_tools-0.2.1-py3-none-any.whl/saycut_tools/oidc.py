"""Optional verification against an existing OAuth/OIDC authorization server."""

import hashlib

import httpx
import jwt

from .errors import SaycutError


class OIDCVerifier:
    def __init__(self, settings):
        if not settings.oidc_issuer.startswith("https://") or not settings.oidc_audience:
            raise SaycutError("oidc_config", "OIDC requires an HTTPS issuer and explicit audience")
        self.issuer, self.audience = settings.oidc_issuer.rstrip("/"), settings.oidc_audience
        response = httpx.get(
            self.issuer + "/.well-known/openid-configuration", timeout=10, follow_redirects=False
        )
        response.raise_for_status()
        metadata = response.json()
        if metadata["issuer"].rstrip("/") != self.issuer or not metadata["jwks_uri"].startswith("https://"):
            raise SaycutError("oidc_config", "OIDC discovery issuer does not match configuration")
        self.issuer = metadata["issuer"]
        self.jwks = jwt.PyJWKClient(metadata["jwks_uri"], timeout=10)

    def tenant(self, token):
        try:
            key = self.jwks.get_signing_key_from_jwt(token)
            claims = jwt.decode(
                token,
                key.key,
                algorithms=["RS256", "ES256"],
                audience=self.audience,
                issuer=self.issuer,
                options={"require": ["exp", "sub", "iss", "aud"]},
            )
            if "saycut:tools" not in str(claims.get("scope", "")).split():
                raise ValueError("Missing scope")
            return "oidc_" + hashlib.sha256((self.issuer + "\0" + claims["sub"]).encode()).hexdigest()[:48]
        except (jwt.PyJWTError, ValueError, TypeError) as exc:
            raise SaycutError(
                "unauthorized", "Invalid access token or missing saycut:tools scope", 401
            ) from exc
