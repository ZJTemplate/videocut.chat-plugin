from __future__ import annotations

import json
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

from .errors import SaycutError


def new_id(prefix):
    return prefix + "_" + secrets.token_hex(12)


class Store:
    def __init__(self, root: Path):
        self.root = root
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.database = root / "saycut.sqlite3"
        with self.connect() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS assets (
                    id TEXT PRIMARY KEY, tenant TEXT NOT NULL, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS projects (
                    id TEXT, tenant TEXT, revision INTEGER, value TEXT NOT NULL,
                    PRIMARY KEY (id, tenant, revision));
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, tenant TEXT NOT NULL, project_id TEXT NOT NULL,
                    revision INTEGER NOT NULL, idempotency_key TEXT NOT NULL,
                    status TEXT NOT NULL, cancel INTEGER NOT NULL DEFAULT 0,
                    created REAL NOT NULL, updated REAL NOT NULL, progress REAL NOT NULL DEFAULT 0,
                    result TEXT, error TEXT, UNIQUE (tenant, idempotency_key));
                CREATE TABLE IF NOT EXISTS events (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL,
                    job_id TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS handoffs (
                    token_hash TEXT PRIMARY KEY, tenant TEXT NOT NULL, job_id TEXT NOT NULL,
                    expires REAL NOT NULL);
            """)
        # Concurrent MCP/worker starts must check and migrate under one write lock.
        with self.connect(True) as db:
            if "request" not in {row[1] for row in db.execute("PRAGMA table_info(jobs)")}:
                db.execute("ALTER TABLE jobs ADD COLUMN request TEXT")
        self.database.chmod(0o600)

    @contextmanager
    def connect(self, write=False):
        db = sqlite3.connect(self.database, timeout=30)
        db.row_factory = sqlite3.Row
        try:
            if write:
                db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def asset(self, tenant, identifier):
        with self.connect() as db:
            row = db.execute(
                "SELECT value FROM assets WHERE id=? AND tenant=?", (identifier, tenant)
            ).fetchone()
        if not row:
            raise SaycutError("asset_not_found", "Asset not found", 404)
        return json.loads(row["value"])

    def add_asset(self, tenant, asset):
        with self.connect(True) as db:
            db.execute("INSERT INTO assets VALUES (?,?,?)", (asset["asset_id"], tenant, json.dumps(asset)))

    def project(self, tenant, identifier, revision=None):
        with self.connect() as db:
            row = db.execute(
                "SELECT revision,value FROM projects WHERE id=? AND tenant=? AND (? IS NULL OR revision=?) "
                "ORDER BY revision DESC LIMIT 1",
                (identifier, tenant, revision, revision),
            ).fetchone()
        if not row:
            raise SaycutError("project_not_found", "Project or revision not found", 404)
        return {"project_id": identifier, "revision": row["revision"], "project": json.loads(row["value"])}

    def save_project(self, tenant, spec: dict, identifier=None, expected_revision=None):
        identifier = identifier or new_id("project")
        with self.connect(True) as db:
            revision = db.execute(
                "SELECT MAX(revision) FROM projects WHERE id=? AND tenant=?", (identifier, tenant)
            ).fetchone()[0]
            if revision != expected_revision:
                raise SaycutError(
                    "revision_conflict", "Project changed; read the latest revision before editing", 409
                )
            revision = (revision or 0) + 1
            db.execute(
                "INSERT INTO projects VALUES (?,?,?,?)", (identifier, tenant, revision, json.dumps(spec))
            )
        return {"project_id": identifier, "revision": revision, "project": spec}

    @staticmethod
    def decode_job(row):
        value = dict(row)
        value.pop("tenant", None)
        value["job_id"] = value.pop("id")
        for key in ("result", "error", "request"):
            value[key] = json.loads(value[key]) if value[key] else None
        value["cancel_requested"] = bool(value.pop("cancel"))
        return value

    def job(self, tenant, identifier):
        with self.connect() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=? AND tenant=?", (identifier, tenant)).fetchone()
        if not row:
            raise SaycutError("job_not_found", "Job not found", 404)
        return self.decode_job(row)

    def create_job(self, tenant, project_id, revision, key, max_active, request=None):
        self.project(tenant, project_id, revision)
        with self.connect(True) as db:
            existing = db.execute(
                "SELECT * FROM jobs WHERE tenant=? AND idempotency_key=?", (tenant, key)
            ).fetchone()
            if existing:
                if (
                    existing["project_id"] != project_id
                    or existing["revision"] != revision
                    or (json.loads(existing["request"]) if existing["request"] else None) != (request or None)
                ):
                    raise SaycutError("idempotency_conflict", "Key already used for a different render", 409)
                return self.decode_job(existing), False
            active = db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[
                0
            ]
            if active >= max_active:
                raise SaycutError("queue_full", "Local render queue is full", 429, retryable=True)
            identifier, now = new_id("job"), time.time()
            db.execute(
                "INSERT INTO jobs(id,tenant,project_id,revision,idempotency_key,status,created,updated,request) "
                "VALUES (?,?,?,?,?,'queued',?,?,?)",
                (
                    identifier,
                    tenant,
                    project_id,
                    revision,
                    key,
                    now,
                    now,
                    json.dumps(request) if request else None,
                ),
            )
            self.event(db, tenant, identifier, "queued")
        return self.job(tenant, identifier), True

    def job_by_key(self, tenant, key):
        with self.connect() as db:
            row = db.execute(
                "SELECT * FROM jobs WHERE tenant=? AND idempotency_key=?", (tenant, key)
            ).fetchone()
        return self.decode_job(row) if row else None

    @staticmethod
    def event(db, tenant, job, status):
        db.execute(
            "INSERT INTO events(tenant,job_id,status,created) VALUES (?,?,?,?)",
            (tenant, job, status, time.time()),
        )

    def update_job(
        self, tenant, identifier, status=None, progress=None, result=None, error=None, claim=False
    ):
        with self.connect(True) as db:
            row = db.execute("SELECT * FROM jobs WHERE id=? AND tenant=?", (identifier, tenant)).fetchone()
            if not row or (claim and row["status"] != "queued"):
                return False
            if row["status"] in ("succeeded", "failed", "cancelled"):
                return False
            if row["cancel"] and status == "succeeded":
                status, result = "cancelled", None
            db.execute(
                "UPDATE jobs SET status=?,updated=?,progress=?,result=?,error=? WHERE id=? AND tenant=?",
                (
                    status or row["status"],
                    time.time(),
                    progress if progress is not None else row["progress"],
                    json.dumps(result) if result else row["result"],
                    json.dumps(error) if error else row["error"],
                    identifier,
                    tenant,
                ),
            )
            if status and status != row["status"]:
                self.event(db, tenant, identifier, status)
        return True

    def cancel_job(self, tenant, identifier):
        self.job(tenant, identifier)
        with self.connect(True) as db:
            db.execute(
                "UPDATE jobs SET cancel=1 WHERE id=? AND tenant=? AND status IN ('queued','running')",
                (identifier, tenant),
            )
            cancelled = db.execute(
                "UPDATE jobs SET status='cancelled',updated=? WHERE id=? AND tenant=? AND status='queued'",
                (time.time(), identifier, tenant),
            )
            if cancelled.rowcount:
                self.event(db, tenant, identifier, "cancelled")
        return self.job(tenant, identifier)

    def events(self, tenant, after=0, limit=100):
        with self.connect() as db:
            rows = db.execute(
                "SELECT sequence,job_id,status,created FROM events WHERE tenant=? AND sequence>? "
                "ORDER BY sequence LIMIT ?",
                (tenant, after, limit),
            ).fetchall()
        return {"items": [dict(row) for row in rows], "cursor": rows[-1]["sequence"] if rows else after}
