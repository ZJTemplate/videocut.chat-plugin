"""Small transactional cloud repository. No FC instance-local state is authoritative."""

from __future__ import annotations

import json
import time
from contextlib import contextmanager

from sqlalchemy import (
    Column,
    Float,
    Integer,
    MetaData,
    String,
    Table,
    Text,
    create_engine,
    insert,
    select,
    update,
)
from sqlalchemy.dialects.mysql import MEDIUMTEXT
from sqlalchemy.exc import IntegrityError

from .errors import SaycutError
from .store import new_id

TERMINAL = {"succeeded", "failed", "cancelled"}


class CloudStore:
    def __init__(self, url: str):
        if not url:
            raise SaycutError("database_required", "Set SAYCUT_DATABASE_URL to a persistent SQL database")
        self.engine = create_engine(url, pool_pre_ping=True, pool_recycle=300, hide_parameters=True)
        metadata = MetaData()
        self.docs = Table(
            "saycut_documents",
            metadata,
            Column("kind", String(24), primary_key=True),
            Column("tenant", String(64), primary_key=True),
            Column("id", String(160), primary_key=True),
            Column("state", String(24), index=True),
            Column("payload", Text().with_variant(MEDIUMTEXT(), "mysql"), nullable=False),
        )
        self.event_table = Table(
            "saycut_events",
            metadata,
            Column("sequence", Integer, primary_key=True, autoincrement=True),
            Column("tenant", String(64), nullable=False, index=True),
            Column("job_id", String(100), nullable=False),
            Column("status", String(24), nullable=False),
            Column("created", Float, nullable=False),
        )
        metadata.create_all(self.engine)
        try:
            with self.engine.begin() as db:
                db.execute(insert(self.docs).values(kind="lock", tenant="system", id="writes", payload="{}"))
        except IntegrityError:
            pass

    @contextmanager
    def transaction(self):
        with self.engine.connect() as db:
            if self.engine.dialect.name == "sqlite":
                db.exec_driver_sql("BEGIN IMMEDIATE")
            else:
                db.begin()
            try:
                # Short metadata writes are serialized; no network calls occur while holding this lock.
                db.execute(
                    select(self.docs.c.id).where(self.where("lock", "system", "writes")).with_for_update()
                ).one()
                yield db
                db.commit()
            except BaseException:
                db.rollback()
                raise

    def where(self, kind, tenant, identifier):
        return (self.docs.c.kind == kind) & (self.docs.c.tenant == tenant) & (self.docs.c.id == identifier)

    def read(self, db, kind, tenant, identifier, required=True):
        value = db.execute(select(self.docs.c.payload).where(self.where(kind, tenant, identifier))).scalar()
        if value is None:
            if required:
                raise SaycutError(kind + "_not_found", "Requested item was not found", 404)
            return None
        return json.loads(value)

    def write(self, db, kind, tenant, identifier, value, create=False):
        payload = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        values = {"payload": payload, "state": value.get("status")}
        if create:
            db.execute(insert(self.docs).values(kind=kind, tenant=tenant, id=identifier, **values))
        else:
            db.execute(update(self.docs).where(self.where(kind, tenant, identifier)).values(**values))

    def get(self, kind, tenant, identifier):
        with self.engine.connect() as db:
            return self.read(db, kind, tenant, identifier)

    def asset(self, tenant, identifier):
        return self.get("asset", tenant, identifier)

    def add_asset(self, tenant, asset):
        with self.transaction() as db:
            self.write(db, "asset", tenant, asset["asset_id"], asset, create=True)

    def project(self, tenant, identifier, revision=None):
        with self.engine.connect() as db:
            head = self.read(db, "project", tenant, identifier)
            if revision is None or revision == head["revision"]:
                return head
            return self.read(db, "revision", tenant, identifier + ":" + str(revision))

    def save_project(self, tenant, spec, identifier=None, expected_revision=None):
        identifier = identifier or new_id("project")
        with self.transaction() as db:
            head = self.read(db, "project", tenant, identifier, False)
            previous = head["revision"] if head else None
            if previous != expected_revision:
                raise SaycutError("revision_conflict", "Read the latest project revision", 409)
            value = {"project_id": identifier, "revision": (previous or 0) + 1, "project": spec}
            self.write(db, "project", tenant, identifier, value, create=head is None)
            self.write(db, "revision", tenant, identifier + ":" + str(value["revision"]), value, True)
        return value

    def event(self, db, tenant, job, status):
        db.execute(
            insert(self.event_table).values(tenant=tenant, job_id=job, status=status, created=time.time())
        )

    def job(self, tenant, identifier):
        return self.get("job", tenant, identifier)

    def job_by_key(self, tenant, key):
        with self.engine.connect() as db:
            ref = self.read(db, "key", tenant, key, False)
            return self.read(db, "job", tenant, ref["job_id"]) if ref else None

    def enqueue(self, tenant, request, key, fingerprint, max_active, ttl, project_id=None, revision=1):
        with self.transaction() as db:
            ref = self.read(db, "key", tenant, key, False)
            if ref:
                job = self.read(db, "job", tenant, ref["job_id"])
                if job["fingerprint"] != fingerprint:
                    raise SaycutError("idempotency_conflict", "Key already used for another request", 409)
                return job, False
            active = db.execute(
                select(self.docs.c.id).where((self.docs.c.kind == "job") & self.docs.c.state.not_in(TERMINAL))
            ).fetchall()
            if len(active) >= max_active:
                raise SaycutError("queue_full", "The cloud render queue is full", 429, True)
            identifier, now = new_id("job"), time.time()
            job = {
                "job_id": identifier,
                "project_id": project_id,
                "revision": revision,
                "status": "queued",
                "created": now,
                "updated": now,
                "progress": 0,
                "cancel_requested": False,
                "result": None,
                "error": None,
                "request": request,
                "fingerprint": fingerprint,
                "deadline": now + ttl,
                "dispatch_after": 0,
                "dispatches": 0,
                "upstream_ids": [],
                "lease_until": 0,
                "run_id": None,
                "attempt": 0,
                "uploads": {},
            }
            self.write(db, "job", tenant, identifier, job, True)
            self.write(db, "key", tenant, key, {"job_id": identifier}, True)
            self.event(db, tenant, identifier, "queued")
        return job, True

    def mutate_job(self, tenant, identifier, mutate):
        with self.transaction() as db:
            job = self.read(db, "job", tenant, identifier)
            status = job["status"]
            result = mutate(job)
            job["updated"] = time.time()
            self.write(db, "job", tenant, identifier, job)
            if status != job["status"]:
                self.event(db, tenant, identifier, job["status"])
        return job, result

    def cancel_job(self, tenant, identifier):
        def cancel(job):
            if job["status"] not in TERMINAL:
                job["cancel_requested"] = True
                if job["status"] == "queued":
                    job["status"] = "cancelled"

        return self.mutate_job(tenant, identifier, cancel)[0]

    def events(self, tenant, after=0, limit=100):
        with self.engine.connect() as db:
            rows = (
                db.execute(
                    select(self.event_table)
                    .where((self.event_table.c.tenant == tenant) & (self.event_table.c.sequence > after))
                    .order_by(self.event_table.c.sequence)
                    .limit(limit)
                )
                .mappings()
                .all()
            )
        return {"items": [dict(row) for row in rows], "cursor": rows[-1]["sequence"] if rows else after}

    def pending(self, limit=64):
        with self.engine.connect() as db:
            rows = db.execute(
                select(self.docs.c.tenant, self.docs.c.id)
                .where((self.docs.c.kind == "job") & self.docs.c.state.not_in(TERMINAL))
                .limit(limit)
            ).all()
        return list(rows)
