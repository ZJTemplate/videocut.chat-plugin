from __future__ import annotations

import ast
import copy
import hashlib
import json
import re
import stat
import zipfile
from pathlib import Path, PurePosixPath

from jsonschema import Draft202012Validator

from .config import Settings, write_json
from .download import download
from .errors import SaycutError


def digest(path: Path, algorithm="sha256") -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, algorithm).hexdigest()


def editable(key: str, value) -> bool:
    # Files, scripts, shader sources and bindings are owned by the compiler, never the model.
    name = key.split(":", 1)[-1].lower()
    base = re.sub(r"_\d+$", "", name)
    return not (
        re.search(r"(path|dir|url)$|script|shader|systemfont|listener|source|asrjson|lyricjson", base)
        or "texture" in name
        and isinstance(value, str | list)
        or name.startswith("text")
        and name != "textcount"
        or isinstance(value, dict)
    )


def schema_for(defaults: dict, numeric: dict | None = None) -> dict:
    properties = {}
    for key, value in defaults.items():
        if not editable(key, value):
            continue
        if isinstance(value, bool):
            item = {"type": "boolean"}
        elif isinstance(value, (int, float)):
            item = {
                "type": "integer" if isinstance(value, int) else "number",
                "minimum": -10000,
                "maximum": 10000,
            }
        elif isinstance(value, str):
            item = {"type": "string", "maxLength": 2048}
        elif isinstance(value, list) and all(isinstance(v, (int, float)) for v in value):
            item = {
                "type": "array",
                "items": {"type": "number", "minimum": -10000, "maximum": 10000},
                "minItems": len(value),
                "maxItems": len(value),
            }
            if "color" in key.lower():
                item["items"] = {"type": "number", "minimum": 0, "maximum": 1}
        else:
            continue
        item.update((numeric or {}).get(key, {}))
        properties[key] = item
    return {"type": "object", "properties": properties, "additionalProperties": False}


def motion_presets(path: Path) -> dict:
    """Read only literal preset data. Importing this module would start unrelated integrations."""
    presets, palettes = {}, []
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign):
            names = [n.id for n in node.targets if isinstance(n, ast.Name)]
            if "MOTION_SUBTITLE_PRESETS" in names:
                presets = ast.literal_eval(node.value)
            elif "_CATALOG_PALETTES" in names:
                palettes = ast.literal_eval(node.value)
        elif (
            isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Attribute)
            and isinstance(node.value.func.value, ast.Name)
            and node.value.func.value.id == "MOTION_SUBTITLE_PRESETS"
            and node.value.func.attr == "update"
        ):
            mapping = node.value.args[0]
            if not isinstance(mapping, ast.Dict):
                raise TypeError("Preset update must be a literal dictionary")
            for key, call in zip(mapping.keys, mapping.values):
                if (
                    not isinstance(call, ast.Call)
                    or not isinstance(call.func, ast.Name)
                    or call.func.id != "_catalog_preset"
                ):
                    raise ValueError("Unknown preset expression")
                values = [ast.literal_eval(arg) for arg in call.args]
                kwargs = {kw.arg: ast.literal_eval(kw.value) for kw in call.keywords}
                mode, duration = values[:2]
                palette = values[2] if len(values) > 2 else kwargs.get("palette", 0)
                strength = values[3] if len(values) > 3 else kwargs.get("strength", 1.0)
                presets[ast.literal_eval(key)] = (mode, strength, duration, *palettes[palette])
    return presets


def import_catalog(
    runtime_catalog: Path, smartcut: Path, subtitle_source: Path, output: Path
) -> dict[str, str]:
    source = json.loads(runtime_catalog.read_text())
    styles, paths = {}, {}
    for name, runtime in source["runtimes"].items():
        entry = copy.deepcopy(runtime)
        entry.update(id=f"runtime/{name}", name=name, kind="runtime", resource_id=f"runtime/{name}")
        entry["parameter_schema"] = schema_for(entry["defaults"], entry.get("numeric_schema"))
        styles[entry["id"]] = entry
    for name, preset in motion_presets(subtitle_source).items():
        mode, strength, duration, color, accent, secondary = preset
        entry = copy.deepcopy(styles["runtime/ZapMotion"])
        entry.update(id=f"motion/{name}", name=name, kind="motion_preset", resource_id="runtime/ZapMotion")
        entry["defaults"].update(
            {
                "0:MotionMode": mode,
                "0:MotionStrength": strength,
                "0:MotionDuration": duration,
                "0:MotionTextColor": color,
                "0:MotionAccentColor": accent,
                "0:MotionSecondaryColor": secondary,
                "0:Color1": color,
            }
        )
        styles[entry["id"]] = entry
    for folder in ("text", "text_hidden"):
        for effect in sorted((smartcut / folder).rglob("*.fceffect")):
            data = json.loads(effect.read_text())
            defaults = {}
            for index, filt in enumerate(data.get("filter_list", [])):
                for key, group in filt.items():
                    if key.startswith("param") and isinstance(group, dict):
                        defaults.update({f"{index}:{k}": v for k, v in group.items()})
            name = effect.parent.relative_to(smartcut).as_posix()
            identifier = "smartcut/" + name
            styles[identifier] = {
                "id": identifier,
                "name": effect.parent.name,
                "kind": "smartcut_effect",
                "resource_id": identifier,
                "defaults": defaults,
                "label_suffixes": [""],
                "parameter_schema": schema_for(defaults),
                "source_sha256": digest(effect),
                "verification": "imported_not_render_verified",
            }
            paths[identifier] = str(effect.resolve())
    write_json(output, {"version": 1, "package_version": source["package_version"], "styles": styles})
    return paths


def safe_extract(archive: Path, target: Path, max_bytes=1024 * 1024 * 1024):
    with zipfile.ZipFile(archive) as package:
        entries = package.infolist()
        if len(entries) > 30000 or sum(e.file_size for e in entries) > max_bytes:
            raise SaycutError("unsafe_archive", "Resource archive exceeds extraction limits")
        for entry in entries:
            relative = PurePosixPath(entry.filename)
            mode = entry.external_attr >> 16
            if (
                relative.is_absolute()
                or ".." in relative.parts
                or "\\" in entry.filename
                or ":" in entry.filename
                or stat.S_ISLNK(mode)
            ):
                raise SaycutError("unsafe_archive", "Resource archive contains unsafe paths")
        package.extractall(target)


def sync_packages(settings: Settings) -> dict[str, str]:
    catalog = Catalog(settings)
    sources = dict(settings.effect_sources)
    packages = {}
    for entry in catalog.styles.values():
        if entry["kind"] == "runtime":
            packages.setdefault(entry["material_md5"].lower(), []).append(entry)
    for checksum, entries in packages.items():
        root = settings.data_dir / "packages" / checksum
        marker = root / ".verified.json"
        if not marker.is_file():
            root.mkdir(parents=True, exist_ok=True)
            archive = root / "package.zip"
            if archive.is_file() and digest(archive, "md5") != checksum:
                archive.unlink()
            if not archive.is_file():
                download(entries[0]["material_url"], archive, 512 * 1024 * 1024)
            if digest(archive, "md5") != checksum:
                archive.unlink()
                raise SaycutError(
                    "checksum_mismatch", "Resource package checksum does not match the source catalog"
                )
            safe_extract(archive, root / "content")
            write_json(marker, {"sha256": digest(archive), "upstream_md5": checksum})
        for entry in entries:
            matches = list((root / "content").rglob(entry["name"] + "/text.fceffect"))
            if len(matches) != 1:
                raise SaycutError("resource_missing", f"Cannot uniquely resolve resource {entry['id']}")
            sources[entry["resource_id"]] = str(matches[0].resolve())
    return sources


class Catalog:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.data = (
            json.loads(settings.catalog_file.read_text())
            if settings.catalog_file.is_file()
            else {"styles": {}}
        )
        self.styles = self.data["styles"]

    def get(self, identifier: str) -> dict:
        if identifier not in self.styles:
            raise SaycutError("style_not_found", "Unknown style ID; call saycut_list_styles first", 404)
        entry = copy.deepcopy(self.styles[identifier])
        entry["available"] = self.available(entry)
        return entry

    def available(self, entry: dict) -> bool:
        resource = self.settings.effect_sources.get(entry["resource_id"])
        if not resource or not Path(resource).is_file():
            return False
        return not self.missing_fonts(entry)

    def missing_fonts(self, entry: dict) -> list[str]:
        resource = self.settings.effect_sources.get(entry["resource_id"])
        if not resource:
            return []
        fallback = self.settings.fallback_font
        if fallback and fallback.is_file():
            return []
        return [
            value
            for key, value in entry["defaults"].items()
            if "CustomFontPath" in key and value and not (Path(resource).parent / value).is_file()
        ]

    def path(self, identifier: str) -> Path:
        entry = self.get(identifier)
        path = self.settings.effect_sources.get(entry["resource_id"])
        if not path or not Path(path).is_file():
            raise SaycutError(
                "resource_unavailable", "Style is catalogued but not installed; run catalog sync"
            )
        return Path(path).resolve()

    def validate(self, identifier: str, params: dict, require_available=True) -> dict:
        entry = self.get(identifier)
        errors = list(Draft202012Validator(entry["parameter_schema"]).iter_errors(params))
        if errors:
            raise SaycutError("invalid_effect_parameters", errors[0].message[:1000])
        if require_available:
            self.path(identifier)
        return entry

    def list(self, query="", offset=0, limit=20, available_only=False) -> dict:
        rows = [
            {
                "id": e["id"],
                "name": e["name"],
                "kind": e["kind"],
                "available": self.available(e),
                "verification": e["verification"],
            }
            for e in self.styles.values()
            if query.lower() in (e["id"] + e["name"]).lower() and (not available_only or self.available(e))
        ]
        return {
            "total": len(rows),
            "items": rows[offset : offset + limit],
            "next_offset": offset + limit if offset + limit < len(rows) else None,
        }
