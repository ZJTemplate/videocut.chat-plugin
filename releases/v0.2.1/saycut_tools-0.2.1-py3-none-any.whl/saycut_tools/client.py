from __future__ import annotations

import mimetypes
import time
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from .errors import SaycutError
from .registry import BY_NAME


class SaycutClient:
    def __init__(self, base_url: str, token: str, transport=None):
        parsed = urlsplit(base_url)
        if parsed.scheme != "https" and not (
            parsed.scheme == "http" and parsed.hostname in ("localhost", "127.0.0.1", "::1")
        ):
            raise ValueError("Use HTTPS except for loopback development")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Base URL may not contain credentials, query or fragment")
        self.http = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={"Authorization": "Bearer " + token},
            timeout=60,
            follow_redirects=False,
            trust_env=False,
            transport=transport,
        )

    def close(self):
        self.http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    @staticmethod
    def decode(response):
        try:
            data = response.json()
        except ValueError as exc:
            raise SaycutError(
                "invalid_http_response",
                f"Saycut gateway returned a non-JSON HTTP {response.status_code} response",
                502,
            ) from exc
        if not isinstance(data, dict):
            raise SaycutError("invalid_http_response", "Gateway response must be a JSON object", 502, True)
        if not response.is_success or set(data) == {"error"}:
            error = data.get("error")
            if not isinstance(error, dict):
                raise SaycutError(
                    "http_error", "Gateway request failed", max(400, response.status_code), True
                )
            raise SaycutError(
                error["code"] if isinstance(error.get("code"), str) else "http_error",
                error["message"] if isinstance(error.get("message"), str) else "Saycut request failed",
                response.status_code if response.status_code >= 400 else 502,
                error.get("retryable") is True or response.status_code in (429, 502, 503, 504),
            )
        return data

    def call(self, name: str, arguments: dict) -> dict:
        if name not in BY_NAME:
            raise SaycutError("unknown_tool", "Unknown Saycut tool")
        payload = BY_NAME[name].model.model_validate(arguments).model_dump(mode="json")
        try:
            response = self.http.post("/v1/tools/" + name, json=payload)
        except httpx.HTTPError:
            raise SaycutError(
                "gateway_unavailable",
                "Gateway request failed; retry submissions with the same idempotency key",
                503,
                True,
            ) from None
        return self.decode(response)

    def upload(self, path: str | Path):
        path = Path(path)
        capabilities = self.call("saycut_capabilities", {})
        if capabilities.get("upload") == "oss_direct":
            grant = self.call(
                "saycut_prepare_upload",
                {
                    "filename": path.name,
                    "bytes": path.stat().st_size,
                    "content_type": mimetypes.guess_type(path.name)[0] or "application/octet-stream",
                },
            )
            upload = grant["upload"]
            with (
                path.open("rb") as stream,
                httpx.Client(timeout=300, trust_env=False, follow_redirects=False) as client,
            ):
                result = client.put(upload["url"], content=stream, headers=upload["headers"])
                result.raise_for_status()
            return self.call("saycut_complete_upload", {"asset_id": grant["asset_id"]})
        with path.open("rb") as stream:
            return self.decode(
                self.http.post(
                    "/v1/assets/upload",
                    params={"filename": path.name},
                    content=stream,
                    headers={"Content-Type": "application/octet-stream"},
                )
            )

    def wait(self, job_id: str, timeout=1800, interval=2):
        deadline = time.monotonic() + timeout
        while True:
            job = self.call("saycut_get_job", {"job_id": job_id})
            if job["status"] not in ("queued", "running"):
                return job
            if time.monotonic() >= deadline:
                raise TimeoutError("Job is still running; poll later or explicitly cancel it")
            time.sleep(interval)

    def download(self, job_id: str, destination: Path, kind="video"):
        if (
            kind not in ("video", "bundle", "sky_json")
            or not job_id.startswith("job_")
            or not job_id.replace("_", "").isalnum()
        ):
            raise ValueError("Invalid output reference")
        temporary = destination.with_name(destination.name + ".part")
        if destination.exists() or temporary.exists():
            raise FileExistsError(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            with self.http.stream("GET", f"/v1/jobs/{job_id}/files/{kind}") as response:
                if response.status_code == 303:
                    from .download import download

                    download(response.headers["Location"], temporary, 8 * 1024 * 1024 * 1024)
                else:
                    response.raise_for_status()
                    with temporary.open("xb") as output:
                        for chunk in response.iter_bytes():
                            output.write(chunk)
            temporary.rename(destination)
        finally:
            temporary.unlink(missing_ok=True)
        return destination
