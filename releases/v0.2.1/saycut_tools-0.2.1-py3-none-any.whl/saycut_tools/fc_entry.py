"""FC web gateway and a separate event-only reconciliation function."""

from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, HTTPServer

from .config import Settings
from .http import create_app
from .service import create_service


def web():
    return create_app(Settings.load())


def timer():
    service = create_service(Settings.load())

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            if self.path not in ("/invoke", "/initialize"):
                self.send_error(404)
                return
            try:
                result = service.reconcile() if self.path == "/invoke" else {"status": "ready"}
                body = json.dumps(result).encode()
                self.send_response(200)
            except Exception:  # noqa: BLE001 - never leak database credentials through FC invocation errors
                body = b'{"error":"reconciliation_failed"}'
                self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    HTTPServer(("0.0.0.0", 9000), Handler).serve_forever()


if __name__ == "__main__":
    timer()
