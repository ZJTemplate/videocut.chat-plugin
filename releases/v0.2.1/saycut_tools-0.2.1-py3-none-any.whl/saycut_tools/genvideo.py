"""GenVideo's saycut_tools_v1 handler. Rendering stays on the worker computer."""

from __future__ import annotations

import argparse
import json
import mimetypes
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from . import models as m
from .config import Settings, write_json
from .errors import SaycutError
from .service import Service


class Gateway:
    def __init__(self, settings, payload, client=None):
        origin = payload["gateway"].rstrip("/")
        if origin not in [value.rstrip("/") for value in settings.worker_origins]:
            raise SaycutError("untrusted_gateway", "Task gateway is not in the worker's configured origins")
        parts = urlsplit(origin)
        if parts.scheme != "https" and not (
            parts.scheme == "http" and parts.hostname in ("127.0.0.1", "localhost")
        ):
            raise SaycutError("untrusted_gateway", "Gateway must use HTTPS")
        m.JobRef(job_id=payload["job_id"])
        self.path = "/internal/jobs/" + payload["job_id"] + "/"
        self.client = client or httpx.Client(
            base_url=origin,
            headers={"Authorization": "Bearer " + payload["capability"]},
            timeout=30,
            trust_env=False,
            follow_redirects=False,
        )

    def call(self, operation, body):
        try:
            response = self.client.post(self.path + operation, json=body)
            value = response.json()
            if response.is_error:
                error = value.get("error", {})
                raise SaycutError(
                    error.get("code", "gateway_failed"),
                    "Gateway rejected worker operation",
                    response.status_code,
                )
            return value
        except (httpx.HTTPError, ValueError) as exc:
            raise SaycutError("gateway_unavailable", "Cannot reach the job gateway", 503, True) from exc


class Heartbeats:
    def __init__(self, gateway, lease, seconds):
        self.gateway, self.lease, self.seconds = gateway, lease, seconds
        self.stop = threading.Event()
        self.progress = 0.0
        self.cancelled = False
        self.lost = False
        self.last_success = time.monotonic()
        self.thread = threading.Thread(target=self.run, daemon=True)

    def run(self):
        while not self.stop.wait(min(10, self.seconds / 4)):
            try:
                result = self.gateway.call("heartbeat", {**self.lease, "progress": self.progress})
                self.cancelled = result["cancel_requested"]
                self.last_success = time.monotonic()
            except SaycutError as exc:
                if exc.status in (401, 403, 409) or time.monotonic() - self.last_success > self.seconds - 15:
                    self.lost = True

    def check(self):
        if self.cancelled:
            raise SaycutError("cancel_requested", "The user cancelled this render")
        if self.lost or time.monotonic() - self.last_success > self.seconds - 5:
            raise SaycutError("lease_lost", "Worker lease lost; refusing to publish stale output")

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.stop.set()
        self.thread.join(timeout=35)


def publish(gateway, lease, beats, local, local_job, reverse, settings):
    result = local_job["result"]
    folder = settings.data_dir / "jobs" / local_job["job_id"]
    files = {
        "outputs/video.mp4": Path(result["video"]),
        "outputs/project.zip": Path(result["bundle"]),
        "outputs/timeline.sky": Path(result["sky_json"]),
    }
    for path in (folder / "native-project").rglob("*"):
        if path.is_file():
            files["native-project/" + path.relative_to(folder / "native-project").as_posix()] = path
    entries = list(files.items())
    for offset in range(0, len(entries), 40):
        beats.check()
        batch = dict(entries[offset : offset + 40])
        grants = gateway.call(
            "uploads",
            {
                **lease,
                "files": {
                    name: {
                        "bytes": path.stat().st_size,
                        "content_type": mimetypes.guess_type(path.name)[0] or "application/octet-stream",
                    }
                    for name, path in batch.items()
                },
            },
        )["uploads"]
        for name, path in batch.items():
            beats.check()
            grant = grants[name]
            # Use a different client: a worker capability must never be forwarded to object storage.
            with (
                path.open("rb") as stream,
                httpx.Client(timeout=120, trust_env=False, follow_redirects=False) as client,
            ):
                response = client.put(grant["url"], content=stream, headers=grant["headers"])
                response.raise_for_status()
    project = local.store.project("local", result["project_id"], result["revision"])["project"]
    for clip in project["clips"]:
        clip["asset_id"] = reverse[clip["asset_id"]]
    if project["font_asset_id"]:
        project["font_asset_id"] = reverse[project["font_asset_id"]]
    assets = {
        cloud_id: {
            k: v
            for k, v in local.store.asset("local", local_id).items()
            if k in ("kind", "duration", "width", "height", "fps", "bytes")
        }
        for local_id, cloud_id in reverse.items()
    }
    gateway.call(
        "complete",
        {**lease, "project": project, "assets": assets, "media": result["media"], "usage": result["usage"]},
    )


def run_task(data: dict, settings: Settings, gateway_factory=Gateway):
    payload = data.get("params", {})
    if payload.get("tid") != "saycut_tools_v1":
        raise SaycutError("unsupported_widget_task", "Expected GenVideo params.tid=saycut_tools_v1")
    gateway = gateway_factory(settings, payload)
    run_id = uuid.uuid4().hex
    try:
        claim = gateway.call("claim", {"run_id": run_id})
    except BaseException:
        gateway.client.close()
        raise
    lease = {"run_id": run_id, "attempt": claim["attempt"]}
    local_job = None
    settings = settings.model_copy(update={"backend": "local", "allow_remote_urls": True})
    local = Service(settings)
    try:
        with Heartbeats(gateway, lease, claim["lease_seconds"]) as beats:
            request = claim["request"]
            mapping = {}
            for identifier, asset in request["assets"].items():
                beats.check()
                mapping[identifier] = local.import_asset(
                    m.ImportAsset(url=asset["url"], filename=asset["filename"]), "local"
                )["asset_id"]
            key = payload["job_id"] + ":" + str(claim["attempt"])
            if request["operation"] == "render_video":
                arguments = request["arguments"]
                arguments["asset_id"] = mapping[arguments["asset_id"]]
                arguments["idempotency_key"] = key
                local_job = local.render_video(m.RenderVideo.model_validate(arguments), "local", True)
            else:
                spec = request["project"]
                for clip in spec["clips"]:
                    clip["asset_id"] = mapping[clip["asset_id"]]
                if spec["font_asset_id"]:
                    spec["font_asset_id"] = mapping[spec["font_asset_id"]]
                project = local.create_project(
                    m.CreateProject(project=m.ProjectSpec.model_validate(spec)), "local"
                )
                local_job = local.render_project(
                    m.RenderProject(
                        project_id=project["project_id"], revision=project["revision"], idempotency_key=key
                    ),
                    "local",
                    True,
                )
            while local_job["status"] in ("queued", "running"):
                beats.check()
                beats.progress = min(0.9, local_job["progress"] * 0.9)
                time.sleep(1)
                local_job = local.get_job(m.JobRef(job_id=local_job["job_id"]), "local", True)
            if local_job["status"] != "succeeded":
                error = local_job.get("error") or {"code": "render_failed"}
                raise SaycutError(error["code"], "Native job did not succeed")
            beats.check()
            publish(gateway, lease, beats, local, local_job, {v: k for k, v in mapping.items()}, settings)
        return {"status": 0, "message": "", "result": {"job_id": payload["job_id"], "completed": True}}
    except Exception as exc:  # noqa: BLE001 - widget boundary; report only a sanitized failure code
        if local_job and local_job["status"] in ("queued", "running"):
            local.cancel_job(m.JobRef(job_id=local_job["job_id"]), "local", True)
        code = exc.code if isinstance(exc, SaycutError) else "worker_failed"
        try:
            gateway.call("failed", {**lease, "code": code})
        except SaycutError:
            pass
        return {"status": -1, "message": code, "result": {"job_id": payload["job_id"]}}
    finally:
        gateway.client.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = run_task(json.loads(args.run.read_text()), Settings.load(args.config))
    except Exception:  # noqa: BLE001 - keep secrets and provider tracebacks out of task results
        result = {"status": -1, "message": "widget_initialization_failed", "result": {}}
    write_json(args.out, result)


if __name__ == "__main__":
    main()
