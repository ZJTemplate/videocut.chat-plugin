from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from fractions import Fraction
from pathlib import Path
from urllib.parse import unquote, urlsplit

from .config import Settings
from .download import download
from .errors import SaycutError
from .store import Store, new_id

EXTENSIONS = {
    ".mp4",
    ".mov",
    ".mkv",
    ".webm",
    ".m4v",
    ".mp3",
    ".wav",
    ".m4a",
    ".aac",
    ".ogg",
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".ttf",
    ".otf",
    ".woff",
    ".woff2",
}
FONTS = {".ttf", ".otf", ".woff", ".woff2"}


def probe(path: Path, binary: str) -> dict:
    try:
        result = subprocess.run(
            [
                binary,
                "-v",
                "error",
                "-protocol_whitelist",
                "file,pipe",
                "-show_format",
                "-show_streams",
                "-of",
                "json",
                str(path),
            ],
            capture_output=True,
            timeout=30,
            check=True,
        )
        metadata = json.loads(result.stdout)
        video = next((s for s in metadata["streams"] if s["codec_type"] == "video"), None)
        return {
            "kind": "video" if video else "audio",
            "duration": float(metadata.get("format", {}).get("duration", 0)),
            "width": video.get("width") if video else None,
            "height": video.get("height") if video else None,
            "fps": float(Fraction(video.get("avg_frame_rate", "0/1")))
            if video and video.get("avg_frame_rate") != "0/0"
            else None,
        }
    except (subprocess.SubprocessError, ValueError, KeyError) as exc:
        raise SaycutError("invalid_media", "ffprobe could not read a supported media stream") from exc


class Assets:
    def __init__(self, settings: Settings, store: Store):
        self.settings, self.store = settings, store

    def destination(self, filename):
        extension = Path(filename).suffix.lower()
        if extension not in EXTENSIONS:
            raise SaycutError("unsupported_asset", "Unsupported media or font extension")
        identifier = new_id("asset")
        folder = self.settings.data_dir / "assets" / identifier
        folder.mkdir(parents=True, mode=0o700)
        return identifier, folder / ("source" + extension)

    def register(self, tenant, identifier, path, filename):
        if path.stat().st_size > self.settings.max_asset_bytes:
            raise SaycutError("asset_too_large", "Asset exceeds the configured byte limit")
        path.chmod(0o600)
        if path.suffix in FONTS:
            with path.open("rb") as stream:
                if stream.read(4) not in (b"\x00\x01\x00\x00", b"OTTO", b"wOFF", b"wOF2", b"ttcf"):
                    raise SaycutError("invalid_font", "Unsupported font signature")
            info = {"kind": "font", "duration": 0}
        else:
            info = probe(path, self.settings.ffprobe)
            if path.suffix in {".png", ".jpg", ".jpeg", ".webp"}:
                info["kind"] = "image"
        with path.open("rb") as stream:
            checksum = hashlib.file_digest(stream, "sha256").hexdigest()
        asset = {
            "asset_id": identifier,
            "filename": Path(filename).name[:200],
            "bytes": path.stat().st_size,
            "sha256": checksum,
            "path": str(path.resolve()),
            **info,
        }
        self.store.add_asset(tenant, asset)
        return self.public(asset)

    @staticmethod
    def public(asset):
        return {k: v for k, v in asset.items() if k != "path"}

    def import_asset(self, tenant, path=None, url=None, filename=None, local_access=False):
        if path:
            if not local_access:
                raise SaycutError(
                    "local_access_denied",
                    "HTTP clients must upload media; local paths are only allowed via stdio/CLI",
                    403,
                )
            source = Path(path).expanduser().resolve(strict=True)
            if not any(source.is_relative_to(root) for root in self.settings.allowed_roots):
                raise SaycutError("path_not_allowed", "Asset is outside configured allowed_roots", 403)
            if not source.is_file() or source.stat().st_size > self.settings.max_asset_bytes:
                raise SaycutError("invalid_asset", "Expected a regular file within the configured size limit")
            filename = source.name
        else:
            if not self.settings.allow_remote_urls:
                raise SaycutError(
                    "remote_urls_disabled",
                    "Remote URL downloads are disabled; upload media or enable allow_remote_urls",
                )
            filename = filename or unquote(urlsplit(url).path).rsplit("/", 1)[-1]
        identifier, destination = self.destination(filename)
        try:
            if path:
                with (
                    os.fdopen(os.open(source, os.O_RDONLY | os.O_NOFOLLOW), "rb") as src,
                    destination.open("xb") as dst,
                ):
                    total = 0
                    while chunk := src.read(1024 * 1024):
                        total += len(chunk)
                        if total > self.settings.max_asset_bytes:
                            raise SaycutError(
                                "asset_too_large", "Asset grew beyond the configured size limit"
                            )
                        dst.write(chunk)
            else:
                download(url, destination, self.settings.max_asset_bytes)
            return self.register(tenant, identifier, destination, filename)
        except BaseException:
            shutil.rmtree(destination.parent, ignore_errors=True)
            raise
