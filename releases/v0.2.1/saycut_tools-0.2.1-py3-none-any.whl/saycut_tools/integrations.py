from __future__ import annotations

import json
import os
import shlex
import shutil
import sys
from pathlib import Path
from types import SimpleNamespace

from . import __version__
from .config import Settings, write_json
from .errors import SaycutError
from .http import create_app
from .providers import PROVIDERS, tool_schemas
from .registry import OPERATIONS


def openapi30(value):
    if isinstance(value, list):
        return [openapi30(item) for item in value]
    if not isinstance(value, dict):
        return value
    value = {key: openapi30(item) for key, item in value.items() if key not in ("$schema", "examples")}
    if "const" in value:
        value["enum"] = [value.pop("const")]
    if "anyOf" in value and any(item.get("type") == "null" for item in value["anyOf"]):
        alternatives = [item for item in value.pop("anyOf") if item.get("type") != "null"]
        value["nullable"] = True
        if len(alternatives) == 1:
            value.update(alternatives[0])
        else:
            value["anyOf"] = alternatives
    for bound in ("exclusiveMinimum", "exclusiveMaximum"):
        if bound in value and not isinstance(value[bound], bool):
            value[bound.replace("exclusive", "").lower()] = value[bound]
            value[bound] = True
    return value


def n8n_workflow(base_url: str) -> dict:
    nodes = []
    connections = {}

    def node(name, kind, parameters, x, y=0, version=1):
        nodes.append(
            {
                "id": name.lower().replace(" ", "-"),
                "name": name,
                "type": kind,
                "typeVersion": version,
                "position": [x, y],
                "parameters": parameters,
            }
        )

    def link(source, target, output=0):
        branches = connections.setdefault(source, {"main": []})["main"]
        while len(branches) <= output:
            branches.append([])
        branches[output].append({"node": target, "type": "main", "index": 0})

    def request(name, operation, body, x):
        node(
            name,
            "n8n-nodes-base.httpRequest",
            {
                "method": "POST",
                "url": base_url + "/v1/tools/saycut_" + operation,
                "authentication": "genericCredentialType",
                "genericAuthType": "httpHeaderAuth",
                "sendBody": True,
                "specifyBody": "json",
                "jsonBody": body,
                "options": {"timeout": 30000},
            },
            x,
            version=4.2,
        )

    def condition(name, expression, x):
        node(
            name,
            "n8n-nodes-base.if",
            {
                "conditions": {
                    "options": {"caseSensitive": True, "typeValidation": "strict", "version": 2},
                    "conditions": [
                        {
                            "id": name,
                            "leftValue": expression,
                            "rightValue": True,
                            "operator": {"type": "boolean", "operation": "true", "singleValue": True},
                        }
                    ],
                    "combinator": "and",
                },
                "options": {},
            },
            x,
            version=2.2,
        )

    node(
        "Video Input", "n8n-nodes-base.executeWorkflowTrigger", {"inputSource": "passthrough"}, 0, version=1.1
    )
    request(
        "Start Render",
        "render_video",
        "={{ { asset_id: $json.asset_id, ...( $json.captions ? { captions: $json.captions } : {} ), "
        "style_id: $json.style_id || 'runtime/ZapMotion', allow_cloud_processing: $json.allow_cloud_processing === true, "
        "idempotency_key: 'n8n-' + $execution.id + '-' + $json.asset_id } }}",
        240,
    )
    node("Wait", "n8n-nodes-base.wait", {"amount": 3, "unit": "seconds"}, 700, version=1.1)
    request("Check Job", "get_job", "={{ { job_id: $('Start Render').item.json.job_id } }}", 940)
    condition(
        "Finished Or Timed Out",
        "={{ !['queued','running'].includes($json.status) || Date.now() / 1000 - $json.created > 7200 }}",
        1180,
    )
    condition("Succeeded", "={{ $json.status === 'succeeded' }}", 1420)
    node(
        "Render Failed",
        "n8n-nodes-base.stopAndError",
        {
            "errorMessage": "={{ JSON.stringify($json.error || { code: 'workflow_timeout', job_id: $json.job_id }) }}"
        },
        1660,
        180,
    )
    node("Video Ready", "n8n-nodes-base.noOp", {}, 1660, -100)
    for source, target in [
        ("Video Input", "Start Render"),
        ("Start Render", "Wait"),
        ("Wait", "Check Job"),
        ("Check Job", "Finished Or Timed Out"),
        ("Finished Or Timed Out", "Succeeded"),
        ("Succeeded", "Video Ready"),
    ]:
        link(source, target)
    link("Finished Or Timed Out", "Wait", 1)
    link("Succeeded", "Render Failed", 1)
    return {
        "name": "videocut.chat - editable captioned video",
        "nodes": nodes,
        "connections": connections,
        "active": False,
        "settings": {"executionOrder": "v1"},
        "pinData": {},
    }


def export_integrations(settings: Settings, output: Path, config: Path, plugin_source: Path | None = None):
    source = plugin_source or Path(__file__).resolve().parents[2] / "plugins/videocut-chat"
    if plugin_source and not (source / ".codex-plugin/plugin.json").is_file():
        raise SaycutError("plugin_source_missing", "Provide the unpacked videocut.chat plugin directory")
    output.mkdir(parents=True, exist_ok=True)
    for provider in PROVIDERS:
        write_json(output / (provider + ".tools.json"), tool_schemas(provider))
    app = create_app(settings, service=SimpleNamespace(settings=settings))
    write_json(output / "openapi.json", app.openapi())
    compatible = openapi30(app.openapi())
    compatible["openapi"] = "3.0.3"
    write_json(output / "openapi-3.0.json", compatible)
    coze = json.loads(json.dumps(compatible))
    coze["paths"] = {path: value for path, value in coze["paths"].items() if path.startswith("/v1/tools/")}
    write_json(output / "coze.openapi.json", coze)
    write_json(output / "n8n-workflow.json", n8n_workflow(settings.public_base_url.rstrip("/")))
    entry = {
        "command": sys.executable,
        "args": [
            *(["-I"] if settings.account_enabled else []),
            "-m",
            "saycut_tools.cli",
            "--config",
            str(config),
            "mcp",
        ],
    }
    write_json(output / "claude-desktop.json", {"mcpServers": {"videocut-chat": entry}})
    write_json(
        output / "claude-desktop.remote.json",
        {
            "mcpServers": {
                "videocut-chat": {
                    "command": sys.executable,
                    "args": ["-m", "saycut_tools.cli", "--config", str(config), "remote-mcp"],
                }
            }
        },
    )
    write_json(output / "claude-code.mcp.json", {"mcpServers": {"videocut-chat": {"type": "stdio", **entry}}})
    write_json(output / "cursor.mcp.json", {"mcpServers": {"videocut-chat": entry}})
    write_json(output / "qwen.settings.json", {"mcpServers": {"videocut-chat": entry}})
    endpoint = "https://mcp.zjtemplate.com/mcp"
    remote = {"type": "http", "url": endpoint, "headers": {"Authorization": "Bearer ${SAYCUT_TOKEN}"}}
    write_json(output / "claude-code.remote.json", {"mcpServers": {"videocut-chat": remote}})
    write_json(
        output / "qwen.remote.settings.json",
        {
            "mcpServers": {
                "videocut-chat": {"httpUrl": endpoint, "headers": {"Authorization": "Bearer ${SAYCUT_TOKEN}"}}
            }
        },
    )
    write_json(output / "mcp.remote.json", {"mcpServers": {"videocut-chat": remote}})
    (output / "codex.remote.toml").write_text(
        '[mcp_servers.videocut-chat]\nurl = "' + endpoint + '"\nbearer_token_env_var = "SAYCUT_TOKEN"\n'
    )
    write_json(
        output / "server.json",
        {
            "$schema": "https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json",
            "name": "com.zjtemplate/videocut-chat",
            "description": "videocut.chat video composition and animated captions.",
            "version": __version__,
            "remotes": [
                {
                    "type": "streamable-http",
                    "url": endpoint,
                    "headers": [
                        {
                            "name": "Authorization",
                            "description": "Bearer followed by your videocut.chat token",
                            "isRequired": True,
                            "isSecret": True,
                        }
                    ],
                }
            ],
        },
    )
    # JSON string literals are also valid TOML basic strings for these absolute local paths.
    (output / "codex.toml").write_text(
        "[mcp_servers.videocut-chat]\ncommand = "
        + json.dumps(sys.executable)
        + "\nargs = "
        + json.dumps(entry["args"])
        + "\n"
    )
    write_json(
        output / "operations.json",
        [{"name": op.name, "description": op.description, "readonly": op.readonly} for op in OPERATIONS],
    )
    if source.is_dir():
        destination = output / "plugins/videocut-chat"
        shutil.copytree(source, destination, dirs_exist_ok=True)
        write_json(destination / ".mcp.json", {"mcpServers": {"videocut-chat": entry}})
        qwen = json.loads((destination / "qwen-extension.json").read_text())
        qwen["mcpServers"] = {"videocut-chat": entry}
        write_json(destination / "qwen-extension.json", qwen)
        if os.name != "nt":
            launcher = destination / "scripts/run-mcp"
            launcher.parent.mkdir(parents=True, exist_ok=True)
            launcher.write_text("#!/bin/sh\nexec " + shlex.join([entry["command"], *entry["args"]]) + '\n')
            launcher.chmod(0o755)
        write_json(
            destination / "mcp.json",
            {
                "$schema": "https://agent-plugins.org/schemas/1.0.0/mcp.schema.json",
                "mcpServers": {
                    "videocut-chat": {
                        "type": "stdio",
                        # A contained POSIX launcher avoids desktop-host PATH/Python lookup.
                        "command": "python" if os.name == "nt" else "./scripts/run-mcp",
                        "args": [
                            "-I",
                            "-S",
                            "-c",
                            "import os; os.execv("
                            + repr(entry["command"])
                            + ", "
                            + repr([entry["command"], *entry["args"]])
                            + ")",
                        ] if os.name == "nt" else [],
                    }
                },
            },
        )
    return {
        "output": str(output.resolve()),
        "tools": len(OPERATIONS),
        "contains_credentials": False,
        "local_plugin_generated": source.is_dir(),
        "installation": "Generated configurations do not alter host settings or publish plugins",
    }
