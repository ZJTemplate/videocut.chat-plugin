from __future__ import annotations

import json
import os
import re
import secrets
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .errors import SaycutError


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + secrets.token_hex(6) + ".tmp")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            os.chmod(temporary, 0o600)
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


class Settings(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)
    data_dir: Path = Field(default_factory=lambda: Path.home() / ".local/share/saycut")
    allowed_roots: list[Path] = Field(default_factory=lambda: [Path.cwd()])
    catalog_file: Path = Field(default_factory=lambda: Path(__file__).parent / "data/catalog.json")
    effect_sources: dict[str, str] = Field(default_factory=dict)
    runtime_dir: Path | None = None
    template_generator_source: Path | None = None
    fallback_font: Path | None = None
    ffmpeg: str = "ffmpeg"
    ffprobe: str = "ffprobe"
    public_base_url: str = "http://127.0.0.1:8765"
    editor_origin: str = "https://edit.videocut.chat"
    editor_bridge_enabled: bool = False
    max_staging_bytes: int = Field(default=4 * 1024 * 1024 * 1024, ge=1024)
    max_asset_bytes: int = Field(default=512 * 1024 * 1024, ge=1024)
    max_duration: float = Field(default=600, gt=0, le=86400)
    render_timeout: int = Field(default=1800, ge=10, le=86400)
    max_active_jobs: int = Field(default=8, ge=1, le=64)
    concurrency: int = Field(default=1, ge=1, le=8)
    allow_remote_urls: bool = False
    sdk_telemetry: bool = False
    account_enabled: bool = False
    account_api_origin: str = "https://api.zjtemplate.com"
    account_platform_origin: str = "https://platform.zjtemplate.com"
    account_proxy: str | None = None
    hardware_encode: bool = False
    backend: Literal["local", "cloud"] = "local"
    asr_backend: Literal["disabled", "faster_whisper", "ryry"] = "disabled"
    asr_model: str = "small"
    asr_allow_model_download: bool = False
    asr_timeout: int = Field(default=900, ge=10, le=7200)
    database_url: str = Field(default="", exclude=True, repr=False)
    oss_bucket: str = ""
    oss_endpoint: str = "https://oss-cn-shenzhen.aliyuncs.com"
    oss_region: str = "cn-shenzhen"
    oss_prefix: str = "saycut-tools"
    aigc_base_url: str = "https://api.dalipen.com"
    aigc_widget_name: str = "GenVideo"
    aigc_widget_version: str | None = None
    aigc_protocol: Literal["legacy", "callback_v1"] = "legacy"
    aigc_extend: dict = Field(default_factory=dict)
    legacy_media_hosts: list[str] = Field(default_factory=list)
    cloud_templates: dict[str, dict] = Field(default_factory=dict)
    cloud_job_ttl: int = Field(default=86400, ge=300, le=604800)
    worker_lease_seconds: int = Field(default=120, ge=30, le=600)
    cloud_available_styles: list[str] = Field(default_factory=list)
    worker_origins: list[str] = Field(default_factory=lambda: ["https://mcp.zjtemplate.com"])
    openai_domain_challenge: str = ""
    oidc_issuer: str = ""
    oidc_audience: str = ""
    api_tokens: dict[str, str] = Field(default_factory=dict, exclude=True)

    @field_validator("account_proxy")
    @classmethod
    def validate_account_proxy(cls, value):
        if value is None:
            return None
        try:
            origin = urlsplit(value)
            if (
                origin.scheme not in {"http", "https"}
                or not origin.hostname
                or origin.username is not None
                or origin.password is not None
                or origin.path not in {"", "/"}
                or origin.query
                or origin.fragment
                or origin.port == 0
                or any(character.isspace() for character in value)
            ):
                raise ValueError
        except ValueError:
            raise SaycutError(
                "unsafe_account_proxy", "Account proxy must be an HTTP(S) origin without credentials"
            ) from None
        return value.rstrip("/")

    @classmethod
    def load(cls, path: str | Path | None = None) -> Settings:
        candidate = Path(path or os.environ.get("SAYCUT_CONFIG", "saycut.local.json")).expanduser()
        if path and not candidate.is_file():
            raise SaycutError("config_missing", f"Configuration not found: {candidate}")
        value = json.loads(candidate.read_text()) if candidate.is_file() else {}
        settings = cls.model_validate(value)
        if os.environ.get("SAYCUT_DATA_DIR"):
            settings.data_dir = Path(os.environ["SAYCUT_DATA_DIR"])
        for field in (
            "backend",
            "public_base_url",
            "database_url",
            "oss_bucket",
            "oss_endpoint",
            "aigc_base_url",
            "aigc_widget_version",
            "aigc_protocol",
            "oidc_issuer",
            "oidc_audience",
            "openai_domain_challenge",
        ):
            if os.environ.get("SAYCUT_" + field.upper()):
                setattr(settings, field, os.environ["SAYCUT_" + field.upper()])
        settings.data_dir = settings.data_dir.expanduser().resolve()
        settings.allowed_roots = [p.expanduser().resolve() for p in settings.allowed_roots]
        settings.data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        settings.api_tokens = json.loads(os.environ.get("SAYCUT_API_TOKENS", "{}"))
        if not settings.api_tokens:
            if settings.backend == "cloud":
                if not settings.oidc_issuer:
                    raise SaycutError("auth_required", "Cloud serving requires explicit API tokens or OIDC")
                return settings
            token_file = settings.data_dir / "api-token"
            try:
                with token_file.open("x") as stream:
                    os.chmod(token_file, 0o600)
                    stream.write(secrets.token_urlsafe(32))
            except FileExistsError:
                pass
            settings.api_tokens = {"local": token_file.read_text().strip()}
        for tenant, token in settings.api_tokens.items():
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", tenant) or len(token) < 24:
                raise SaycutError(
                    "invalid_auth_config", "Tenant IDs must be simple identifiers; tokens need 24+ characters"
                )
        return settings

    def snapshot(self) -> dict:
        return self.model_dump(mode="json")
