from __future__ import annotations

import json
import secrets
import shutil
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, RedirectResponse
from mcp.server.transport_security import TransportSecuritySettings
from starlette.concurrency import run_in_threadpool
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from . import __version__
from .config import Settings
from .errors import SaycutError
from .mcp_server import create_mcp
from .registry import OPERATIONS, TENANT, invoke
from .service import Service, create_service


class AuthMiddleware:
    def __init__(self, app, service: Service):
        self.app, self.service = app, service
        self.oidc = None
        if service.settings.oidc_issuer:
            from .oidc import OIDCVerifier

            self.oidc = OIDCVerifier(service.settings)

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        path = scope["path"]
        if (
            path
            in (
                "/health",
                "/docs",
                "/openapi.json",
                "/docs/oauth2-redirect",
                "/.well-known/openai-apps-challenge",
                "/.well-known/oauth-protected-resource",
                "/.well-known/oauth-protected-resource/mcp",
            )
            or scope["method"] == "OPTIONS"
        ):
            return await self.app(scope, receive, send)
        headers = dict(scope["headers"])
        total = 0
        limit = self.service.settings.max_asset_bytes if path == "/v1/assets/upload" else 4 * 1024 * 1024
        try:
            declared = int(headers.get(b"content-length", b"0"))
        except ValueError:
            return await JSONResponse({"error": {"code": "invalid_content_length"}}, status_code=400)(
                scope, receive, send
            )
        if declared < 0 or declared > limit:
            return await JSONResponse({"error": {"code": "request_too_large"}}, status_code=413)(
                scope, receive, send
            )

        async def bounded_receive():
            nonlocal total
            message = await receive()
            total += len(message.get("body", b""))
            if total > limit:
                raise SaycutError("request_too_large", "Request body exceeds the configured limit", 413)
            return message

        authorization = headers.get(b"authorization", b"").decode("latin1")
        token = authorization[7:] if authorization.startswith("Bearer ") else ""
        tenant = None
        if path.startswith("/internal/jobs/") and self.service.settings.backend == "cloud":
            try:
                claims = await run_in_threadpool(self.service.authorize_capability, token)
                if path.split("/")[3] != claims["sub"]:
                    raise SaycutError("invalid_capability", "Capability belongs to a different job", 403)
                scope["saycut_worker"] = claims
                return await self.app(scope, bounded_receive, send)
            except SaycutError as exc:
                return await JSONResponse(exc.payload(), status_code=exc.status)(scope, receive, send)
        if path.startswith("/v1/handoff/"):
            try:
                scope["saycut_handoff"] = await run_in_threadpool(self.service.handoff_job, token)
                return await self.app(scope, bounded_receive, send)
            except SaycutError as exc:
                return await JSONResponse(exc.payload(), status_code=exc.status)(scope, receive, send)
        for owner, secret in self.service.settings.api_tokens.items():
            if secrets.compare_digest(token, secret):
                tenant = owner
        if tenant is None and token and self.oidc:
            try:
                tenant = await run_in_threadpool(self.oidc.tenant, token)
            except SaycutError:
                pass
        if tenant is None:
            return await JSONResponse(
                {"error": {"code": "unauthorized", "message": "Bearer token required"}},
                status_code=401,
                headers={
                    "WWW-Authenticate": 'Bearer resource_metadata="'
                    + self.service.settings.public_base_url
                    + '/.well-known/oauth-protected-resource"'
                },
            )(scope, receive, send)
        context = TENANT.set(tenant)
        try:
            await self.app(scope, bounded_receive, send)
        finally:
            TENANT.reset(context)


def create_app(settings: Settings, service=None):
    service = service or create_service(settings)
    mcp = create_mcp(service)
    host = urlsplit(settings.public_base_url).hostname
    hosts = list(dict.fromkeys(["localhost", "127.0.0.1", "[::1]", host]))
    origins = [settings.editor_origin.rstrip("/"), settings.public_base_url.rstrip("/")]
    mcp_app = mcp.streamable_http_app(
        stateless_http=True,
        json_response=True,
        transport_security=TransportSecuritySettings(
            allowed_hosts=hosts + [h + ":*" for h in hosts], allowed_origins=origins
        ),
    )

    @asynccontextmanager
    async def lifespan(app):
        async with mcp.session_manager.run():
            yield

    app = FastAPI(
        title="videocut.chat Tools",
        version=__version__,
        lifespan=lifespan,
        description="videocut.chat video composition: local template_generator or cloud GenVideo workers.",
    )
    app.state.service = service

    @app.exception_handler(SaycutError)
    async def expected_error(request, exc):
        return JSONResponse(exc.payload(), status_code=exc.status)

    @app.get("/health")
    def health():
        return {"status": "ok", "service": "saycut-tools", "version": __version__, "backend": settings.backend}

    @app.get("/.well-known/openai-apps-challenge", include_in_schema=False)
    def challenge():
        if not settings.openai_domain_challenge:
            raise SaycutError("not_configured", "No domain verification challenge configured", 404)
        return PlainTextResponse(settings.openai_domain_challenge)

    @app.get("/.well-known/oauth-protected-resource", include_in_schema=False)
    @app.get("/.well-known/oauth-protected-resource/mcp", include_in_schema=False)
    def protected_resource():
        if not settings.oidc_issuer:
            raise SaycutError(
                "oauth_not_configured", "This installation currently uses manually issued API tokens", 404
            )
        return {
            "resource": settings.public_base_url.rstrip("/") + "/mcp",
            "authorization_servers": [settings.oidc_issuer],
            "scopes_supported": ["saycut:tools"],
            "bearer_methods_supported": ["header"],
        }

    def route(operation):
        async def call(body):
            return await run_in_threadpool(
                invoke, service, operation.name, body.model_dump(mode="json"), TENANT.get(), False
            )

        call.__annotations__ = {"body": operation.model, "return": dict}
        call.__name__ = operation.name
        return call

    for operation in OPERATIONS:
        app.add_api_route(
            "/v1/tools/" + operation.name,
            route(operation),
            methods=["POST"],
            operation_id=operation.name,
            description=operation.description,
            tags=["Tools"],
        )

    @app.post("/v1/assets/upload", tags=["Assets"], operation_id="saycut_upload_asset")
    async def upload(request: Request, filename: str):
        if settings.backend == "cloud":
            raise SaycutError(
                "direct_upload_required", "Use prepare_upload and complete_upload for OSS direct uploads", 409
            )
        identifier, path = service.assets.destination(filename)
        try:
            total = 0
            with path.open("xb") as stream:
                async for chunk in request.stream():
                    total += len(chunk)
                    if total > settings.max_asset_bytes:
                        raise SaycutError("asset_too_large", "Upload exceeds the byte limit", 413)
                    stream.write(chunk)
            return await run_in_threadpool(service.assets.register, TENANT.get(), identifier, path, filename)
        except BaseException:
            shutil.rmtree(path.parent, ignore_errors=True)
            raise

    @app.get("/v1/jobs/{job_id}/files/{kind}", tags=["Assets"])
    def result_file(job_id: str, kind: str):
        if kind not in ("video", "bundle", "sky_json"):
            raise SaycutError("file_not_found", "Unknown output kind", 404)
        job = service.store.job(TENANT.get(), job_id)
        if job["status"] != "succeeded":
            raise SaycutError("output_not_ready", "Job has no completed output", 409)
        if settings.backend == "cloud":
            if settings.aigc_protocol == "legacy":
                url = job["result"].get("downloads", {}).get(kind)
                if not url:
                    raise SaycutError(
                        "output_unavailable", "This GenVideo task did not return that artifact", 404
                    )
                return RedirectResponse(url, status_code=303, headers={"Cache-Control": "private, no-store"})
            return RedirectResponse(
                service.objects.get_url(job["result"]["objects"][kind]),
                status_code=303,
                headers={"Cache-Control": "private, no-store"},
            )
        path = Path(job["result"][kind])
        if not path.is_file():
            raise SaycutError("output_missing", "Output was removed from local storage", 410)
        return FileResponse(path, filename=path.name, headers={"Cache-Control": "private, no-store"})

    @app.get("/v1/handoff/manifest", include_in_schema=False)
    def handoff_manifest(request: Request):
        job = request.scope["saycut_handoff"]
        if settings.backend == "cloud":
            return JSONResponse(service.handoff_manifest(job), headers={"Cache-Control": "no-store"})
        root = settings.data_dir / "jobs" / job["job_id"] / "native-project"
        return JSONResponse(
            json.loads((root / "saycut-manifest.json").read_text()), headers={"Cache-Control": "no-store"}
        )

    @app.get("/v1/handoff/file", include_in_schema=False)
    def handoff_file(request: Request, path: str):
        job = request.scope["saycut_handoff"]
        if settings.backend == "cloud":
            return RedirectResponse(
                service.handoff_url(job, path), status_code=303, headers={"Cache-Control": "no-store"}
            )
        root = (settings.data_dir / "jobs" / job["job_id"] / "native-project").resolve()
        manifest = json.loads((root / "saycut-manifest.json").read_text())
        target = (root / path).resolve()
        if path not in manifest["files"] or not target.is_relative_to(root) or not target.is_file():
            raise SaycutError("file_not_found", "File not included in this project", 404)
        return FileResponse(
            target, headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"}
        )

    if settings.backend == "cloud":
        from . import cloud_models as cm

        for action, model, method in (
            ("claim", cm.Claim, "claim"),
            ("heartbeat", cm.Heartbeat, "heartbeat"),
            ("uploads", cm.ArtifactUpload, "artifact_uploads"),
            ("complete", cm.Complete, "complete"),
            ("failed", cm.Failure, "fail"),
        ):

            def worker_route(model, method):
                async def call(job_id: str, request: Request, body):
                    claims = request.scope["saycut_worker"]
                    return await run_in_threadpool(getattr(service, method), claims["tenant"], job_id, body)

                call.__annotations__["body"] = model
                return call

            app.add_api_route(
                "/internal/jobs/{job_id}/" + action,
                worker_route(model, method),
                methods=["POST"],
                include_in_schema=False,
            )

    original_openapi = app.openapi

    def openapi():
        schema = original_openapi()
        schema.setdefault("components", {}).setdefault("securitySchemes", {})["SaycutBearer"] = {
            "type": "http",
            "scheme": "bearer",
        }
        schema["security"] = [{"SaycutBearer": []}]
        schema["servers"] = [{"url": settings.public_base_url}]
        return schema

    app.openapi = openapi
    app.mount("/", mcp_app)
    app.add_middleware(AuthMiddleware, service=service)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "MCP-Protocol-Version", "Mcp-Session-Id"],
        expose_headers=["Mcp-Session-Id"],
    )
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)
    return app
