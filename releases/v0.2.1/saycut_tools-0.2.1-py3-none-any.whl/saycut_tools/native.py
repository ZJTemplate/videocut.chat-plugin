"""Isolated compatibility adapter; SDK license verification remains in force."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from .config import Settings, write_json
from .errors import SaycutError
from .license_adapter import install_license, native_license
from .models import ProjectSpec


class NativeProcesses:
    """Keep SDK orchestration while replacing its shell launches with argument-vector execution."""

    def __getattr__(self, name):
        return getattr(subprocess, name)

    @staticmethod
    def arguments(command, kwargs):
        if not isinstance(command, list):
            raise SaycutError(
                "unsafe_native_command", "The native adapter only accepts argument-vector commands"
            )
        kwargs["shell"] = False
        return command, kwargs

    def run(self, command, **kwargs):
        command, kwargs = self.arguments(command, kwargs)
        return subprocess.run(command, check=kwargs.pop("check", False), **kwargs)

    def Popen(self, command, **kwargs):
        command, kwargs = self.arguments(command, kwargs)
        return subprocess.Popen(command, **kwargs)


def native_binary(settings: Settings) -> Path:
    if not settings.runtime_dir or not settings.runtime_dir.is_dir():
        raise SaycutError("runtime_missing", "Configure runtime_dir with a licensed TemplateProcess runtime")
    filename = {
        "darwin": "TemplateProcess",
        "win32": "TemplateProcess.exe",
        "linux": "TemplateProcess_osmesa",
    }.get(sys.platform)
    if not filename:
        raise SaycutError("unsupported_os", "Native rendering supports macOS, Windows and provisioned Linux")
    if sys.platform == "linux" and settings.hardware_encode:
        filename = "TemplateProcess_egl"
    binary = settings.runtime_dir / "skymedia" / filename
    if not binary.is_file() or not os.access(binary, os.X_OK):
        raise SaycutError("runtime_missing", f"Executable native runtime not found: {filename}")
    return binary.resolve()


def run(settings: Settings, folder: Path):
    binary = native_binary(settings)
    if settings.template_generator_source:
        sys.path.insert(0, str(settings.template_generator_source))
    try:
        from template_generator import license_manager, stats, template
    except ImportError as exc:
        raise SaycutError(
            "sdk_missing", "Install saycut-tools[native] or configure template_generator_source"
        ) from exc

    if settings.account_enabled:
        from .account import AccountClient

        with AccountClient(settings) as account:
            install_license(settings, license_manager, account.prepare_license())

    if not settings.sdk_telemetry:
        stats._stats_reporter.report_function_call = lambda *args, **kwargs: None

    def command(arguments):
        arguments = [str(item) for item in arguments]
        if "--license" not in arguments:
            key = license_manager.read_license()
            if key:
                arguments = [arguments[0], "--license", native_license(key), *arguments[1:]]
        else:
            index = arguments.index("--license") + 1
            arguments[index] = native_license(arguments[index])
        return [str(binary), *arguments[1:]]

    template.realCommand = command
    template.subprocess = NativeProcesses()
    template.getBinary = lambda *args, **kwargs: (str(binary.parent), binary.name)
    template.thisFileDir = str(folder / "sdk-tmp")
    Path(template.thisFileDir).mkdir(exist_ok=True)
    output_dir = folder / "native-project"
    template.generateTemplate(
        str(folder / "layers.json"),
        str(output_dir),
        str(settings.runtime_dir),
        printLog=False,
        useHardwareEncode=settings.hardware_encode,
        useHardwareDecode=False,
    )
    if not (output_dir / "template.proj").is_file() or not list(output_dir.rglob("*.sky")):
        raise SaycutError("compile_failed", "TemplateProcess did not generate its native project files")
    spec = ProjectSpec.model_validate_json((folder / "project.json").read_text())
    for path in output_dir.rglob("*.sky"):
        sky = json.loads(path.read_text())
        sky["timeline"]["videoParams"]["frameRate"] = float(spec.fps)
        write_json(path, sky)
    # The native RapidJSON reader checks IsDouble(), so an integer frameRate would silently become 30.
    write_json(
        output_dir / "output.conf",
        [
            {
                "height": spec.height,
                "width": spec.width,
                "frameRate": float(spec.fps),
                "type": "Video",
                "videoBitRate": max(500000, spec.width * spec.height * 4),
                "audioBitRate": 128000,
            }
        ],
    )

    def progress(value, *args):
        try:
            write_json(folder / "progress.json", {"progress": float(value)})
        except (ValueError, TypeError):
            pass

    template.executeTemplate(
        {"input": [], "template": str(output_dir), "params": {}, "output": str(folder / "video.mp4")},
        searchPath=str(settings.runtime_dir),
        printLog=False,
        oneVideoTimeout=settings.render_timeout,
        useHardwareEncode=settings.hardware_encode,
        useHardwareDecode=False,
        progress_callback=progress,
    )
    if not (folder / "video.mp4").is_file():
        raise SaycutError("render_failed", "TemplateProcess returned without an output video")


def main():
    folder = Path(sys.argv[1]).resolve()
    os.umask(0o077)
    parent = os.getppid()

    def watch_parent():
        while os.getppid() == parent:
            time.sleep(2)
        if os.name != "nt":
            os.killpg(os.getpgrp(), signal.SIGKILL)
        os._exit(1)

    threading.Thread(target=watch_parent, daemon=True).start()
    try:
        settings = Settings.model_validate_json((folder / "settings.json").read_text())
        run(settings, folder)
    except Exception as exc:  # noqa: BLE001 - isolate all native SDK failures from the protocol process
        # Never forward SDK exception text: some versions include full shell commands with license keys.
        code = exc.code if isinstance(exc, SaycutError) else "native_" + type(exc).__name__.lower()
        write_json(
            folder / "native-error.json",
            {"code": code, "message": "Native SDK failed; check runtime and license using doctor"},
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
