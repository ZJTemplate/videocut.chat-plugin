from pathlib import PurePosixPath
from typing import Any

from pydantic import Field, model_validator

from .models import Model, ProjectSpec


class Claim(Model):
    run_id: str = Field(pattern=r"^[a-zA-Z0-9_-]{16,100}$")


class Lease(Claim):
    attempt: int = Field(ge=1)


class Heartbeat(Lease):
    progress: float = Field(default=0, ge=0, le=1)


class Artifact(Model):
    bytes: int = Field(gt=0)
    content_type: str = Field(default="application/octet-stream", max_length=120)


class ArtifactUpload(Lease):
    files: dict[str, Artifact] = Field(min_length=1, max_length=2000)

    @model_validator(mode="after")
    def safe_paths(self):
        for name in self.files:
            path = PurePosixPath(name)
            if (
                path.is_absolute()
                or ".." in path.parts
                or "\\" in name
                or "\x00" in name
                or len(name) > 600
                or path.as_posix() != name
                or path.parts[0] not in ("outputs", "native-project")
            ):
                raise ValueError("Artifact paths must be relative under outputs/ or native-project/")
        return self


class Complete(Lease):
    project: ProjectSpec
    media: dict[str, Any]
    usage: dict[str, Any] = Field(default_factory=dict)
    assets: dict[str, dict] = Field(default_factory=dict, max_length=200)


class Failure(Lease):
    code: str = Field(default="worker_failed", pattern=r"^[a-z_]{1,80}$")
