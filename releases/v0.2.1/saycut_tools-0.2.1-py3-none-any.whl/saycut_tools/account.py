"""Private device-flow credentials. The SDK never receives a platform login token."""

from __future__ import annotations

import json
import os
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from .config import Settings, write_json
from .errors import SaycutError

CLIENT_ID = "saycut-local"
SCOPE = "account:read license:local"


def private_directory(settings: Settings) -> Path:
    path = settings.data_dir / "private"
    if path.is_symlink():
        raise SaycutError("unsafe_credentials", "Credential directory must not be a symbolic link")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path, 0o700)
    return path


class AccountClient:
    def __init__(self, settings: Settings, transport=None):
        if not settings.account_enabled:
            raise SaycutError("account_disabled", "Enable account authorization in the plugin configuration")
        self.settings = settings
        origin = urlsplit(settings.account_api_origin)
        if (
            origin.scheme != "https"
            or not origin.hostname
            or origin.username
            or origin.password
            or origin.query
            or origin.fragment
            or origin.path not in ("", "/")
        ):
            raise SaycutError("unsafe_account_origin", "Account API must use an HTTPS origin")
        self.origin = settings.account_api_origin.rstrip("/")
        self.directory = private_directory(settings)
        self.path = self.directory / "account.json"
        if self.path.is_symlink():
            raise SaycutError("unsafe_credentials", "Credential file must not be a symbolic link")
        self.client = httpx.Client(
            base_url=self.origin,
            timeout=15,
            verify=True,
            follow_redirects=False,
            trust_env=False,
            proxy=settings.account_proxy,
            transport=transport,
        )

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.client.close()

    @contextmanager
    def locked(self):
        from .worker import try_lock

        deadline = time.monotonic() + 35
        lock = None
        while not lock:
            lock = try_lock(self.directory / "account.lock")
            if lock:
                break
            if time.monotonic() > deadline:
                raise SaycutError("account_busy", "Another account operation is running", 409, True)
            time.sleep(0.1)
        try:
            yield
        finally:
            lock.close()

    def read(self):
        if self.path.is_symlink():
            raise SaycutError("unsafe_credentials", "Credential file must not be a symbolic link")
        try:
            value = json.loads(self.path.read_text()) if self.path.exists() else {"api_origin": self.origin}
        except (ValueError, OSError):
            raise SaycutError(
                "invalid_credentials", "Private account state cannot be read; it has not been replaced"
            ) from None
        if not isinstance(value, dict) or any(
            key in value and (not isinstance(value[key], str) or not value[key].strip())
            for key in ("access_token", "refresh_token", "connection_id")
        ):
            raise SaycutError(
                "invalid_credentials", "Invalid private account state; it has not been replaced"
            )
        if value.get("api_origin") != self.origin:
            raise SaycutError(
                "account_origin_mismatch", "Use a separate data directory for another account server"
            )
        return value

    def save(self, value):
        write_json(self.path, {**value, "api_origin": self.origin})

    def request(self, method, path, *, access=None, **kwargs):
        try:
            response = self.client.request(
                method, path, headers={"Authorization": "Bearer " + access} if access else {}, **kwargs
            )
        except httpx.HTTPError:
            raise SaycutError(
                "account_unavailable", "Account verification failed; no offline fallback", 503, True
            ) from None
        try:
            value = response.json()
        except ValueError:
            raise SaycutError("account_unavailable", "Invalid account service response", 503, True) from None
        if not isinstance(value, dict):
            raise SaycutError("account_unavailable", "Invalid account service response", 503, True)
        if response.status_code != 200 or value.get("error"):
            code = value.get("error")
            if isinstance(code, dict):
                code = code.get("code")
            allowed = {
                "invalid_token",
                "invalid_grant",
                "authorization_pending",
                "slow_down",
                "expired_token",
                "access_denied",
                "entitlement_required",
                "rate_limited",
                "license_unavailable",
            }
            code = code if isinstance(code, str) and code in allowed else "account_unavailable"
            status = response.status_code if response.status_code >= 400 else 502
            raise SaycutError(
                code,
                "Account authorization: " + code,
                status,
                status >= 500 or status == 429 or code == "rate_limited",
            )
        return value

    @staticmethod
    def validate_tokens(value):
        if (
            any(
                not isinstance(value.get(key), str)
                or not value[key].strip()
                or any(character.isspace() for character in value[key])
                for key in ("access_token", "refresh_token", "connection_id")
            )
            or value.get("token_type") != "Bearer"
            or type(value.get("expires_in")) is not int
            or value["expires_in"] <= 0
        ):
            raise SaycutError(
                "account_unavailable", "Invalid token response; credentials unchanged", 503, True
            )
        return value

    def start_login(self, device_name="Local computer"):
        with self.locked():
            state = self.read()
            if state.get("access_token"):
                raise SaycutError("already_connected", "Log out before connecting another account")
            result = self.request(
                "POST",
                "/mcp/v1/device/authorize",
                data={"client_id": CLIENT_ID, "device_name": device_name, "scope": SCOPE},
            )
            if any(
                not isinstance(result.get(key), str) or not result[key].strip()
                for key in ("device_code", "user_code", "verification_uri", "verification_uri_complete")
            ) or any(
                type(result.get(key)) is not int or result[key] <= 0 for key in ("interval", "expires_in")
            ):
                raise SaycutError("account_unavailable", "Invalid device authorization response", 503, True)
            expected = urlsplit(self.settings.account_platform_origin)
            for key in ("verification_uri", "verification_uri_complete"):
                try:
                    verification = urlsplit(result[key])
                    safe = (
                        verification.scheme == "https"
                        and verification.netloc == expected.netloc
                        and verification.path == "/mcp/authorize"
                        and not verification.fragment
                        and not any(character.isspace() for character in result[key])
                    )
                except ValueError:
                    safe = False
                if not safe:
                    raise SaycutError("unsafe_authorization_url", "Unexpected authorization destination")
            state["pending"] = {"device_code": result["device_code"], "interval": result["interval"]}
            self.save(state)
            return {
                key: result[key]
                for key in (
                    "verification_uri",
                    "verification_uri_complete",
                    "user_code",
                    "expires_in",
                    "interval",
                )
            }

    def complete_login(self):
        with self.locked():
            state = self.read()
            pending = state.get("pending")
            if not pending:
                raise SaycutError("login_required", "Start account login first", 401)
            if (
                not isinstance(pending, dict)
                or not isinstance(pending.get("device_code"), str)
                or not pending["device_code"]
                or type(pending.get("interval")) is not int
                or pending["interval"] <= 0
            ):
                raise SaycutError("invalid_credentials", "Invalid pending authorization; start login again")
            try:
                result = self.request(
                    "POST",
                    "/mcp/v1/token",
                    data={
                        "client_id": CLIENT_ID,
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                        "device_code": pending["device_code"],
                    },
                )
            except SaycutError as error:
                if error.code in {"authorization_pending", "slow_down"}:
                    if error.code == "slow_down":
                        pending["interval"] += 5
                        self.save(state)
                    return {"status": "pending", "interval": pending["interval"]}
                raise
            self.validate_tokens(result)
            self.save({**result, "api_origin": self.origin})
            return {"status": "connected", "connection_id": result["connection_id"]}

    def authorized(self, state, method, path, **kwargs):
        access = state.get("access_token")
        if not access:
            raise SaycutError("login_required", "Run saycut-tools account login or use account_login", 401)
        try:
            return self.request(method, path, access=access, **kwargs)
        except SaycutError as error:
            if error.code != "invalid_token" or not state.get("refresh_token"):
                raise
        result = self.request(
            "POST",
            "/mcp/v1/token",
            data={
                "client_id": CLIENT_ID,
                "grant_type": "refresh_token",
                "refresh_token": state["refresh_token"],
            },
        )
        state.update(self.validate_tokens(result))
        self.save(state)
        return self.request(method, path, access=state["access_token"], **kwargs)

    def status(self):
        with self.locked():
            state = self.read()
            if not state.get("access_token"):
                return {"status": "disconnected"}
            info = self.authorized(state, "GET", "/mcp/v1/session")
            if type(info.get("local_render_allowed")) is not bool:
                raise SaycutError("account_unavailable", "Invalid account entitlement response", 503, True)
            return {
                "status": "connected",
                **{
                    key: info[key]
                    for key in (
                        "connection_expires_at",
                        "connection_id",
                        "device_name",
                        "entitlement_until",
                        "local_render_allowed",
                        "scope",
                        "server_time",
                        "user_id",
                    )
                    if key in info
                },
            }

    def require_render(self):
        info = self.status()
        if info.get("local_render_allowed") is not True:
            raise SaycutError("entitlement_required", "Sign in with an active local-render entitlement", 403)

    def prepare_license(self):
        with self.locked():
            state = self.read()
            lease = self.authorized(state, "POST", "/mcp/v1/license/issue", json={})
            key = lease.get("license", "")
            if not isinstance(key, str) or not key.startswith("mcp-") or len(key) <= 4:
                raise SaycutError(
                    "invalid_personal_license", "Account service did not return a personal license"
                )
            # Only the private credential store contains the lease, never job/settings snapshots.
            state["lease"] = lease
            self.save(state)
            return key

    def logout(self):
        with self.locked():
            state = self.read()
            if state.get("access_token"):
                try:
                    self.authorized(state, "POST", "/mcp/v1/logout", json={})
                except SaycutError as error:
                    if error.code not in {"invalid_token", "invalid_grant"}:
                        # Do not claim revocation when the server could not be reached.
                        raise
            self.path.unlink(missing_ok=True)
            sdk = self.directory / "sdk"
            if not sdk.is_symlink():
                for name in ("license.txt", ".state"):
                    (sdk / name).unlink(missing_ok=True)
            return {"status": "disconnected"}


def require_account(settings):
    if settings.account_enabled:
        with AccountClient(settings) as account:
            account.require_render()
